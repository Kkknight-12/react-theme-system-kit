# Installation Instructions

## Quick Start

1. **Install dependencies:**
   ```bash
   pnpm install
   # or
   npm install
   ```

2. **Start development server:**
   ```bash
   pnpm dev
   # or
   npm run dev
   ```

3. **Build for production:**
   ```bash
   pnpm build
   # or
   npm run build
   ```

## Live Demo
View the live demo at: https://react-theme-kit.vercel.app/

## Documentation
- README.md - Getting started guide
- THEME-CUSTOMIZATION-GUIDE.md - How to customize themes
- THEME-EXPORT-GUIDE.md - Export/import themes
- TYPESCRIPT.md - TypeScript usage
- COMPONENTS.md - Component documentation

## Support
For support, please refer to the documentation or contact the seller.

Thank you for purchasing React Theme System Kit!
