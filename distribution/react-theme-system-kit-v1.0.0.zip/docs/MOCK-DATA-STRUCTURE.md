# Mock Data Structure

**Project**: Modern Admin Dashboard Template  
**Purpose**: Define consistent mock data structures across all components  
**Last Updated**: 2025-01-14

## 🎯 Overview

This document defines the mock data architecture for the admin dashboard template. All mock data follows consistent patterns to ensure uniformity across 170+ pages.

## 📁 File Structure

```
src/
  utils/
    mock-data/
      index.js           # Main export file
      generators.js      # Utility functions for data generation
      constants.js       # Pre-defined data arrays
      users.js          # User-related mock data
      products.js       # Product-related mock data
      orders.js         # Order-related mock data
      analytics.js      # Dashboard metrics and charts
      support.js        # Tickets and support data
      content.js        # Blog posts and media
      notifications.js  # Notification data
      settings.js       # App configuration data
```

## 🔑 ID Generation

Using **nanoid** library for unique, readable IDs:

```javascript
import { nanoid } from 'nanoid'

// ID Format: prefix_nanoidString
// Examples:
// usr_Ab3kL9mN2 (users)
// prd_Xy7pQ4rT8 (products)
// ord_Mn5kB2zW9 (orders)

export function generateId(prefix) {
  return `${prefix}_${nanoid(10)}`
}

// Prefixes by entity:
const ID_PREFIXES = {
  user: 'usr',
  product: 'prd',
  order: 'ord',
  ticket: 'tkt',
  invoice: 'inv',
  post: 'pst',
  category: 'cat',
  notification: 'ntf',
  transaction: 'txn',
  customer: 'cst',
  vendor: 'vnd',
  staff: 'stf'
}
```

## 👥 User Entities

### User Types
```javascript
// Staff Member
{
  id: 'stf_Ab3kL9mN2',
  type: 'staff',
  firstName: 'Emma',
  lastName: 'Johnson',
  fullName: 'Emma Johnson',
  email: 'emma.johnson@company.com',
  phone: '+1 (555) 123-4567',
  avatar: 'https://picsum.photos/seed/stf_Ab3kL9mN2/200/200',
  role: 'Admin', // Admin, Manager, Employee
  department: 'Engineering',
  position: 'Senior Developer',
  status: 'active', // active, inactive, suspended
  isVerified: true,
  joinedDate: '2023-01-15T00:00:00Z',
  lastActive: '2024-01-14T10:30:00Z',
  permissions: ['users.view', 'users.edit', 'orders.manage'],
  address: {
    street: '123 Tech Boulevard',
    city: 'San Francisco',
    state: 'CA',
    country: 'USA',
    zipCode: '94105'
  },
  preferences: {
    theme: 'light',
    language: 'en',
    timezone: 'America/Los_Angeles',
    notifications: {
      email: true,
      push: true,
      sms: false
    }
  }
}

// Customer
{
  id: 'cst_Xy7pQ4rT8',
  type: 'customer',
  // Similar structure but with:
  loyaltyPoints: 1250,
  tier: 'Gold', // Bronze, Silver, Gold, Platinum
  totalSpent: 4567.89,
  orderCount: 23,
  tags: ['vip', 'repeat-buyer']
}

// Vendor
{
  id: 'vnd_Mn5kB2zW9',
  type: 'vendor',
  companyName: 'Tech Supplies Inc',
  contactPerson: 'John Smith',
  // Additional vendor fields
  rating: 4.5,
  productCount: 156,
  revenue: 125678.90
}
```

## 📦 Product Entities

```javascript
{
  id: 'prd_Ht6nK3pL8',
  sku: 'DASH-PRO-001',
  name: 'Dashboard Pro License',
  slug: 'dashboard-pro-license',
  description: 'Professional admin dashboard with advanced features',
  type: 'digital', // physical, digital, service, subscription
  category: {
    id: 'cat_Jk9mN2qR5',
    name: 'Software Licenses',
    slug: 'software-licenses'
  },
  price: {
    amount: 99.00,
    currency: 'USD',
    compareAt: 149.00, // Original price for sale items
    tax: 9.90
  },
  images: [
    'https://picsum.photos/seed/prd_Ht6nK3pL8_1/600/400',
    'https://picsum.photos/seed/prd_Ht6nK3pL8_2/600/400'
  ],
  thumbnail: 'https://picsum.photos/seed/prd_Ht6nK3pL8_thumb/300/300',
  status: 'active', // active, inactive, draft, archived
  inventory: {
    trackInventory: false, // false for digital products
    quantity: null,
    lowStockThreshold: null
  },
  attributes: {
    license: 'single-site',
    support: '1-year',
    updates: 'lifetime'
  },
  seo: {
    title: 'Dashboard Pro - Professional Admin Template',
    description: 'Modern admin dashboard template with 150+ pages',
    keywords: ['admin', 'dashboard', 'template']
  },
  metrics: {
    views: 3456,
    sales: 234,
    rating: 4.8,
    reviewCount: 89
  },
  createdAt: '2023-06-15T00:00:00Z',
  updatedAt: '2024-01-10T00:00:00Z'
}
```

## 🛒 Order Entities

```javascript
{
  id: 'ord_Qw8eR5tY2',
  orderNumber: 'ORD-2024-0156',
  type: 'sale', // sale, subscription, refund
  customer: {
    id: 'cst_Xy7pQ4rT8',
    name: 'Michael Brown',
    email: 'michael.brown@email.com'
  },
  items: [
    {
      id: 'itm_Zx9cV3bN1',
      product: {
        id: 'prd_Ht6nK3pL8',
        name: 'Dashboard Pro License',
        sku: 'DASH-PRO-001'
      },
      quantity: 1,
      price: 99.00,
      discount: 10.00,
      tax: 8.10,
      total: 97.10
    }
  ],
  pricing: {
    subtotal: 99.00,
    discount: 10.00,
    tax: 8.10,
    shipping: 0.00,
    total: 97.10
  },
  status: 'completed', // pending, processing, completed, cancelled, refunded
  paymentStatus: 'paid', // pending, paid, failed, refunded
  fulfillmentStatus: 'delivered', // unfulfilled, partial, fulfilled, delivered
  payment: {
    method: 'credit_card', // credit_card, paypal, bank_transfer
    transactionId: 'txn_Lk4mN7pQ2',
    last4: '4242'
  },
  shipping: {
    method: 'email', // email for digital, standard, express for physical
    trackingNumber: null,
    address: null // null for digital products
  },
  dates: {
    created: '2024-01-10T14:30:00Z',
    paid: '2024-01-10T14:31:00Z',
    fulfilled: '2024-01-10T14:32:00Z',
    delivered: '2024-01-10T14:32:00Z'
  },
  notes: {
    customer: 'Please send license to alternate email',
    internal: 'VIP customer - priority support'
  }
}
```

## 📊 Analytics Entities

```javascript
// Dashboard Metrics
{
  revenue: {
    current: 125678.90,
    previous: 98456.78,
    change: 27.65, // percentage
    trend: 'up' // up, down, stable
  },
  orders: {
    current: 1234,
    previous: 987,
    change: 25.02,
    trend: 'up'
  },
  customers: {
    current: 8901,
    previous: 7654,
    change: 16.29,
    trend: 'up'
  },
  avgOrderValue: {
    current: 101.89,
    previous: 99.75,
    change: 2.14,
    trend: 'up'
  }
}

// Chart Data
{
  salesByMonth: [
    { month: 'Jan', value: 45000, year: 2024 },
    { month: 'Feb', value: 52000, year: 2024 },
    // ... 12 months
  ],
  topProducts: [
    { name: 'Dashboard Pro', sales: 234, revenue: 23166 },
    { name: 'Admin Plus', sales: 189, revenue: 18711 },
    // ... top 10
  ],
  trafficSources: [
    { source: 'Organic Search', visits: 45678, percentage: 35.2 },
    { source: 'Direct', visits: 34567, percentage: 26.6 },
    // ... all sources
  ]
}
```

## 🎫 Support Entities

```javascript
{
  id: 'tkt_Nm7kP2qW8',
  ticketNumber: 'TKT-2024-0892',
  subject: 'Cannot access dashboard after update',
  description: 'After the recent update, I cannot login to my dashboard...',
  customer: {
    id: 'cst_Xy7pQ4rT8',
    name: 'Sarah Wilson',
    email: 'sarah.wilson@email.com'
  },
  assignee: {
    id: 'stf_Ab3kL9mN2',
    name: 'Emma Johnson',
    avatar: 'https://picsum.photos/seed/stf_Ab3kL9mN2/200/200'
  },
  status: 'open', // open, in_progress, resolved, closed
  priority: 'high', // low, medium, high, urgent
  category: 'technical', // technical, billing, feature_request, other
  tags: ['login-issue', 'high-priority', 'v2.1'],
  createdAt: '2024-01-14T09:15:00Z',
  updatedAt: '2024-01-14T10:30:00Z',
  resolvedAt: null,
  responseTime: null, // in minutes
  messages: [
    {
      id: 'msg_Qw3eR5tY7',
      sender: {
        id: 'cst_Xy7pQ4rT8',
        name: 'Sarah Wilson',
        type: 'customer'
      },
      message: 'I tried clearing cache but still cannot login',
      attachments: [],
      createdAt: '2024-01-14T09:45:00Z'
    }
  ]
}
```

## 📝 Content Entities

```javascript
// Blog Post
{
  id: 'pst_Hg6nM3kL9',
  title: 'New Dashboard Features Released',
  slug: 'new-dashboard-features-released',
  excerpt: 'We are excited to announce new features...',
  content: '<p>Full HTML content here...</p>',
  author: {
    id: 'stf_Ab3kL9mN2',
    name: 'Emma Johnson',
    avatar: 'https://picsum.photos/seed/stf_Ab3kL9mN2/200/200'
  },
  category: 'Product Updates',
  tags: ['features', 'update', 'dashboard'],
  featuredImage: 'https://picsum.photos/seed/pst_Hg6nM3kL9/1200/600',
  status: 'published', // draft, published, scheduled, archived
  publishDate: '2024-01-10T00:00:00Z',
  seo: {
    title: 'New Dashboard Features - January 2024 Update',
    description: 'Discover the latest features added to our dashboard',
    keywords: ['dashboard', 'features', 'update']
  },
  metrics: {
    views: 2345,
    likes: 123,
    shares: 45,
    comments: 12
  }
}

// Media Library Item
{
  id: 'med_Jk8pQ4nT6',
  filename: 'dashboard-screenshot.png',
  title: 'Dashboard Screenshot',
  alt: 'Screenshot showing the main dashboard interface',
  type: 'image', // image, video, document, other
  mimeType: 'image/png',
  url: 'https://picsum.photos/seed/med_Jk8pQ4nT6/1920/1080',
  thumbnail: 'https://picsum.photos/seed/med_Jk8pQ4nT6_thumb/300/200',
  size: 245678, // bytes
  dimensions: {
    width: 1920,
    height: 1080
  },
  uploadedBy: {
    id: 'stf_Ab3kL9mN2',
    name: 'Emma Johnson'
  },
  uploadedAt: '2024-01-05T14:20:00Z',
  tags: ['dashboard', 'screenshot', 'ui']
}
```

## 🔔 Notification Entities

```javascript
{
  id: 'ntf_Lm9kN3pQ7',
  type: 'order_placed', // order_placed, payment_received, user_registered, system_update, alert
  title: 'New Order Received',
  message: 'Order #ORD-2024-0156 has been placed',
  icon: 'shopping-cart', // icon name or null
  avatar: null, // user avatar URL or null
  link: '/orders/ord_Qw8eR5tY2',
  isRead: false,
  priority: 'normal', // low, normal, high, urgent
  createdAt: '2024-01-14T10:45:00Z',
  metadata: {
    orderId: 'ord_Qw8eR5tY2',
    amount: 97.10,
    customerName: 'Michael Brown'
  }
}
```

## ⚙️ Settings Entities

```javascript
// App Settings
{
  general: {
    siteName: 'Dashboard Pro',
    siteUrl: 'https://dashboard.example.com',
    logo: '/assets/logo.png',
    favicon: '/assets/favicon.ico',
    timezone: 'America/New_York',
    dateFormat: 'MM/DD/YYYY',
    currency: 'USD'
  },
  email: {
    fromName: 'Dashboard Pro',
    fromEmail: 'noreply@dashboard.example.com',
    smtpHost: 'smtp.example.com',
    smtpPort: 587,
    smtpSecure: true
  },
  security: {
    twoFactorAuth: true,
    sessionTimeout: 30, // minutes
    passwordPolicy: {
      minLength: 8,
      requireUppercase: true,
      requireNumbers: true,
      requireSpecial: true
    }
  },
  features: {
    maintenance: false,
    registration: true,
    socialLogin: true,
    apiAccess: true
  }
}

// User Permissions
{
  roles: [
    {
      id: 'rol_Ad4mN7kP2',
      name: 'Admin',
      description: 'Full system access',
      permissions: ['*'] // wildcard for all permissions
    },
    {
      id: 'rol_Mn6kP3qL8',
      name: 'Manager',
      description: 'Manage orders and customers',
      permissions: [
        'dashboard.view',
        'orders.view',
        'orders.edit',
        'customers.view',
        'customers.edit'
      ]
    }
  ],
  permissions: [
    { key: 'dashboard.view', name: 'View Dashboard', category: 'Dashboard' },
    { key: 'orders.view', name: 'View Orders', category: 'Orders' },
    { key: 'orders.edit', name: 'Edit Orders', category: 'Orders' },
    // ... all permissions
  ]
}
```

## 🛠️ Generator Utilities

### Core Generator Functions
```javascript
// utils/mock-data/generators.js

import { nanoid } from 'nanoid'

// ID Generation
export function generateId(prefix) {
  return `${prefix}_${nanoid(10)}`
}

// Random Selection
export function randomFrom(array) {
  return array[Math.floor(Math.random() * array.length)]
}

// Random Number
export function randomNumber(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min
}

// Random Boolean
export function randomBoolean(probability = 0.5) {
  return Math.random() < probability
}

// Date Generation
export function randomDate(start, end) {
  return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()))
}

// Past Date
export function pastDate(days) {
  const date = new Date()
  date.setDate(date.getDate() - days)
  return date.toISOString()
}

// Phone Number
export function generatePhone() {
  return `+1 (${randomNumber(200, 999)}) ${randomNumber(100, 999)}-${randomNumber(1000, 9999)}`
}

// Email
export function generateEmail(firstName, lastName, domain = 'example.com') {
  return `${firstName.toLowerCase()}.${lastName.toLowerCase()}@${domain}`
}

// Price
export function generatePrice(min = 10, max = 1000) {
  return Math.round((Math.random() * (max - min) + min) * 100) / 100
}

// Percentage
export function generatePercentage(min = -50, max = 50) {
  return Math.round((Math.random() * (max - min) + min) * 100) / 100
}
```

### Pre-defined Data Arrays
```javascript
// utils/mock-data/constants.js

export const FIRST_NAMES = [
  'Emma', 'Liam', 'Olivia', 'Noah', 'Ava', 'Ethan', 'Sophia', 'Mason',
  'Isabella', 'William', 'Mia', 'James', 'Charlotte', 'Benjamin', 'Amelia',
  'Lucas', 'Harper', 'Henry', 'Evelyn', 'Michael', 'Sarah', 'David',
  'Grace', 'Daniel', 'Victoria', 'Joseph', 'Lily', 'Samuel', 'Hannah',
  'John', 'Zoe', 'Ryan', 'Natalie', 'Nathan', 'Audrey', 'Christopher'
]

export const LAST_NAMES = [
  'Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller',
  'Davis', 'Rodriguez', 'Martinez', 'Lopez', 'Wilson', 'Anderson', 'Taylor',
  'Thomas', 'Moore', 'Jackson', 'Martin', 'Lee', 'Thompson', 'White',
  'Harris', 'Clark', 'Lewis', 'Robinson', 'Walker', 'Hall', 'Young',
  'Allen', 'King', 'Wright', 'Scott', 'Green', 'Baker', 'Adams'
]

export const COMPANY_NAMES = [
  'TechCorp Solutions', 'DataFlow Systems', 'CloudBase Inc', 'InnovateTech',
  'Digital Dynamics', 'WebScale Technologies', 'FutureNet Corp', 'SmartSoft',
  'NextGen Industries', 'Quantum Computing Co', 'AI Innovations', 'CyberTech',
  'Global Systems', 'MegaSoft Corporation', 'NetWorks Inc', 'InfoTech Pro'
]

export const DEPARTMENTS = [
  'Engineering', 'Sales', 'Marketing', 'Human Resources', 'Finance',
  'Operations', 'Customer Service', 'Product', 'Design', 'Legal'
]

export const PRODUCT_ADJECTIVES = [
  'Professional', 'Premium', 'Advanced', 'Ultimate', 'Essential',
  'Enterprise', 'Standard', 'Deluxe', 'Pro', 'Plus'
]

export const STREET_NAMES = [
  'Main St', 'Oak Ave', 'Park Blvd', 'Elm St', 'Washington Ave',
  'Market St', 'Broadway', 'First Ave', 'Second St', 'Maple Dr'
]

export const CITIES = [
  'New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix',
  'Philadelphia', 'San Antonio', 'San Diego', 'Dallas', 'San Jose',
  'Austin', 'Jacksonville', 'San Francisco', 'Seattle', 'Denver'
]

export const STATES = [
  'NY', 'CA', 'IL', 'TX', 'AZ', 'PA', 'FL', 'OH', 'NC', 'MI',
  'GA', 'VA', 'WA', 'MA', 'CO', 'OR', 'MD', 'MN', 'WI', 'NV'
]

export const STATUS_TYPES = {
  user: ['active', 'inactive', 'suspended'],
  order: ['pending', 'processing', 'completed', 'cancelled', 'refunded'],
  product: ['active', 'inactive', 'draft', 'archived'],
  ticket: ['open', 'in_progress', 'resolved', 'closed'],
  payment: ['pending', 'paid', 'failed', 'refunded']
}
```

## 📋 API Response Format

All mock API responses follow this structure:

```javascript
// Success Response
{
  success: true,
  data: [...] or {...}, // Array for lists, Object for single items
  pagination: {
    page: 1,
    limit: 20,
    total: 245,
    pages: 13,
    hasNext: true,
    hasPrev: false
  },
  timestamp: '2024-01-14T10:30:00Z'
}

// Error Response
{
  success: false,
  error: {
    code: 'VALIDATION_ERROR',
    message: 'Invalid input data',
    details: [
      { field: 'email', message: 'Invalid email format' }
    ]
  },
  timestamp: '2024-01-14T10:30:00Z'
}
```

## 🔄 Data Generation Examples

### Generate Users
```javascript
import { generateMockUsers } from '@/utils/mock-data/users'

// Generate 50 mixed users (staff, customers, vendors)
const users = generateMockUsers(50)

// Generate specific type
const customers = generateMockCustomers(100)
const staff = generateMockStaff(20)
const vendors = generateMockVendors(30)

// Get paginated data
const page1 = getMockUsersPage(1, 20) // page 1, 20 items per page
```

### Generate Orders
```javascript
import { generateMockOrders } from '@/utils/mock-data/orders'

// Generate orders with random customers and products
const orders = generateMockOrders(100)

// Generate orders for specific date range
const recentOrders = generateMockOrders(50, {
  startDate: new Date('2024-01-01'),
  endDate: new Date('2024-01-14')
})
```

### Generate Analytics
```javascript
import { generateDashboardMetrics } from '@/utils/mock-data/analytics'

// Generate current dashboard metrics
const metrics = generateDashboardMetrics()

// Generate chart data
const salesChart = generateSalesChartData(12) // 12 months
const trafficData = generateTrafficSourceData()
```

## 🎯 Best Practices

1. **Consistency**: Always use the same ID format and data structures
2. **Realism**: Generate plausible data (prices, dates, names)
3. **Performance**: Cache generated data when appropriate
4. **Relationships**: Maintain valid ID references between entities
5. **Pagination**: Support pagination for all list endpoints
6. **Timestamps**: Use ISO 8601 format for all dates
7. **Localization**: Design data structures to support multiple locales
8. **Validation**: Ensure generated data meets validation rules

## 📝 Notes

- All images use Lorem Picsum with seed-based generation for consistency
- Prices are stored as numbers (not cents) for simplicity
- Dates use ISO 8601 format (YYYY-MM-DDTHH:mm:ssZ)
- IDs are prefixed for easy identification and debugging
- Mock data is designed to transition easily to real API later