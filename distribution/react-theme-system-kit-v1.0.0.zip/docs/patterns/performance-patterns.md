# Performance Patterns

**Category**: React Performance Optimization  
**Purpose**: Preventing unnecessary re-renders and optimizing performance  
**Last Updated**: 2025-01-14

## 📚 Table of Contents

1. [Memoization Fundamentals](#memoization-fundamentals)
2. [React.memo Rules and Guidelines](#reactmemo-rules-and-guidelines)
3. [Elements vs Components Performance](#elements-vs-components-performance)
4. [Children as Props for Performance](#children-as-props-for-performance)
5. [Escaping Stale Closures](#escaping-stale-closures)

## Memoization Fundamentals

**Why**: JavaScript compares objects/arrays by reference, not value. This causes unnecessary re-renders when parent components re-render with new object references.

### The Problem

```javascript
// ❌ Problem: New object reference on every render
function Parent() {
  const [count, setCount] = useState(0)
  
  // This creates a NEW object on every render
  const config = { theme: 'dark', size: 'large' }
  
  return (
    <>
      <button onClick={() => setCount(count + 1)}>Count: {count}</button>
      <ExpensiveChild config={config} />
    </>
  )
}

// Child re-renders every time parent's count changes!
const ExpensiveChild = React.memo(({ config }) => {
  console.log('ExpensiveChild rendered')
  return <div>Theme: {config.theme}</div>
})
```

### The Solution

```javascript
// ✅ Solution: Memoize object references
function Parent() {
  const [count, setCount] = useState(0)
  
  // Only recreate if dependencies change
  const config = useMemo(
    () => ({ theme: 'dark', size: 'large' }),
    [] // Empty deps = never changes
  )
  
  return (
    <>
      <button onClick={() => setCount(count + 1)}>Count: {count}</button>
      <ExpensiveChild config={config} />
    </>
  )
}
```

## React.memo Rules and Guidelines

**Why**: React.memo only prevents re-renders when ALL props remain the same (by reference for objects/functions).

### Rule 1: Memoize Object/Array Props

```javascript
// Parent component
function TodoList() {
  const [todos, setTodos] = useState([])
  const [filter, setFilter] = useState('all')
  
  // Memoize filtered array
  const filteredTodos = useMemo(() => {
    if (filter === 'all') return todos
    return todos.filter(todo => todo.status === filter)
  }, [todos, filter])
  
  // Memoize callback
  const handleToggle = useCallback((id) => {
    setTodos(prev => prev.map(todo => 
      todo.id === id ? { ...todo, done: !todo.done } : todo
    ))
  }, [])
  
  return (
    <TodoListDisplay 
      todos={filteredTodos}
      onToggle={handleToggle}
    />
  )
}

// Child component
const TodoListDisplay = React.memo(({ todos, onToggle }) => {
  console.log('TodoListDisplay rendered')
  return (
    <ul>
      {todos.map(todo => (
        <TodoItem key={todo.id} todo={todo} onToggle={onToggle} />
      ))}
    </ul>
  )
})
```

### Rule 2: Don't Break Memoization Chain

```javascript
// ❌ Bad: Inline function breaks memoization
const TodoItem = React.memo(({ todo, onToggle }) => (
  <li onClick={() => onToggle(todo.id)}> {/* New function every render! */}
    {todo.text}
  </li>
))

// ✅ Good: Stable callback reference
const TodoItem = React.memo(({ todo, onToggle }) => {
  const handleClick = useCallback(() => {
    onToggle(todo.id)
  }, [todo.id, onToggle])
  
  return <li onClick={handleClick}>{todo.text}</li>
})
```

## Elements vs Components Performance

**Why**: React elements are just objects. When passed as props, they don't cause re-renders of memoized components.

```javascript
// ✅ Elements as props don't break memoization
function App() {
  const [count, setCount] = useState(0)
  
  return (
    <Layout
      sidebar={<Sidebar />}  // Element, not component call
      header={<Header count={count} />}
    >
      <button onClick={() => setCount(count + 1)}>Count: {count}</button>
    </Layout>
  )
}

const Layout = React.memo(({ sidebar, header, children }) => {
  console.log('Layout rendered') // Only on mount!
  return (
    <div className="layout">
      <div className="sidebar">{sidebar}</div>
      <div className="main">
        <div className="header">{header}</div>
        <div className="content">{children}</div>
      </div>
    </div>
  )
})
```

## Children as Props for Performance

**Why**: Components with children don't re-render when parent state changes, only the children do.

```javascript
// ❌ Problem: Everything re-renders
function BadScrollContainer() {
  const [scrollPos, setScrollPos] = useState(0)
  
  return (
    <div onScroll={(e) => setScrollPos(e.target.scrollTop)}>
      <ScrollIndicator position={scrollPos} />
      <ExpensiveList /> {/* Re-renders on every scroll! */}
    </div>
  )
}

// ✅ Solution: Move state down, use children
function GoodScrollContainer({ children }) {
  const [scrollPos, setScrollPos] = useState(0)
  
  return (
    <div onScroll={(e) => setScrollPos(e.target.scrollTop)}>
      <ScrollIndicator position={scrollPos} />
      {children} {/* Doesn't re-render! */}
    </div>
  )
}

// Usage
<GoodScrollContainer>
  <ExpensiveList /> {/* Stable, no re-renders from scroll */}
</GoodScrollContainer>
```

## Escaping Stale Closures

**Why**: Callbacks can "close over" stale values. Use refs to access fresh values without changing dependencies.

### The Stale Closure Problem

```javascript
// ❌ Problem: Stale closure
function Timer() {
  const [count, setCount] = useState(0)
  
  const logCount = useCallback(() => {
    console.log(count) // Always logs 0!
  }, []) // Empty deps = closure over initial count
  
  useEffect(() => {
    const id = setInterval(() => {
      setCount(c => c + 1)
      logCount() // Always logs 0, not current count
    }, 1000)
    return () => clearInterval(id)
  }, [logCount])
  
  return <div>Count: {count}</div>
}
```

### Solution 1: Ref Escape Hatch

```javascript
// ✅ Solution: Use ref for fresh values
function Timer() {
  const [count, setCount] = useState(0)
  const countRef = useRef(count)
  
  // Update ref on every render
  useEffect(() => {
    countRef.current = count
  })
  
  const logCount = useCallback(() => {
    console.log(countRef.current) // Always fresh!
  }, []) // Empty deps but fresh value
  
  useEffect(() => {
    const id = setInterval(() => {
      setCount(c => c + 1)
      logCount() // Logs current count
    }, 1000)
    return () => clearInterval(id)
  }, [logCount])
  
  return <div>Count: {count}</div>
}
```

### Solution 2: State Updater Pattern

```javascript
// ✅ Access fresh state in setState
function Counter() {
  const [count, setCount] = useState(0)
  
  const increment = useCallback(() => {
    setCount(currentCount => {
      console.log('Current count:', currentCount) // Always fresh
      return currentCount + 1
    })
  }, []) // No dependencies needed!
  
  return <ExpensiveChild onIncrement={increment} />
}
```

## Practical Guidelines

### When to Memoize

1. **Expensive Computations**
   ```javascript
   const expensiveResult = useMemo(() => {
     return calculatePrimeNumbers(limit)
   }, [limit])
   ```

2. **Stable References for Children**
   ```javascript
   const childProps = useMemo(() => ({
     data: processedData,
     config: { theme: 'dark' }
   }), [processedData])
   ```

3. **Callback Props**
   ```javascript
   const handleSubmit = useCallback((data) => {
     api.submit(data)
   }, []) // Stable for child memoization
   ```

### When NOT to Memoize

1. **Primitive Values** - Already compared by value
2. **Simple Computations** - Memoization overhead not worth it
3. **Single-Use Values** - No children to optimize

## Performance Checklist

- [ ] Memoize objects/arrays passed to memoized components
- [ ] Use useCallback for functions passed as props
- [ ] Consider moving state down to reduce re-render scope
- [ ] Use children pattern for stable content
- [ ] Profile before optimizing (React DevTools Profiler)
- [ ] Measure impact - not all memoization improves performance

## Related Patterns

- [Ref Patterns](ref-patterns.md) - Using refs for performance
- [State Management](state-management-patterns.md) - Efficient state design
- [Context Patterns](context-patterns.md) - Avoiding context re-renders