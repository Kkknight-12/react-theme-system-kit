# Configuration Patterns

**Category**: Flexible Component APIs  
**Purpose**: Creating components with flexible, extensible configuration  
**Last Updated**: 2025-01-14

## 📚 Table of Contents

1. [Elements as Props for Flexibility](#elements-as-props-for-flexibility)
2. [Modal with Flexible Sections](#modal-with-flexible-sections)
3. [Default Props with cloneElement](#default-props-with-cloneelement)
4. [Render Props for Complex Interactions](#render-props-for-complex-interactions)

## Elements as Props for Flexibility

**Why**: Allows complete control over component parts while maintaining consistent behavior and styling.

### Basic Pattern

```javascript
// Flexible Card component
function Card({ 
  header,      // React element
  footer,      // React element
  actions,     // React element
  children,
  className
}) {
  return (
    <div className={cn("rounded-lg border bg-white shadow-sm", className)}>
      {header && (
        <div className="border-b px-6 py-4">
          {header}
        </div>
      )}
      
      <div className="px-6 py-4">
        {children}
      </div>
      
      {(actions || footer) && (
        <div className="border-t px-6 py-4 flex items-center justify-between">
          <div>{footer}</div>
          <div className="flex gap-2">{actions}</div>
        </div>
      )}
    </div>
  )
}

// Usage - Maximum flexibility
<Card
  header={
    <div className="flex items-center justify-between">
      <h3 className="text-lg font-semibold">User Details</h3>
      <Badge variant="success">Active</Badge>
    </div>
  }
  footer={<span className="text-sm text-gray-500">Last updated: 2 hours ago</span>}
  actions={
    <>
      <Button variant="outline" size="sm">Cancel</Button>
      <Button variant="primary" size="sm">Save Changes</Button>
    </>
  }
>
  <UserForm user={user} />
</Card>
```

### Advanced: Component + Element Props

```javascript
// Table with flexible columns
function DataTable({ 
  data,
  columns,     // Array of column configs
  actions,     // Element for row actions
  emptyState,  // Element for empty data
  headerExtra, // Extra header content
}) {
  return (
    <div className="rounded-lg border">
      <div className="flex items-center justify-between p-4 border-b">
        <h3 className="font-semibold">Data Table</h3>
        {headerExtra}
      </div>
      
      {data.length === 0 ? (
        <div className="p-8 text-center">
          {emptyState || <EmptyState />}
        </div>
      ) : (
        <table className="w-full">
          <thead>
            <tr>
              {columns.map(col => (
                <th key={col.key} className="text-left p-4">
                  {col.header}
                </th>
              ))}
              {actions && <th className="text-right p-4">Actions</th>}
            </tr>
          </thead>
          <tbody>
            {data.map((row, i) => (
              <tr key={row.id || i} className="border-t">
                {columns.map(col => (
                  <td key={col.key} className="p-4">
                    {col.render ? col.render(row[col.key], row) : row[col.key]}
                  </td>
                ))}
                {actions && (
                  <td className="p-4 text-right">
                    {typeof actions === 'function' ? actions(row) : actions}
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  )
}

// Usage
<DataTable
  data={users}
  columns={[
    { key: 'name', header: 'Name' },
    { 
      key: 'status', 
      header: 'Status',
      render: (status) => <Badge variant={status}>{status}</Badge>
    },
    { 
      key: 'lastActive', 
      header: 'Last Active',
      render: (date) => formatRelativeTime(date)
    }
  ]}
  actions={(user) => (
    <DropdownMenu>
      <DropdownMenuTrigger>
        <Button variant="ghost" size="sm">
          <MoreVerticalIcon className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent>
        <DropdownMenuItem onClick={() => editUser(user)}>Edit</DropdownMenuItem>
        <DropdownMenuItem onClick={() => deleteUser(user)}>Delete</DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )}
  headerExtra={
    <Button size="sm" onClick={handleExport}>
      <DownloadIcon className="h-4 w-4 mr-2" />
      Export
    </Button>
  }
  emptyState={
    <EmptyState 
      icon={<UsersIcon />}
      title="No users found"
      description="Get started by inviting your first user"
      action={<Button>Invite User</Button>}
    />
  }
/>
```

## Modal with Flexible Sections

**Why**: Modals need different layouts and content. Element props provide maximum flexibility.

```javascript
function Modal({
  isOpen,
  onClose,
  title,          // String or element
  description,    // String or element  
  footer,         // Element
  closeButton = true,
  size = 'md',
  children
}) {
  if (!isOpen) return null
  
  return (
    <div className="fixed inset-0 z-50">
      <div className="fixed inset-0 bg-black/50" onClick={onClose} />
      
      <div className={cn(
        "fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2",
        "bg-white rounded-lg shadow-xl",
        "w-full max-h-[90vh] overflow-hidden",
        sizes[size]
      )}>
        {/* Header */}
        <div className="flex items-start justify-between p-6 border-b">
          <div className="flex-1">
            {typeof title === 'string' ? (
              <h2 className="text-lg font-semibold">{title}</h2>
            ) : title}
            
            {description && (
              typeof description === 'string' ? (
                <p className="mt-1 text-sm text-gray-600">{description}</p>
              ) : description
            )}
          </div>
          
          {closeButton && (
            <button 
              onClick={onClose}
              className="ml-4 text-gray-400 hover:text-gray-600"
            >
              <XIcon className="h-5 w-5" />
            </button>
          )}
        </div>
        
        {/* Body */}
        <div className="p-6 overflow-auto max-h-[60vh]">
          {children}
        </div>
        
        {/* Footer */}
        {footer && (
          <div className="flex items-center justify-end gap-3 p-6 border-t bg-gray-50">
            {footer}
          </div>
        )}
      </div>
    </div>
  )
}

// Usage Examples

// Simple confirmation
<Modal
  isOpen={showDelete}
  onClose={() => setShowDelete(false)}
  title="Delete User"
  description="This action cannot be undone."
  footer={
    <>
      <Button variant="outline" onClick={() => setShowDelete(false)}>
        Cancel
      </Button>
      <Button variant="danger" onClick={handleDelete}>
        Delete
      </Button>
    </>
  }
>
  Are you sure you want to delete {user.name}?
</Modal>

// Complex form
<Modal
  isOpen={showEdit}
  onClose={() => setShowEdit(false)}
  size="lg"
  title={
    <div className="flex items-center gap-3">
      <UserIcon className="h-5 w-5 text-gray-500" />
      <span>Edit User Profile</span>
    </div>
  }
  description={
    <Alert variant="info" className="mt-2">
      Changes will be reflected immediately
    </Alert>
  }
  footer={
    <>
      <span className="text-sm text-gray-500 mr-auto">
        Last updated: {formatDate(user.updatedAt)}
      </span>
      <Button variant="outline" onClick={() => setShowEdit(false)}>
        Cancel
      </Button>
      <Button onClick={handleSave} loading={saving}>
        Save Changes
      </Button>
    </>
  }
>
  <UserEditForm user={user} />
</Modal>
```

## Default Props with cloneElement

**Why**: Inject props into children elements while allowing overrides. Useful for consistent styling or behavior.

```javascript
// Button Group with default props
function ButtonGroup({ children, size = 'md', variant = 'outline' }) {
  return (
    <div className="flex -space-x-px">
      {React.Children.map(children, (child, index) => {
        if (!React.isValidElement(child)) return child
        
        return React.cloneElement(child, {
          size,      // Default size
          variant,   // Default variant
          className: cn(
            child.props.className,
            index === 0 && "rounded-r-none",
            index === React.Children.count(children) - 1 && "rounded-l-none",
            index !== 0 && index !== React.Children.count(children) - 1 && "rounded-none",
            "focus:z-10" // Ensure focused button is on top
          ),
          ...child.props // Allow overrides
        })
      })}
    </div>
  )
}

// Usage
<ButtonGroup size="sm" variant="secondary">
  <Button onClick={handlePrev}>Previous</Button>
  <Button onClick={handleToday}>Today</Button>
  <Button onClick={handleNext}>Next</Button>
</ButtonGroup>

// Form Field wrapper
function FormField({ children, error, required }) {
  return (
    <div className="space-y-2">
      {React.Children.map(children, child => {
        // Inject props into Label components
        if (child.type === Label) {
          return React.cloneElement(child, {
            required,
            className: cn(child.props.className, error && "text-red-600")
          })
        }
        
        // Inject props into Input/Select/Textarea
        if (child.type === Input || child.type === Select || child.type === Textarea) {
          return React.cloneElement(child, {
            'aria-invalid': !!error,
            'aria-describedby': error ? `${child.props.id}-error` : undefined,
            className: cn(
              child.props.className,
              error && "border-red-500 focus:ring-red-500"
            )
          })
        }
        
        return child
      })}
      
      {error && (
        <p className="text-sm text-red-600" id={`${children.props?.id}-error`}>
          {error}
        </p>
      )}
    </div>
  )
}

// Usage
<FormField error={errors.email} required>
  <Label htmlFor="email">Email Address</Label>
  <Input 
    id="email" 
    type="email" 
    value={email} 
    onChange={(e) => setEmail(e.target.value)}
  />
</FormField>
```

## Render Props for Complex Interactions

**Why**: Share complex interaction logic while allowing full control over rendering.

```javascript
// Dropdown with render prop
function Dropdown({ trigger, children }) {
  const [isOpen, setIsOpen] = useState(false)
  const dropdownRef = useRef(null)
  
  // Close on outside click
  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false)
      }
    }
    
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])
  
  return (
    <div ref={dropdownRef} className="relative">
      {trigger({ isOpen, toggle: () => setIsOpen(!isOpen) })}
      
      {isOpen && (
        <div className="absolute top-full mt-2 right-0 z-50">
          {typeof children === 'function' 
            ? children({ close: () => setIsOpen(false) })
            : children
          }
        </div>
      )}
    </div>
  )
}

// Usage with render props
<Dropdown
  trigger={({ isOpen, toggle }) => (
    <Button onClick={toggle}>
      Options
      <ChevronDownIcon 
        className={cn("ml-2 h-4 w-4 transition-transform", isOpen && "rotate-180")}
      />
    </Button>
  )}
>
  {({ close }) => (
    <Card className="w-48 p-1">
      <button 
        className="w-full text-left px-3 py-2 hover:bg-gray-100 rounded"
        onClick={() => {
          handleEdit()
          close()
        }}
      >
        Edit
      </button>
      <button 
        className="w-full text-left px-3 py-2 hover:bg-gray-100 rounded text-red-600"
        onClick={() => {
          handleDelete()
          close()
        }}
      >
        Delete
      </button>
    </Card>
  )}
</Dropdown>

// Sortable List with render prop
function SortableList({ items, onReorder, renderItem }) {
  const [draggedItem, setDraggedItem] = useState(null)
  const [draggedOverItem, setDraggedOverItem] = useState(null)
  
  const handleDragEnd = () => {
    if (draggedItem !== null && draggedOverItem !== null) {
      const newItems = [...items]
      const draggedItemContent = newItems[draggedItem]
      newItems.splice(draggedItem, 1)
      newItems.splice(draggedOverItem, 0, draggedItemContent)
      onReorder(newItems)
    }
    setDraggedItem(null)
    setDraggedOverItem(null)
  }
  
  return (
    <div className="space-y-2">
      {items.map((item, index) => (
        <div
          key={item.id}
          draggable
          onDragStart={() => setDraggedItem(index)}
          onDragEnter={() => setDraggedOverItem(index)}
          onDragEnd={handleDragEnd}
          className={cn(
            "cursor-move",
            draggedItem === index && "opacity-50"
          )}
        >
          {renderItem({
            item,
            index,
            isDragging: draggedItem === index,
            isDraggedOver: draggedOverItem === index
          })}
        </div>
      ))}
    </div>
  )
}

// Usage
<SortableList
  items={tasks}
  onReorder={setTasks}
  renderItem={({ item, isDragging, isDraggedOver }) => (
    <Card 
      className={cn(
        "p-4 transition-all",
        isDragging && "shadow-lg",
        isDraggedOver && "border-blue-500"
      )}
    >
      <div className="flex items-center gap-3">
        <GripVerticalIcon className="h-4 w-4 text-gray-400" />
        <span>{item.title}</span>
      </div>
    </Card>
  )}
/>
```

## Best Practices

1. **Type Safety**: Define clear prop types for element props
2. **Defaults**: Provide sensible default components
3. **Composition**: Allow both elements and render functions
4. **Documentation**: Clearly document what each prop accepts
5. **Examples**: Provide usage examples for complex patterns

## Related Patterns

- [Composition Patterns](composition-patterns.md) - Component composition strategies
- [UI Component Patterns](ui-component-patterns.md) - Common UI implementations
- [Performance Patterns](performance-patterns.md) - Optimizing flexible components