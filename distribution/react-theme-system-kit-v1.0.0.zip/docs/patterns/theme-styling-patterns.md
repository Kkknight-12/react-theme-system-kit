# Theme & Styling Patterns

**Category**: Theming and Responsive Design  
**Purpose**: Dynamic theming, responsive patterns, and CSS-in-JS strategies  
**Last Updated**: 2025-01-14

## 📚 Table of Contents

1. [Dynamic Theme Switching](#dynamic-theme-switching)
2. [Responsive Patterns](#responsive-patterns)
3. [CSS-in-JS Patterns](#css-in-js-patterns)

## Dynamic Theme Switching

**Why**: Allow users to customize appearance and support dark mode for better UX.

### Complete Theme System

```javascript
// Theme definitions
const themes = {
  light: {
    name: 'light',
    colors: {
      background: '#ffffff',
      surface: '#f8f9fa',
      primary: '#007bff',
      primaryHover: '#0056b3',
      text: '#212529',
      textMuted: '#6c757d',
      border: '#dee2e6',
      error: '#dc3545',
      success: '#28a745',
      warning: '#ffc107'
    },
    shadows: {
      sm: '0 1px 2px rgba(0,0,0,0.05)',
      md: '0 4px 6px rgba(0,0,0,0.07)',
      lg: '0 10px 15px rgba(0,0,0,0.1)'
    }
  },
  dark: {
    name: 'dark',
    colors: {
      background: '#1a1a1a',
      surface: '#2d2d2d',
      primary: '#0d6efd',
      primaryHover: '#0b5ed7',
      text: '#f8f9fa',
      textMuted: '#adb5bd',
      border: '#495057',
      error: '#f8d7da',
      success: '#d1e7dd',
      warning: '#fff3cd'
    },
    shadows: {
      sm: '0 1px 2px rgba(0,0,0,0.2)',
      md: '0 4px 6px rgba(0,0,0,0.3)',
      lg: '0 10px 15px rgba(0,0,0,0.4)'
    }
  }
}

// Theme context with system preference detection
const ThemeContext = createContext()

function ThemeProvider({ children }) {
  const [themeName, setThemeName] = useState(() => {
    // Check localStorage first
    const saved = localStorage.getItem('theme')
    if (saved && themes[saved]) return saved
    
    // Check system preference
    if (window.matchMedia?.('(prefers-color-scheme: dark)').matches) {
      return 'dark'
    }
    
    return 'light'
  })
  
  const theme = themes[themeName]
  
  // Update CSS variables
  useEffect(() => {
    const root = document.documentElement
    
    // Set theme colors as CSS variables
    Object.entries(theme.colors).forEach(([key, value]) => {
      root.style.setProperty(`--color-${key}`, value)
    })
    
    // Set shadows
    Object.entries(theme.shadows).forEach(([key, value]) => {
      root.style.setProperty(`--shadow-${key}`, value)
    })
    
    // Set theme class on body
    document.body.className = `theme-${themeName}`
    
    // Save preference
    localStorage.setItem('theme', themeName)
  }, [theme, themeName])
  
  // Listen for system theme changes
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)')
    
    const handleChange = (e) => {
      // Only auto-switch if user hasn't set a preference
      if (!localStorage.getItem('theme')) {
        setThemeName(e.matches ? 'dark' : 'light')
      }
    }
    
    mediaQuery.addEventListener('change', handleChange)
    return () => mediaQuery.removeEventListener('change', handleChange)
  }, [])
  
  const toggleTheme = () => {
    setThemeName(prev => prev === 'light' ? 'dark' : 'light')
  }
  
  const setTheme = (name) => {
    if (themes[name]) {
      setThemeName(name)
    }
  }
  
  return (
    <ThemeContext.Provider value={{ theme, themeName, toggleTheme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  )
}

// Hook for using theme
function useTheme() {
  const context = useContext(ThemeContext)
  if (!context) {
    throw new Error('useTheme must be used within ThemeProvider')
  }
  return context
}

// Theme toggle component
function ThemeToggle() {
  const { themeName, toggleTheme } = useTheme()
  
  return (
    <button
      onClick={toggleTheme}
      className="p-2 rounded-lg hover:bg-surface transition-colors"
      aria-label="Toggle theme"
    >
      {themeName === 'light' ? (
        <MoonIcon className="h-5 w-5" />
      ) : (
        <SunIcon className="h-5 w-5" />
      )}
    </button>
  )
}
```

### CSS Variables Integration

```css
/* Global CSS file */
:root {
  /* Colors will be set by JavaScript */
  --color-background: #ffffff;
  --color-surface: #f8f9fa;
  --color-primary: #007bff;
  --color-text: #212529;
  
  /* Shadows */
  --shadow-sm: 0 1px 2px rgba(0,0,0,0.05);
  --shadow-md: 0 4px 6px rgba(0,0,0,0.07);
  
  /* Transitions */
  --transition-fast: 150ms ease-in-out;
  --transition-base: 250ms ease-in-out;
}

/* Utility classes using CSS variables */
.bg-background { background-color: var(--color-background); }
.bg-surface { background-color: var(--color-surface); }
.bg-primary { background-color: var(--color-primary); }
.text-primary { color: var(--color-text); }
.text-muted { color: var(--color-textMuted); }

/* Component with theme-aware styles */
.card {
  background-color: var(--color-surface);
  color: var(--color-text);
  border: 1px solid var(--color-border);
  box-shadow: var(--shadow-sm);
  transition: box-shadow var(--transition-base);
}

.card:hover {
  box-shadow: var(--shadow-md);
}

/* Dark mode specific overrides */
.theme-dark {
  color-scheme: dark;
}

.theme-dark img {
  opacity: 0.9;
}

.theme-dark .card {
  background-image: linear-gradient(
    rgba(255, 255, 255, 0.05),
    rgba(255, 255, 255, 0.05)
  );
}
```

### Theme-aware Components

```javascript
// Themed button component
function Button({ variant = 'primary', size = 'md', children, ...props }) {
  const { theme } = useTheme()
  
  const styles = {
    base: "font-medium rounded-lg transition-all focus:outline-none focus:ring-2",
    size: {
      sm: "px-3 py-1.5 text-sm",
      md: "px-4 py-2",
      lg: "px-6 py-3 text-lg"
    },
    variant: {
      primary: `bg-primary text-white hover:opacity-90 focus:ring-primary/50`,
      secondary: `bg-surface text-primary border border-border hover:bg-opacity-80`,
      ghost: `text-primary hover:bg-surface`
    }
  }
  
  return (
    <button
      className={cn(
        styles.base,
        styles.size[size],
        styles.variant[variant]
      )}
      style={{
        '--tw-ring-color': theme.colors.primary + '80'
      }}
      {...props}
    >
      {children}
    </button>
  )
}

// Chart with dynamic theme colors
function ThemedChart({ data }) {
  const { theme } = useTheme()
  
  const chartOptions = {
    theme: {
      mode: theme.name,
      palette: 'palette1',
      monochrome: {
        enabled: false,
        color: theme.colors.primary
      }
    },
    chart: {
      background: 'transparent',
      foreColor: theme.colors.text
    },
    grid: {
      borderColor: theme.colors.border
    },
    tooltip: {
      theme: theme.name,
      style: {
        fontSize: '12px',
        fontFamily: 'inherit'
      }
    }
  }
  
  return <ApexChart options={chartOptions} series={data} />
}
```

## Responsive Patterns

**Why**: Create layouts that work seamlessly across all device sizes.

### Responsive Hook

```javascript
// Custom hook for responsive design
function useResponsive() {
  const [windowSize, setWindowSize] = useState({
    width: window.innerWidth,
    height: window.innerHeight
  })
  
  useEffect(() => {
    const handleResize = debounce(() => {
      setWindowSize({
        width: window.innerWidth,
        height: window.innerHeight
      })
    }, 150)
    
    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [])
  
  const breakpoints = {
    xs: windowSize.width < 640,
    sm: windowSize.width >= 640 && windowSize.width < 768,
    md: windowSize.width >= 768 && windowSize.width < 1024,
    lg: windowSize.width >= 1024 && windowSize.width < 1280,
    xl: windowSize.width >= 1280,
    '2xl': windowSize.width >= 1536
  }
  
  const isMobile = windowSize.width < 768
  const isTablet = windowSize.width >= 768 && windowSize.width < 1024
  const isDesktop = windowSize.width >= 1024
  
  return {
    windowSize,
    breakpoints,
    isMobile,
    isTablet,
    isDesktop,
    // Utility function
    isBreakpoint: (bp) => breakpoints[bp]
  }
}

// Usage in components
function ResponsiveLayout({ children }) {
  const { isMobile, isTablet, isDesktop } = useResponsive()
  
  if (isMobile) {
    return <MobileLayout>{children}</MobileLayout>
  }
  
  if (isTablet) {
    return <TabletLayout>{children}</TabletLayout>
  }
  
  return <DesktopLayout>{children}</DesktopLayout>
}
```

### Responsive Grid System

```javascript
// Responsive grid component
function Grid({ children, cols = 1, gap = 4, className }) {
  const colsClasses = {
    1: 'grid-cols-1',
    2: 'grid-cols-1 sm:grid-cols-2',
    3: 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3',
    4: 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-4',
    6: 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-6',
    12: 'grid-cols-4 sm:grid-cols-6 lg:grid-cols-12',
    // Responsive object syntax
    responsive: (cols) => {
      const classes = []
      if (cols.xs) classes.push(`grid-cols-${cols.xs}`)
      if (cols.sm) classes.push(`sm:grid-cols-${cols.sm}`)
      if (cols.md) classes.push(`md:grid-cols-${cols.md}`)
      if (cols.lg) classes.push(`lg:grid-cols-${cols.lg}`)
      if (cols.xl) classes.push(`xl:grid-cols-${cols.xl}`)
      return classes.join(' ')
    }
  }
  
  const gapClasses = {
    2: 'gap-2',
    4: 'gap-4',
    6: 'gap-6',
    8: 'gap-8'
  }
  
  const gridCols = typeof cols === 'object' 
    ? colsClasses.responsive(cols)
    : colsClasses[cols] || colsClasses[1]
  
  return (
    <div className={cn(
      'grid',
      gridCols,
      gapClasses[gap],
      className
    )}>
      {children}
    </div>
  )
}

// Usage
<Grid cols={{ xs: 1, sm: 2, md: 3, lg: 4 }} gap={6}>
  {products.map(product => (
    <ProductCard key={product.id} product={product} />
  ))}
</Grid>
```

### Responsive Navigation

```javascript
function ResponsiveNav({ items }) {
  const { isMobile } = useResponsive()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  
  // Close menu on route change
  const location = useLocation()
  useEffect(() => {
    setMobileMenuOpen(false)
  }, [location])
  
  if (isMobile) {
    return (
      <>
        {/* Mobile menu button */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="p-2 rounded-lg hover:bg-surface"
          aria-label="Toggle menu"
        >
          {mobileMenuOpen ? (
            <XIcon className="h-6 w-6" />
          ) : (
            <MenuIcon className="h-6 w-6" />
          )}
        </button>
        
        {/* Mobile menu */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'tween', duration: 0.3 }}
              className="fixed inset-y-0 right-0 w-64 bg-surface shadow-lg z-50"
            >
              <nav className="p-4">
                {items.map(item => (
                  <Link
                    key={item.path}
                    to={item.path}
                    className="block py-2 px-4 rounded hover:bg-background"
                  >
                    {item.label}
                  </Link>
                ))}
              </nav>
            </motion.div>
          )}
        </AnimatePresence>
        
        {/* Overlay */}
        {mobileMenuOpen && (
          <div
            className="fixed inset-0 bg-black/50 z-40"
            onClick={() => setMobileMenuOpen(false)}
          />
        )}
      </>
    )
  }
  
  // Desktop navigation
  return (
    <nav className="flex gap-6">
      {items.map(item => (
        <Link
          key={item.path}
          to={item.path}
          className="text-sm font-medium hover:text-primary transition-colors"
        >
          {item.label}
        </Link>
      ))}
    </nav>
  )
}
```

## CSS-in-JS Patterns

**Why**: Dynamic styling based on props and state with type safety.

### Styled Components Pattern

```javascript
// Using @emotion/styled or styled-components
import styled from '@emotion/styled'

// Basic styled component
const Button = styled.button`
  padding: ${props => props.size === 'large' ? '12px 24px' : '8px 16px'};
  background-color: ${props => props.variant === 'primary' 
    ? props.theme.colors.primary 
    : 'transparent'};
  color: ${props => props.variant === 'primary' 
    ? 'white' 
    : props.theme.colors.primary};
  border: 2px solid ${props => props.theme.colors.primary};
  border-radius: 8px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s ease;
  
  &:hover {
    opacity: 0.9;
    transform: translateY(-1px);
  }
  
  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
`

// Dynamic styles with props
const Card = styled.div`
  background: ${props => props.theme.colors.surface};
  border-radius: ${props => props.rounded ? '16px' : '8px'};
  padding: ${props => props.compact ? '16px' : '24px'};
  box-shadow: ${props => props.elevated 
    ? props.theme.shadows.lg 
    : props.theme.shadows.sm};
  
  ${props => props.clickable && `
    cursor: pointer;
    transition: transform 0.2s ease, box-shadow 0.2s ease;
    
    &:hover {
      transform: translateY(-2px);
      box-shadow: ${props.theme.shadows.xl};
    }
  `}
`
```

### CSS Modules Pattern

```javascript
// Button.module.css
.button {
  padding: 8px 16px;
  border-radius: 8px;
  font-weight: 500;
  transition: all 0.2s ease;
  cursor: pointer;
}

.primary {
  background-color: var(--color-primary);
  color: white;
  border: none;
}

.secondary {
  background-color: transparent;
  color: var(--color-primary);
  border: 2px solid var(--color-primary);
}

.large {
  padding: 12px 24px;
  font-size: 1.125rem;
}

.button:hover {
  opacity: 0.9;
  transform: translateY(-1px);
}

.button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

// Button.jsx
import styles from './Button.module.css'

function Button({ variant = 'primary', size = 'medium', children, ...props }) {
  return (
    <button
      className={cn(
        styles.button,
        styles[variant],
        size === 'large' && styles.large
      )}
      {...props}
    >
      {children}
    </button>
  )
}
```

### Tailwind with Component Variants

```javascript
// Using class-variance-authority (CVA)
import { cva } from 'class-variance-authority'

const buttonVariants = cva(
  // Base styles
  "inline-flex items-center justify-center rounded-md font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        primary: "bg-primary text-white hover:bg-primary/90",
        secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
        destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
        outline: "border border-input hover:bg-accent hover:text-accent-foreground",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "underline-offset-4 hover:underline text-primary"
      },
      size: {
        sm: "h-8 px-3 text-xs",
        md: "h-10 px-4 py-2",
        lg: "h-12 px-8 text-lg",
        icon: "h-10 w-10"
      }
    },
    defaultVariants: {
      variant: "primary",
      size: "md"
    }
  }
)

function Button({ className, variant, size, ...props }) {
  return (
    <button
      className={cn(buttonVariants({ variant, size, className }))}
      {...props}
    />
  )
}

// Compound variants
const alertVariants = cva(
  "relative w-full rounded-lg border p-4",
  {
    variants: {
      variant: {
        default: "bg-background text-foreground",
        destructive: "border-destructive/50 text-destructive dark:border-destructive"
      }
    },
    compoundVariants: [
      {
        variant: "destructive",
        className: "[&>svg]:text-destructive"
      }
    ]
  }
)
```

### Dynamic Styles with CSS Variables

```javascript
// Component with dynamic CSS variables
function DynamicCard({ color, radius = 8, children }) {
  const style = {
    '--card-color': color,
    '--card-radius': `${radius}px`
  }
  
  return (
    <div className="dynamic-card" style={style}>
      {children}
    </div>
  )
}

// CSS
.dynamic-card {
  background: var(--card-color, var(--color-surface));
  border-radius: var(--card-radius, 8px);
  padding: 1.5rem;
  box-shadow: 0 0 0 1px var(--card-color, transparent);
  
  /* Use the dynamic color for child elements */
  & .card-title {
    color: var(--card-color);
  }
  
  & .card-icon {
    fill: var(--card-color);
  }
}

// Advanced: Gradient generator
function GradientText({ from, to, angle = 45, children }) {
  const style = {
    '--gradient-from': from,
    '--gradient-to': to,
    '--gradient-angle': `${angle}deg`
  }
  
  return (
    <span className="gradient-text" style={style}>
      {children}
    </span>
  )
}

// CSS
.gradient-text {
  background: linear-gradient(
    var(--gradient-angle),
    var(--gradient-from),
    var(--gradient-to)
  );
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}
```

## Best Practices

1. **System Preferences**: Respect user's OS theme preference
2. **Performance**: Use CSS variables for theme switching (no re-renders)
3. **Accessibility**: Ensure sufficient contrast ratios in all themes
4. **Mobile First**: Design for mobile, enhance for desktop
5. **Consistent Spacing**: Use a spacing scale (4, 8, 16, 24, 32, etc.)
6. **Type Safety**: Use TypeScript for theme objects and props

## Related Patterns

- [UI Component Patterns](ui-component-patterns.md) - Component implementation
- [Performance Patterns](performance-patterns.md) - Optimizing theme switches
- [Configuration Patterns](configuration-patterns.md) - Theme configuration