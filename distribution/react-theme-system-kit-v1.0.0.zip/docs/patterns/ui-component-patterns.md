# UI Component Patterns

**Category**: Common UI Components  
**Purpose**: Battle-tested patterns for frequently used UI components  
**Last Updated**: 2025-01-14

## 📚 Table of Contents

1. [Modal/Dialog Pattern with Accessibility](#modaldialog-pattern-with-accessibility)
2. [Advanced Table Pattern](#advanced-table-pattern)
3. [List with Filters Pattern](#list-with-filters-pattern)

## Modal/Dialog Pattern with Accessibility

**Why**: Modals need proper focus management, keyboard navigation, and screen reader support.

### Complete Modal Implementation

```javascript
import { useEffect, useRef } from 'react'
import { createPortal } from 'react-dom'

function Modal({ 
  isOpen, 
  onClose, 
  title,
  children,
  size = 'md',
  closeOnOverlayClick = true,
  closeOnEsc = true
}) {
  const modalRef = useRef(null)
  const previousActiveElement = useRef(null)
  
  // Focus management
  useEffect(() => {
    if (isOpen) {
      // Store current focus
      previousActiveElement.current = document.activeElement
      
      // Focus first focusable element or modal itself
      const focusableElements = modalRef.current?.querySelectorAll(
        'a[href], button, textarea, input, select, [tabindex]:not([tabindex="-1"])'
      )
      
      if (focusableElements?.length > 0) {
        focusableElements[0].focus()
      } else {
        modalRef.current?.focus()
      }
    } else {
      // Restore focus
      previousActiveElement.current?.focus()
    }
  }, [isOpen])
  
  // Keyboard navigation
  useEffect(() => {
    if (!isOpen || !closeOnEsc) return
    
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') {
        onClose()
      }
      
      // Tab trap
      if (e.key === 'Tab' && modalRef.current) {
        const focusableElements = modalRef.current.querySelectorAll(
          'a[href], button, textarea, input, select, [tabindex]:not([tabindex="-1"])'
        )
        
        const firstElement = focusableElements[0]
        const lastElement = focusableElements[focusableElements.length - 1]
        
        if (e.shiftKey && document.activeElement === firstElement) {
          e.preventDefault()
          lastElement.focus()
        } else if (!e.shiftKey && document.activeElement === lastElement) {
          e.preventDefault()
          firstElement.focus()
        }
      }
    }
    
    document.addEventListener('keydown', handleKeyDown)
    return () => document.removeEventListener('keydown', handleKeyDown)
  }, [isOpen, onClose, closeOnEsc])
  
  // Prevent body scroll
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = ''
    }
    
    return () => {
      document.body.style.overflow = ''
    }
  }, [isOpen])
  
  if (!isOpen) return null
  
  const sizes = {
    sm: 'max-w-md',
    md: 'max-w-lg',
    lg: 'max-w-2xl',
    xl: 'max-w-4xl',
    full: 'max-w-full mx-4'
  }
  
  return createPortal(
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      aria-labelledby="modal-title"
      aria-modal="true"
      role="dialog"
    >
      {/* Overlay */}
      <div 
        className="fixed inset-0 bg-black/50 transition-opacity"
        onClick={closeOnOverlayClick ? onClose : undefined}
        aria-hidden="true"
      />
      
      {/* Modal */}
      <div
        ref={modalRef}
        className={cn(
          "relative bg-white rounded-lg shadow-xl",
          "w-full overflow-hidden",
          "animate-in fade-in zoom-in-95 duration-200",
          sizes[size]
        )}
        tabIndex={-1}
      >
        {/* Header */}
        <div className="flex items-start justify-between p-6 border-b">
          <h2 id="modal-title" className="text-xl font-semibold">
            {title}
          </h2>
          <button
            onClick={onClose}
            className="ml-4 text-gray-400 hover:text-gray-600 transition-colors"
            aria-label="Close modal"
          >
            <XIcon className="h-5 w-5" />
          </button>
        </div>
        
        {/* Body */}
        <div className="p-6 overflow-auto max-h-[60vh]">
          {children}
        </div>
      </div>
    </div>,
    document.body
  )
}

// Usage with confirmation dialog
function DeleteConfirmModal({ isOpen, onClose, onConfirm, itemName }) {
  const [isDeleting, setIsDeleting] = useState(false)
  
  const handleDelete = async () => {
    setIsDeleting(true)
    try {
      await onConfirm()
      onClose()
    } catch (error) {
      console.error('Delete failed:', error)
    } finally {
      setIsDeleting(false)
    }
  }
  
  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Delete Confirmation"
      size="sm"
    >
      <p className="text-gray-600 mb-6">
        Are you sure you want to delete <strong>{itemName}</strong>? 
        This action cannot be undone.
      </p>
      
      <div className="flex gap-3 justify-end">
        <Button 
          variant="outline" 
          onClick={onClose}
          disabled={isDeleting}
        >
          Cancel
        </Button>
        <Button 
          variant="danger" 
          onClick={handleDelete}
          loading={isDeleting}
        >
          Delete
        </Button>
      </div>
    </Modal>
  )
}
```

## Advanced Table Pattern

**Why**: Tables need sorting, filtering, pagination, and responsive design.

### Full-Featured Data Table

```javascript
function DataTable({
  data,
  columns,
  searchable = true,
  sortable = true,
  paginated = true,
  pageSize = 10,
  onRowClick,
  rowActions,
  bulkActions,
  emptyMessage = "No data found"
}) {
  const [search, setSearch] = useState('')
  const [sortConfig, setSortConfig] = useState({ key: null, direction: null })
  const [currentPage, setCurrentPage] = useState(1)
  const [selectedRows, setSelectedRows] = useState(new Set())
  
  // Filter data
  const filteredData = useMemo(() => {
    if (!search) return data
    
    return data.filter(row => 
      columns.some(col => {
        const value = row[col.key]
        return value?.toString().toLowerCase().includes(search.toLowerCase())
      })
    )
  }, [data, columns, search])
  
  // Sort data
  const sortedData = useMemo(() => {
    if (!sortConfig.key) return filteredData
    
    return [...filteredData].sort((a, b) => {
      const aValue = a[sortConfig.key]
      const bValue = b[sortConfig.key]
      
      if (aValue === bValue) return 0
      
      const comparison = aValue < bValue ? -1 : 1
      return sortConfig.direction === 'asc' ? comparison : -comparison
    })
  }, [filteredData, sortConfig])
  
  // Paginate data
  const paginatedData = useMemo(() => {
    if (!paginated) return sortedData
    
    const startIndex = (currentPage - 1) * pageSize
    return sortedData.slice(startIndex, startIndex + pageSize)
  }, [sortedData, currentPage, pageSize, paginated])
  
  const totalPages = Math.ceil(sortedData.length / pageSize)
  
  // Handlers
  const handleSort = (key) => {
    if (!sortable) return
    
    setSortConfig(prev => ({
      key,
      direction: 
        prev.key === key && prev.direction === 'asc' ? 'desc' : 'asc'
    }))
  }
  
  const handleSelectAll = () => {
    if (selectedRows.size === paginatedData.length) {
      setSelectedRows(new Set())
    } else {
      setSelectedRows(new Set(paginatedData.map(row => row.id)))
    }
  }
  
  const handleSelectRow = (rowId) => {
    const newSelected = new Set(selectedRows)
    if (newSelected.has(rowId)) {
      newSelected.delete(rowId)
    } else {
      newSelected.add(rowId)
    }
    setSelectedRows(newSelected)
  }
  
  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        {searchable && (
          <div className="relative">
            <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="search"
              placeholder="Search..."
              value={search}
              onChange={(e) => {
                setSearch(e.target.value)
                setCurrentPage(1)
              }}
              className="pl-10 pr-4 py-2 border rounded-lg"
            />
          </div>
        )}
        
        {bulkActions && selectedRows.size > 0 && (
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-600">
              {selectedRows.size} selected
            </span>
            {bulkActions(Array.from(selectedRows))}
          </div>
        )}
      </div>
      
      {/* Table */}
      <div className="overflow-x-auto border rounded-lg">
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              {bulkActions && (
                <th className="w-12 px-4 py-3">
                  <input
                    type="checkbox"
                    checked={selectedRows.size === paginatedData.length && paginatedData.length > 0}
                    indeterminate={selectedRows.size > 0 && selectedRows.size < paginatedData.length}
                    onChange={handleSelectAll}
                  />
                </th>
              )}
              
              {columns.map(column => (
                <th
                  key={column.key}
                  className={cn(
                    "px-4 py-3 text-left text-sm font-medium text-gray-900",
                    sortable && column.sortable !== false && "cursor-pointer hover:bg-gray-100"
                  )}
                  onClick={() => column.sortable !== false && handleSort(column.key)}
                >
                  <div className="flex items-center gap-2">
                    {column.header}
                    {sortable && column.sortable !== false && (
                      <div className="flex flex-col">
                        <ChevronUpIcon 
                          className={cn(
                            "h-3 w-3",
                            sortConfig.key === column.key && sortConfig.direction === 'asc'
                              ? "text-gray-900"
                              : "text-gray-400"
                          )}
                        />
                        <ChevronDownIcon 
                          className={cn(
                            "h-3 w-3 -mt-1",
                            sortConfig.key === column.key && sortConfig.direction === 'desc'
                              ? "text-gray-900"
                              : "text-gray-400"
                          )}
                        />
                      </div>
                    )}
                  </div>
                </th>
              ))}
              
              {rowActions && <th className="w-20" />}
            </tr>
          </thead>
          
          <tbody>
            {paginatedData.length === 0 ? (
              <tr>
                <td 
                  colSpan={columns.length + (bulkActions ? 1 : 0) + (rowActions ? 1 : 0)}
                  className="px-4 py-8 text-center text-gray-500"
                >
                  {emptyMessage}
                </td>
              </tr>
            ) : (
              paginatedData.map((row, index) => (
                <tr
                  key={row.id || index}
                  className={cn(
                    "border-b hover:bg-gray-50",
                    onRowClick && "cursor-pointer",
                    selectedRows.has(row.id) && "bg-blue-50"
                  )}
                  onClick={() => onRowClick?.(row)}
                >
                  {bulkActions && (
                    <td className="px-4 py-3">
                      <input
                        type="checkbox"
                        checked={selectedRows.has(row.id)}
                        onChange={(e) => {
                          e.stopPropagation()
                          handleSelectRow(row.id)
                        }}
                        onClick={(e) => e.stopPropagation()}
                      />
                    </td>
                  )}
                  
                  {columns.map(column => (
                    <td key={column.key} className="px-4 py-3 text-sm">
                      {column.render 
                        ? column.render(row[column.key], row)
                        : row[column.key]
                      }
                    </td>
                  ))}
                  
                  {rowActions && (
                    <td className="px-4 py-3">
                      <div onClick={(e) => e.stopPropagation()}>
                        {rowActions(row)}
                      </div>
                    </td>
                  )}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
      
      {/* Pagination */}
      {paginated && totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-gray-600">
            Showing {((currentPage - 1) * pageSize) + 1} to{' '}
            {Math.min(currentPage * pageSize, sortedData.length)} of{' '}
            {sortedData.length} results
          </p>
          
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
              disabled={currentPage === 1}
            >
              Previous
            </Button>
            
            {/* Page numbers */}
            {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
              let pageNum
              if (totalPages <= 5) {
                pageNum = i + 1
              } else if (currentPage <= 3) {
                pageNum = i + 1
              } else if (currentPage >= totalPages - 2) {
                pageNum = totalPages - 4 + i
              } else {
                pageNum = currentPage - 2 + i
              }
              
              return (
                <Button
                  key={pageNum}
                  variant={pageNum === currentPage ? 'primary' : 'outline'}
                  size="sm"
                  onClick={() => setCurrentPage(pageNum)}
                >
                  {pageNum}
                </Button>
              )
            })}
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
              disabled={currentPage === totalPages}
            >
              Next
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}

// Usage
<DataTable
  data={users}
  columns={[
    { 
      key: 'name', 
      header: 'Name',
      render: (name, user) => (
        <div className="flex items-center gap-3">
          <Avatar src={user.avatar} alt={name} />
          <div>
            <div className="font-medium">{name}</div>
            <div className="text-gray-500">{user.email}</div>
          </div>
        </div>
      )
    },
    { 
      key: 'role', 
      header: 'Role',
      render: (role) => <Badge variant={role === 'admin' ? 'primary' : 'secondary'}>{role}</Badge>
    },
    { 
      key: 'lastActive', 
      header: 'Last Active',
      render: (date) => formatRelativeTime(date)
    },
    { 
      key: 'status', 
      header: 'Status',
      sortable: false,
      render: (status) => (
        <Switch
          checked={status === 'active'}
          onChange={(checked) => updateUserStatus(user.id, checked)}
        />
      )
    }
  ]}
  onRowClick={(user) => navigate(`/users/${user.id}`)}
  rowActions={(user) => (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm">
          <MoreHorizontalIcon className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={() => editUser(user)}>Edit</DropdownMenuItem>
        <DropdownMenuItem onClick={() => duplicateUser(user)}>Duplicate</DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem 
          onClick={() => deleteUser(user)}
          className="text-red-600"
        >
          Delete
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )}
  bulkActions={(selectedIds) => (
    <>
      <Button size="sm" variant="outline" onClick={() => exportUsers(selectedIds)}>
        Export
      </Button>
      <Button size="sm" variant="danger" onClick={() => deleteUsers(selectedIds)}>
        Delete
      </Button>
    </>
  )}
/>
```

## List with Filters Pattern

**Why**: Lists often need multiple filter types, search, and responsive layouts.

### Filterable Product List

```javascript
function ProductList({ products }) {
  const [filters, setFilters] = useState({
    search: '',
    category: 'all',
    priceRange: [0, 1000],
    inStock: false,
    sortBy: 'name'
  })
  
  const [viewMode, setViewMode] = useState('grid') // grid | list
  
  // Filter products
  const filteredProducts = useMemo(() => {
    return products
      .filter(product => {
        // Search filter
        if (filters.search && !product.name.toLowerCase().includes(filters.search.toLowerCase())) {
          return false
        }
        
        // Category filter
        if (filters.category !== 'all' && product.category !== filters.category) {
          return false
        }
        
        // Price filter
        if (product.price < filters.priceRange[0] || product.price > filters.priceRange[1]) {
          return false
        }
        
        // Stock filter
        if (filters.inStock && product.stock === 0) {
          return false
        }
        
        return true
      })
      .sort((a, b) => {
        switch (filters.sortBy) {
          case 'name':
            return a.name.localeCompare(b.name)
          case 'price-asc':
            return a.price - b.price
          case 'price-desc':
            return b.price - a.price
          case 'newest':
            return new Date(b.createdAt) - new Date(a.createdAt)
          default:
            return 0
        }
      })
  }, [products, filters])
  
  const categories = useMemo(() => {
    const cats = new Set(products.map(p => p.category))
    return ['all', ...Array.from(cats)]
  }, [products])
  
  const updateFilter = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }))
  }
  
  const clearFilters = () => {
    setFilters({
      search: '',
      category: 'all',
      priceRange: [0, 1000],
      inStock: false,
      sortBy: 'name'
    })
  }
  
  const activeFilterCount = Object.entries(filters).filter(([key, value]) => {
    if (key === 'search') return value !== ''
    if (key === 'category') return value !== 'all'
    if (key === 'priceRange') return value[0] !== 0 || value[1] !== 1000
    if (key === 'inStock') return value === true
    if (key === 'sortBy') return value !== 'name'
    return false
  }).length
  
  return (
    <div className="flex gap-6">
      {/* Sidebar Filters */}
      <aside className="w-64 flex-shrink-0">
        <div className="sticky top-4 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Filters</h2>
            {activeFilterCount > 0 && (
              <button
                onClick={clearFilters}
                className="text-sm text-blue-600 hover:text-blue-700"
              >
                Clear all ({activeFilterCount})
              </button>
            )}
          </div>
          
          {/* Search */}
          <div>
            <label className="block text-sm font-medium mb-2">Search</label>
            <input
              type="search"
              placeholder="Search products..."
              value={filters.search}
              onChange={(e) => updateFilter('search', e.target.value)}
              className="w-full px-3 py-2 border rounded-md"
            />
          </div>
          
          {/* Category */}
          <div>
            <label className="block text-sm font-medium mb-2">Category</label>
            <select
              value={filters.category}
              onChange={(e) => updateFilter('category', e.target.value)}
              className="w-full px-3 py-2 border rounded-md"
            >
              {categories.map(cat => (
                <option key={cat} value={cat}>
                  {cat === 'all' ? 'All Categories' : cat}
                </option>
              ))}
            </select>
          </div>
          
          {/* Price Range */}
          <div>
            <label className="block text-sm font-medium mb-2">
              Price Range: ${filters.priceRange[0]} - ${filters.priceRange[1]}
            </label>
            <RangeSlider
              min={0}
              max={1000}
              step={50}
              value={filters.priceRange}
              onChange={(value) => updateFilter('priceRange', value)}
            />
          </div>
          
          {/* In Stock */}
          <div>
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={filters.inStock}
                onChange={(e) => updateFilter('inStock', e.target.checked)}
                className="rounded"
              />
              <span className="text-sm">In stock only</span>
            </label>
          </div>
        </div>
      </aside>
      
      {/* Main Content */}
      <div className="flex-1">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <p className="text-gray-600">
            {filteredProducts.length} products found
          </p>
          
          <div className="flex items-center gap-4">
            {/* Sort */}
            <select
              value={filters.sortBy}
              onChange={(e) => updateFilter('sortBy', e.target.value)}
              className="px-3 py-2 border rounded-md"
            >
              <option value="name">Name</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="newest">Newest First</option>
            </select>
            
            {/* View Mode */}
            <div className="flex border rounded-md">
              <button
                onClick={() => setViewMode('grid')}
                className={cn(
                  "p-2",
                  viewMode === 'grid' ? 'bg-gray-100' : 'hover:bg-gray-50'
                )}
              >
                <GridIcon className="h-4 w-4" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={cn(
                  "p-2",
                  viewMode === 'list' ? 'bg-gray-100' : 'hover:bg-gray-50'
                )}
              >
                <ListIcon className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
        
        {/* Products Grid/List */}
        {filteredProducts.length === 0 ? (
          <EmptyState
            icon={<PackageIcon />}
            title="No products found"
            description="Try adjusting your filters"
            action={
              <Button onClick={clearFilters} variant="outline">
                Clear filters
              </Button>
            }
          />
        ) : (
          <div className={cn(
            viewMode === 'grid' 
              ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
              : "space-y-4"
          )}>
            {filteredProducts.map(product => (
              viewMode === 'grid' ? (
                <ProductCard key={product.id} product={product} />
              ) : (
                <ProductListItem key={product.id} product={product} />
              )
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
```

## Best Practices

1. **Accessibility First**: Always include ARIA labels, keyboard navigation, focus management
2. **Performance**: Use memoization for expensive filters/sorts
3. **Responsive**: Design mobile-first, test on all screen sizes
4. **Loading States**: Show skeletons or spinners during data fetching
5. **Error Handling**: Graceful error states with retry options
6. **Empty States**: Helpful messages when no data matches filters

## Related Patterns

- [Loading & Animation Patterns](loading-animation-patterns.md) - Skeletons and transitions
- [Data Fetching Patterns](data-fetching-patterns.md) - Loading data for tables/lists
- [Performance Patterns](performance-patterns.md) - Optimizing large lists