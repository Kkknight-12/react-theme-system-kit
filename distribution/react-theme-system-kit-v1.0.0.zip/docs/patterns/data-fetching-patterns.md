# Data Fetching Patterns

**Category**: Data Loading and Management  
**Purpose**: Efficient data fetching, caching, and state management  
**Last Updated**: 2025-01-14

## 📚 Table of Contents

1. [Page-Level Data Fetching](#page-level-data-fetching)
2. [Optimistic Updates Pattern](#optimistic-updates-pattern)
3. [Infinite Scroll Pattern](#infinite-scroll-pattern)
4. [Race Conditions in Data Fetching](#race-conditions-in-data-fetching)

## Page-Level Data Fetching

**Why**: Centralize data fetching at page level for better loading states and error handling.

### Basic Page Data Pattern

```javascript
function usePageData(fetcher, dependencies = []) {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  
  useEffect(() => {
    let cancelled = false
    
    const fetchData = async () => {
      try {
        setLoading(true)
        setError(null)
        const result = await fetcher()
        
        if (!cancelled) {
          setData(result)
        }
      } catch (err) {
        if (!cancelled) {
          setError(err)
        }
      } finally {
        if (!cancelled) {
          setLoading(false)
        }
      }
    }
    
    fetchData()
    
    return () => {
      cancelled = true
    }
  }, dependencies)
  
  const refetch = useCallback(() => {
    const fetchData = async () => {
      try {
        setLoading(true)
        setError(null)
        const result = await fetcher()
        setData(result)
      } catch (err) {
        setError(err)
      } finally {
        setLoading(false)
      }
    }
    
    fetchData()
  }, [fetcher])
  
  return { data, loading, error, refetch }
}

// Page component
function UserProfilePage({ userId }) {
  const { data: user, loading, error, refetch } = usePageData(
    () => api.getUser(userId),
    [userId]
  )
  
  if (loading) {
    return <UserProfileSkeleton />
  }
  
  if (error) {
    return (
      <ErrorState 
        error={error}
        onRetry={refetch}
      />
    )
  }
  
  return (
    <div>
      <UserHeader user={user} />
      <UserDetails user={user} />
      <UserActivity userId={user.id} />
    </div>
  )
}
```

### Parallel Data Fetching

```javascript
function DashboardPage() {
  const [data, setData] = useState({
    stats: null,
    recentActivity: null,
    notifications: null
  })
  const [loading, setLoading] = useState(true)
  const [errors, setErrors] = useState({})
  
  useEffect(() => {
    const fetchDashboardData = async () => {
      setLoading(true)
      
      // Fetch all data in parallel
      const results = await Promise.allSettled([
        api.getStats(),
        api.getRecentActivity(),
        api.getNotifications()
      ])
      
      const newData = {}
      const newErrors = {}
      
      // Process results
      if (results[0].status === 'fulfilled') {
        newData.stats = results[0].value
      } else {
        newErrors.stats = results[0].reason
      }
      
      if (results[1].status === 'fulfilled') {
        newData.recentActivity = results[1].value
      } else {
        newErrors.recentActivity = results[1].reason
      }
      
      if (results[2].status === 'fulfilled') {
        newData.notifications = results[2].value
      } else {
        newErrors.notifications = results[2].reason
      }
      
      setData(newData)
      setErrors(newErrors)
      setLoading(false)
    }
    
    fetchDashboardData()
  }, [])
  
  if (loading) {
    return <DashboardSkeleton />
  }
  
  return (
    <div className="space-y-6">
      {/* Stats Section */}
      {errors.stats ? (
        <ErrorCard error={errors.stats} onRetry={() => refetchStats()} />
      ) : (
        <StatsGrid stats={data.stats} />
      )}
      
      {/* Activity Section */}
      {errors.recentActivity ? (
        <ErrorCard error={errors.recentActivity} onRetry={() => refetchActivity()} />
      ) : (
        <RecentActivity activities={data.recentActivity} />
      )}
      
      {/* Notifications */}
      {errors.notifications ? (
        <ErrorCard error={errors.notifications} onRetry={() => refetchNotifications()} />
      ) : (
        <NotificationsList notifications={data.notifications} />
      )}
    </div>
  )
}
```

### Dependent Data Fetching

```javascript
function ProjectDetailsPage({ projectId }) {
  const [project, setProject] = useState(null)
  const [team, setTeam] = useState(null)
  const [tasks, setTasks] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  
  useEffect(() => {
    const fetchProjectData = async () => {
      try {
        setLoading(true)
        
        // First, fetch the project
        const projectData = await api.getProject(projectId)
        setProject(projectData)
        
        // Then fetch dependent data in parallel
        const [teamData, tasksData] = await Promise.all([
          api.getTeamMembers(projectData.teamId),
          api.getProjectTasks(projectId)
        ])
        
        setTeam(teamData)
        setTasks(tasksData)
      } catch (err) {
        setError(err)
      } finally {
        setLoading(false)
      }
    }
    
    fetchProjectData()
  }, [projectId])
  
  if (loading) return <ProjectSkeleton />
  if (error) return <ErrorState error={error} />
  
  return (
    <div>
      <ProjectHeader project={project} />
      <TeamSection team={team} />
      <TaskList tasks={tasks} projectId={projectId} />
    </div>
  )
}
```

## Optimistic Updates Pattern

**Why**: Provide instant feedback by updating UI before server confirmation.

### Basic Optimistic Update

```javascript
function TodoList() {
  const [todos, setTodos] = useState([])
  const [optimisticUpdates, setOptimisticUpdates] = useState(new Map())
  
  // Merge real data with optimistic updates
  const displayTodos = useMemo(() => {
    return todos.map(todo => {
      const optimistic = optimisticUpdates.get(todo.id)
      return optimistic || todo
    })
  }, [todos, optimisticUpdates])
  
  const toggleTodo = async (todoId) => {
    const todo = todos.find(t => t.id === todoId)
    if (!todo) return
    
    // Optimistic update
    const optimisticTodo = { ...todo, completed: !todo.completed }
    setOptimisticUpdates(prev => new Map(prev).set(todoId, optimisticTodo))
    
    try {
      // Server update
      const updated = await api.updateTodo(todoId, { 
        completed: !todo.completed 
      })
      
      // Update real data
      setTodos(prev => prev.map(t => 
        t.id === todoId ? updated : t
      ))
      
      // Clear optimistic update
      setOptimisticUpdates(prev => {
        const next = new Map(prev)
        next.delete(todoId)
        return next
      })
    } catch (error) {
      // Revert optimistic update on error
      setOptimisticUpdates(prev => {
        const next = new Map(prev)
        next.delete(todoId)
        return next
      })
      
      // Show error message
      toast.error('Failed to update todo')
    }
  }
  
  return (
    <ul>
      {displayTodos.map(todo => (
        <li key={todo.id} className="flex items-center gap-3">
          <input
            type="checkbox"
            checked={todo.completed}
            onChange={() => toggleTodo(todo.id)}
          />
          <span className={cn(
            todo.completed && "line-through text-gray-500",
            optimisticUpdates.has(todo.id) && "opacity-70"
          )}>
            {todo.title}
          </span>
        </li>
      ))}
    </ul>
  )
}
```

### Optimistic Create with Temporary IDs

```javascript
function CommentSection({ postId }) {
  const [comments, setComments] = useState([])
  const [pendingComments, setPendingComments] = useState([])
  
  const addComment = async (text) => {
    // Create temporary comment
    const tempId = `temp-${Date.now()}`
    const tempComment = {
      id: tempId,
      text,
      author: currentUser,
      createdAt: new Date().toISOString(),
      pending: true
    }
    
    // Add to pending
    setPendingComments(prev => [...prev, tempComment])
    
    try {
      // Create on server
      const newComment = await api.createComment(postId, { text })
      
      // Add real comment and remove pending
      setComments(prev => [...prev, newComment])
      setPendingComments(prev => 
        prev.filter(c => c.id !== tempId)
      )
    } catch (error) {
      // Remove failed comment
      setPendingComments(prev => 
        prev.filter(c => c.id !== tempId)
      )
      
      toast.error('Failed to post comment')
    }
  }
  
  // Combine real and pending comments
  const allComments = [...comments, ...pendingComments]
  
  return (
    <div>
      <CommentForm onSubmit={addComment} />
      
      <div className="space-y-4 mt-6">
        {allComments.map(comment => (
          <Comment 
            key={comment.id} 
            comment={comment}
            isPending={comment.pending}
          />
        ))}
      </div>
    </div>
  )
}

function Comment({ comment, isPending }) {
  return (
    <div className={cn(
      "p-4 rounded-lg border",
      isPending && "opacity-60 bg-gray-50"
    )}>
      <div className="flex items-start gap-3">
        <Avatar user={comment.author} />
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <span className="font-medium">{comment.author.name}</span>
            <span className="text-sm text-gray-500">
              {formatRelativeTime(comment.createdAt)}
            </span>
            {isPending && (
              <span className="text-xs text-gray-400">Posting...</span>
            )}
          </div>
          <p className="mt-1">{comment.text}</p>
        </div>
      </div>
    </div>
  )
}
```

## Infinite Scroll Pattern

**Why**: Load large datasets progressively as user scrolls.

### Hook-based Infinite Scroll

```javascript
function useInfiniteScroll({ 
  fetcher,      // Function to fetch next page
  hasMore,      // Whether more data exists
  dependencies = []
}) {
  const [loading, setLoading] = useState(false)
  const observerRef = useRef(null)
  const loadMoreRef = useRef(null)
  
  const loadMore = useCallback(async () => {
    if (loading || !hasMore) return
    
    setLoading(true)
    try {
      await fetcher()
    } finally {
      setLoading(false)
    }
  }, [fetcher, hasMore, loading])
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !loading) {
          loadMore()
        }
      },
      { threshold: 0.1 }
    )
    
    observerRef.current = observer
    
    if (loadMoreRef.current) {
      observer.observe(loadMoreRef.current)
    }
    
    return () => observer.disconnect()
  }, [loadMore, hasMore, loading, ...dependencies])
  
  return { loadMoreRef, loading }
}

// Usage in component
function ProductGrid() {
  const [products, setProducts] = useState([])
  const [page, setPage] = useState(1)
  const [hasMore, setHasMore] = useState(true)
  
  const fetchProducts = useCallback(async () => {
    const response = await api.getProducts({ 
      page, 
      limit: 20 
    })
    
    setProducts(prev => [...prev, ...response.data])
    setHasMore(response.hasNextPage)
    setPage(prev => prev + 1)
  }, [page])
  
  const { loadMoreRef, loading } = useInfiniteScroll({
    fetcher: fetchProducts,
    hasMore,
    dependencies: [page]
  })
  
  return (
    <div>
      <div className="grid grid-cols-3 gap-4">
        {products.map(product => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
      
      {/* Intersection observer target */}
      <div ref={loadMoreRef} className="h-10 mt-4">
        {loading && (
          <div className="flex justify-center">
            <Spinner />
          </div>
        )}
        
        {!hasMore && products.length > 0 && (
          <p className="text-center text-gray-500">
            No more products to load
          </p>
        )}
      </div>
    </div>
  )
}
```

### Virtual Scrolling for Large Lists

```javascript
function VirtualList({ 
  items, 
  itemHeight, 
  containerHeight,
  renderItem,
  overscan = 5
}) {
  const [scrollTop, setScrollTop] = useState(0)
  const scrollElementRef = useRef(null)
  
  const startIndex = Math.floor(scrollTop / itemHeight)
  const endIndex = Math.ceil((scrollTop + containerHeight) / itemHeight)
  
  // Add overscan for smoother scrolling
  const visibleStartIndex = Math.max(0, startIndex - overscan)
  const visibleEndIndex = Math.min(items.length - 1, endIndex + overscan)
  
  const visibleItems = items.slice(visibleStartIndex, visibleEndIndex + 1)
  const totalHeight = items.length * itemHeight
  const offsetY = visibleStartIndex * itemHeight
  
  const handleScroll = (e) => {
    setScrollTop(e.target.scrollTop)
  }
  
  return (
    <div
      ref={scrollElementRef}
      className="relative overflow-auto"
      style={{ height: containerHeight }}
      onScroll={handleScroll}
    >
      {/* Total height container */}
      <div style={{ height: totalHeight }} />
      
      {/* Visible items */}
      <div
        className="absolute top-0 left-0 right-0"
        style={{ transform: `translateY(${offsetY}px)` }}
      >
        {visibleItems.map((item, index) => (
          <div
            key={item.id}
            style={{ height: itemHeight }}
          >
            {renderItem(item, visibleStartIndex + index)}
          </div>
        ))}
      </div>
    </div>
  )
}

// Usage
<VirtualList
  items={largeDataset}
  itemHeight={80}
  containerHeight={600}
  renderItem={(item, index) => (
    <div className="p-4 border-b">
      <h3>{item.title}</h3>
      <p>{item.description}</p>
    </div>
  )}
/>
```

### Cursor-based Pagination

```javascript
function CursorPaginatedList({ endpoint }) {
  const [items, setItems] = useState([])
  const [cursor, setCursor] = useState(null)
  const [hasMore, setHasMore] = useState(true)
  const [loading, setLoading] = useState(false)
  
  const loadMore = async () => {
    if (loading || !hasMore) return
    
    setLoading(true)
    try {
      const response = await api.get(endpoint, {
        params: { 
          cursor,
          limit: 20 
        }
      })
      
      setItems(prev => [...prev, ...response.data])
      setCursor(response.nextCursor)
      setHasMore(!!response.nextCursor)
    } catch (error) {
      toast.error('Failed to load more items')
    } finally {
      setLoading(false)
    }
  }
  
  // Initial load
  useEffect(() => {
    loadMore()
  }, [])
  
  return (
    <div>
      <div className="space-y-4">
        {items.map(item => (
          <ItemCard key={item.id} item={item} />
        ))}
      </div>
      
      {hasMore && (
        <div className="mt-6 text-center">
          <Button 
            onClick={loadMore}
            loading={loading}
            variant="outline"
          >
            Load More
          </Button>
        </div>
      )}
    </div>
  )
}
```

## Race Conditions in Data Fetching

**Why**: When multiple async operations update the same state, users can see incorrect data or flashing content.

### Understanding Race Conditions

Race conditions occur when:
1. Multiple fetch requests are triggered (e.g., rapid navigation)
2. Requests resolve in different order than initiated
3. State updates with "stale" data

```javascript
// ❌ Problem: Race condition prone
function Page({ id }) {
  const [data, setData] = useState(null)
  
  useEffect(() => {
    fetch(`/api/data/${id}`)
      .then(r => r.json())
      .then(result => {
        // If user navigates quickly, this might set old data!
        setData(result)
      })
  }, [id])
  
  return <div>{data?.title}</div>
}

// Scenario:
// 1. User on page 1, fetch starts (takes 2s)
// 2. User navigates to page 2, new fetch starts (takes 1s)
// 3. Page 2 data arrives first, displays correctly
// 4. Page 1 data arrives later, OVERWRITES with wrong data!
```

### Solution 1: Force Re-mounting

**When**: Component should reset completely on navigation

```javascript
// Force unmount/remount with key prop
function App() {
  const [pageId, setPageId] = useState(1)
  
  return (
    // Key change = component unmounts, cancelling old effects
    <Page id={pageId} key={pageId} />
  )
}

// Why it works:
// - Component unmounts → useEffect cleanup runs
// - Old fetch can't setState on unmounted component
// - New component mounts fresh with new id
```

### Solution 2: Compare Results with Current State

**When**: Need to keep component mounted but ignore stale data

```javascript
function Page({ id }) {
  const [data, setData] = useState(null)
  const currentIdRef = useRef(id)
  
  useEffect(() => {
    // Always update ref to latest id
    currentIdRef.current = id
    
    fetch(`/api/data/${id}`)
      .then(r => r.json())
      .then(result => {
        // Only update if result matches current id
        if (currentIdRef.current === id) {
          setData(result)
        }
        // Otherwise, ignore stale result
      })
  }, [id])
  
  return <div>{data?.title}</div>
}

// Alternative: Compare with result data
function Page({ id }) {
  const [data, setData] = useState(null)
  const currentUrlRef = useRef(null)
  
  useEffect(() => {
    const url = `/api/data/${id}`
    currentUrlRef.current = url
    
    fetch(url)
      .then(r => r.json())
      .then(result => {
        // API returns the URL it was called with
        if (result.url === currentUrlRef.current) {
          setData(result)
        }
      })
  }, [id])
}
```

### Solution 3: Cleanup Function with Closure

**When**: Want to track "active" requests without refs

```javascript
function Page({ id }) {
  const [data, setData] = useState(null)
  
  useEffect(() => {
    // This variable is unique to this effect run
    let isActive = true
    
    fetch(`/api/data/${id}`)
      .then(r => r.json())
      .then(result => {
        // Only update if this effect is still active
        if (isActive) {
          setData(result)
        }
      })
    
    // Cleanup: mark this effect as inactive
    return () => {
      isActive = false
    }
  }, [id])
  
  return <div>{data?.title}</div>
}

// How it works:
// 1. Each useEffect run creates its own closure with isActive = true
// 2. When id changes, cleanup runs first, setting old closure's isActive = false
// 3. New effect runs with fresh closure where isActive = true
// 4. Old fetch completes but isActive is false, so setState skipped
```

### Solution 4: AbortController (Recommended)

**When**: Want to actually cancel the network request

```javascript
function Page({ id }) {
  const [data, setData] = useState(null)
  const [error, setError] = useState(null)
  
  useEffect(() => {
    // Create controller for this request
    const controller = new AbortController()
    
    fetch(`/api/data/${id}`, {
      signal: controller.signal
    })
      .then(r => r.json())
      .then(result => {
        setData(result)
        setError(null)
      })
      .catch(err => {
        // Ignore abort errors
        if (err.name !== 'AbortError') {
          setError(err)
        }
      })
    
    // Cleanup: abort the request
    return () => {
      controller.abort()
    }
  }, [id])
  
  return (
    <div>
      {error && <div>Error: {error.message}</div>}
      {data && <div>{data.title}</div>}
    </div>
  )
}
```

### Advanced: Custom Hook for Race-Safe Fetching

```javascript
function useRaceSafeFetch(url) {
  const [state, setState] = useState({
    data: null,
    loading: true,
    error: null
  })
  
  useEffect(() => {
    const controller = new AbortController()
    
    setState(prev => ({ ...prev, loading: true, error: null }))
    
    fetch(url, { signal: controller.signal })
      .then(r => {
        if (!r.ok) throw new Error(`HTTP ${r.status}`)
        return r.json()
      })
      .then(data => {
        setState({ data, loading: false, error: null })
      })
      .catch(error => {
        if (error.name !== 'AbortError') {
          setState({ data: null, loading: false, error })
        }
      })
    
    return () => controller.abort()
  }, [url])
  
  return state
}

// Usage
function Page({ id }) {
  const { data, loading, error } = useRaceSafeFetch(`/api/data/${id}`)
  
  if (loading) return <Spinner />
  if (error) return <ErrorMessage error={error} />
  return <div>{data.title}</div>
}
```

### Async/Await Considerations

Async/await doesn't change race condition behavior:

```javascript
// ❌ Still has race conditions
function Page({ id }) {
  const [data, setData] = useState(null)
  
  useEffect(() => {
    async function fetchData() {
      const response = await fetch(`/api/data/${id}`)
      const result = await response.json()
      setData(result) // Still vulnerable!
    }
    
    fetchData()
  }, [id])
}

// ✅ Fixed with AbortController
function Page({ id }) {
  const [data, setData] = useState(null)
  
  useEffect(() => {
    const controller = new AbortController()
    
    async function fetchData() {
      try {
        const response = await fetch(`/api/data/${id}`, {
          signal: controller.signal
        })
        const result = await response.json()
        setData(result)
      } catch (error) {
        if (error.name !== 'AbortError') {
          console.error('Fetch failed:', error)
        }
      }
    }
    
    fetchData()
    
    return () => controller.abort()
  }, [id])
}
```

### Race Conditions in Libraries

Most data fetching libraries handle race conditions automatically:

```javascript
// SWR - handles race conditions internally
import useSWR from 'swr'

function Page({ id }) {
  const { data, error } = useSWR(`/api/data/${id}`, fetcher)
  // No race conditions! SWR cancels stale requests
}

// React Query - also handles race conditions
import { useQuery } from 'react-query'

function Page({ id }) {
  const { data, error } = useQuery(
    ['page', id],
    () => fetch(`/api/data/${id}`).then(r => r.json())
  )
  // Safe from race conditions
}
```

### Common Scenarios and Solutions

1. **Search Input with Debouncing**
```javascript
function Search() {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState([])
  
  useEffect(() => {
    const controller = new AbortController()
    const timeoutId = setTimeout(() => {
      if (query) {
        fetch(`/api/search?q=${query}`, {
          signal: controller.signal
        })
          .then(r => r.json())
          .then(data => setResults(data))
          .catch(err => {
            if (err.name !== 'AbortError') {
              setResults([])
            }
          })
      } else {
        setResults([])
      }
    }, 300) // Debounce 300ms
    
    return () => {
      clearTimeout(timeoutId)
      controller.abort()
    }
  }, [query])
}
```

2. **Tab Navigation**
```javascript
function TabbedContent() {
  const [activeTab, setActiveTab] = useState('tab1')
  const [content, setContent] = useState(null)
  
  useEffect(() => {
    let isActive = true
    
    // Show loading immediately
    setContent(null)
    
    fetch(`/api/tabs/${activeTab}`)
      .then(r => r.json())
      .then(data => {
        // Double-check we're still on the same tab
        if (isActive) {
          setContent(data)
        }
      })
    
    return () => {
      isActive = false
    }
  }, [activeTab])
}
```

## Best Practices

1. **Loading States**: Always show appropriate loading indicators
2. **Error Handling**: Graceful error states with retry options
3. **Race Conditions**: Always handle with AbortController or cleanup functions
4. **Caching**: Consider using React Query or SWR for advanced caching
5. **Optimistic UI**: Provide instant feedback for better UX
6. **Progressive Loading**: Load critical data first, enhance progressively

## Related Patterns

- [Loading & Animation Patterns](loading-animation-patterns.md) - Loading states
- [State Management Patterns](state-management-patterns.md) - Managing fetched data
- [Performance Patterns](performance-patterns.md) - Optimizing data updates