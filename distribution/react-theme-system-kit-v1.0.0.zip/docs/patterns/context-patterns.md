# Context Patterns

**Category**: React Context Performance  
**Purpose**: Optimizing Context for performance and scalability  
**Last Updated**: 2025-01-14

## 📚 Table of Contents

1. [Context with Children Pattern](#context-with-children-pattern)
2. [Split Context Pattern](#split-context-pattern)
3. [useReducer Context Pattern](#usereducer-context-pattern)
4. [Context Performance Optimization](#context-performance-optimization)

## Context with Children Pattern

**Why**: Prevents unnecessary re-renders by keeping children stable when context value changes.

### Basic Pattern

```javascript
// ❌ Bad: Context value recreation causes all consumers to re-render
function ThemeProvider({ children }) {
  const [theme, setTheme] = useState('light')
  
  // This object is recreated on every render!
  const value = {
    theme,
    setTheme,
    toggleTheme: () => setTheme(prev => prev === 'light' ? 'dark' : 'light')
  }
  
  return (
    <ThemeContext.Provider value={value}>
      {children}
    </ThemeContext.Provider>
  )
}

// ✅ Good: Memoized value + children pattern
function ThemeProvider({ children }) {
  const [theme, setTheme] = useState('light')
  
  const toggleTheme = useCallback(() => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light')
  }, [])
  
  const value = useMemo(
    () => ({ theme, setTheme, toggleTheme }),
    [theme] // Only recreate when theme changes
  )
  
  return (
    <ThemeContext.Provider value={value}>
      {children}
    </ThemeContext.Provider>
  )
}
```

### Advanced: Context with Side Effects

```javascript
function NotificationProvider({ children }) {
  const [notifications, setNotifications] = useState([])
  const timeoutsRef = useRef(new Map())
  
  const addNotification = useCallback((notification) => {
    const id = Date.now()
    const fullNotification = { ...notification, id }
    
    setNotifications(prev => [...prev, fullNotification])
    
    // Auto-dismiss after 5 seconds
    if (notification.autoDismiss !== false) {
      const timeout = setTimeout(() => {
        removeNotification(id)
      }, notification.duration || 5000)
      
      timeoutsRef.current.set(id, timeout)
    }
    
    return id
  }, [])
  
  const removeNotification = useCallback((id) => {
    setNotifications(prev => prev.filter(n => n.id !== id))
    
    // Clear timeout if exists
    const timeout = timeoutsRef.current.get(id)
    if (timeout) {
      clearTimeout(timeout)
      timeoutsRef.current.delete(id)
    }
  }, [])
  
  // Cleanup on unmount
  useEffect(() => {
    return () => {
      timeoutsRef.current.forEach(timeout => clearTimeout(timeout))
    }
  }, [])
  
  const value = useMemo(
    () => ({ notifications, addNotification, removeNotification }),
    [notifications, addNotification, removeNotification]
  )
  
  return (
    <NotificationContext.Provider value={value}>
      {children}
      <NotificationContainer notifications={notifications} />
    </NotificationContext.Provider>
  )
}
```

## Split Context Pattern

**Why**: Separate frequently changing values from stable ones to minimize re-renders.

### Split State and Dispatch

```javascript
// Separate contexts for state and dispatch
const AuthStateContext = createContext()
const AuthDispatchContext = createContext()

function AuthProvider({ children }) {
  const [state, dispatch] = useReducer(authReducer, {
    user: null,
    isAuthenticated: false,
    isLoading: true
  })
  
  // Check authentication on mount
  useEffect(() => {
    checkAuth().then(user => {
      dispatch({ type: 'AUTH_SUCCESS', payload: user })
    }).catch(() => {
      dispatch({ type: 'AUTH_FAILURE' })
    })
  }, [])
  
  return (
    <AuthStateContext.Provider value={state}>
      <AuthDispatchContext.Provider value={dispatch}>
        {children}
      </AuthDispatchContext.Provider>
    </AuthStateContext.Provider>
  )
}

// Separate hooks for consuming
function useAuthState() {
  const context = useContext(AuthStateContext)
  if (!context) {
    throw new Error('useAuthState must be used within AuthProvider')
  }
  return context
}

function useAuthDispatch() {
  const context = useContext(AuthDispatchContext)
  if (!context) {
    throw new Error('useAuthDispatch must be used within AuthProvider')
  }
  return context
}

// Usage - component only re-renders when needed
function UserAvatar() {
  const { user } = useAuthState() // Re-renders when user changes
  return <Avatar user={user} />
}

function LogoutButton() {
  const dispatch = useAuthDispatch() // Never re-renders!
  return (
    <button onClick={() => dispatch({ type: 'LOGOUT' })}>
      Logout
    </button>
  )
}
```

### Multiple Split Contexts

```javascript
// Shopping cart with split contexts
const CartItemsContext = createContext()
const CartActionsContext = createContext()
const CartSummaryContext = createContext()

function CartProvider({ children }) {
  const [items, setItems] = useState([])
  
  // Memoized summary calculations
  const summary = useMemo(() => {
    const subtotal = items.reduce((sum, item) => sum + (item.price * item.quantity), 0)
    const tax = subtotal * 0.08
    const shipping = subtotal > 50 ? 0 : 10
    const total = subtotal + tax + shipping
    
    return { subtotal, tax, shipping, total, itemCount: items.length }
  }, [items])
  
  // Stable action functions
  const actions = useMemo(() => ({
    addItem: (product) => {
      setItems(prev => {
        const existing = prev.find(item => item.id === product.id)
        if (existing) {
          return prev.map(item => 
            item.id === product.id 
              ? { ...item, quantity: item.quantity + 1 }
              : item
          )
        }
        return [...prev, { ...product, quantity: 1 }]
      })
    },
    
    removeItem: (productId) => {
      setItems(prev => prev.filter(item => item.id !== productId))
    },
    
    updateQuantity: (productId, quantity) => {
      if (quantity <= 0) {
        setItems(prev => prev.filter(item => item.id !== productId))
      } else {
        setItems(prev => prev.map(item => 
          item.id === productId 
            ? { ...item, quantity }
            : item
        ))
      }
    },
    
    clearCart: () => setItems([])
  }), [])
  
  return (
    <CartItemsContext.Provider value={items}>
      <CartActionsContext.Provider value={actions}>
        <CartSummaryContext.Provider value={summary}>
          {children}
        </CartSummaryContext.Provider>
      </CartActionsContext.Provider>
    </CartItemsContext.Provider>
  )
}

// Granular hooks
function useCartItems() {
  return useContext(CartItemsContext)
}

function useCartActions() {
  return useContext(CartActionsContext)
}

function useCartSummary() {
  return useContext(CartSummaryContext)
}

// Components only subscribe to what they need
function CartBadge() {
  const { itemCount } = useCartSummary() // Only re-renders when count changes
  return <Badge>{itemCount}</Badge>
}

function AddToCartButton({ product }) {
  const { addItem } = useCartActions() // Never re-renders!
  return <button onClick={() => addItem(product)}>Add to Cart</button>
}
```

## useReducer Context Pattern

**Why**: Stable dispatch function prevents consumer re-renders and provides predictable state updates.

### Key Benefits Over useState

**From real-world experience**: 

1. **Dispatch Never Changes** - Unlike setState functions that need memoization, dispatch is stable by default
2. **Actions Don't Depend on State** - Toggle functions can be created without state dependencies
3. **Prevents Cascade Re-renders** - API functions remain stable even when state changes

```javascript
// ❌ useState Problem: toggle depends on state
const [isExpanded, setIsExpanded] = useState(false);
const toggle = useCallback(() => {
  setIsExpanded(!isExpanded); // Depends on isExpanded!
}, [isExpanded]); // Re-creates when state changes

// ✅ useReducer Solution: toggle is always stable
const [state, dispatch] = useReducer(reducer, { isExpanded: false });
const toggle = useCallback(() => {
  dispatch({ type: 'toggle' }); // No dependencies!
}, []); // Never re-creates
```

### Complex State with Reducer

```javascript
const AppStateContext = createContext()
const AppDispatchContext = createContext()

// Action types
const ActionTypes = {
  SET_USER: 'SET_USER',
  SET_THEME: 'SET_THEME',
  SET_SIDEBAR_OPEN: 'SET_SIDEBAR_OPEN',
  ADD_NOTIFICATION: 'ADD_NOTIFICATION',
  REMOVE_NOTIFICATION: 'REMOVE_NOTIFICATION',
  SET_LOADING: 'SET_LOADING',
  SET_ERROR: 'SET_ERROR'
}

// Reducer with complex state updates
function appReducer(state, action) {
  switch (action.type) {
    case ActionTypes.SET_USER:
      return {
        ...state,
        user: action.payload,
        isAuthenticated: !!action.payload
      }
      
    case ActionTypes.SET_THEME:
      // Side effect: Save to localStorage
      localStorage.setItem('theme', action.payload)
      return {
        ...state,
        theme: action.payload
      }
      
    case ActionTypes.ADD_NOTIFICATION:
      return {
        ...state,
        notifications: [...state.notifications, {
          id: Date.now(),
          ...action.payload
        }]
      }
      
    case ActionTypes.REMOVE_NOTIFICATION:
      return {
        ...state,
        notifications: state.notifications.filter(n => n.id !== action.payload)
      }
      
    case ActionTypes.SET_LOADING:
      return {
        ...state,
        isLoading: action.payload
      }
      
    case ActionTypes.SET_ERROR:
      return {
        ...state,
        error: action.payload,
        isLoading: false
      }
      
    default:
      throw new Error(`Unknown action: ${action.type}`)
  }
}

// Provider with action creators
function AppProvider({ children }) {
  const [state, dispatch] = useReducer(appReducer, {
    user: null,
    isAuthenticated: false,
    theme: localStorage.getItem('theme') || 'light',
    sidebarOpen: true,
    notifications: [],
    isLoading: false,
    error: null
  })
  
  // Action creators for better DX
  const actions = useMemo(() => ({
    setUser: (user) => dispatch({ type: ActionTypes.SET_USER, payload: user }),
    setTheme: (theme) => dispatch({ type: ActionTypes.SET_THEME, payload: theme }),
    toggleSidebar: () => dispatch({ 
      type: ActionTypes.SET_SIDEBAR_OPEN, 
      payload: !state.sidebarOpen 
    }),
    notify: (notification) => dispatch({ 
      type: ActionTypes.ADD_NOTIFICATION, 
      payload: notification 
    }),
    dismissNotification: (id) => dispatch({ 
      type: ActionTypes.REMOVE_NOTIFICATION, 
      payload: id 
    }),
    setLoading: (loading) => dispatch({ 
      type: ActionTypes.SET_LOADING, 
      payload: loading 
    }),
    setError: (error) => dispatch({ 
      type: ActionTypes.SET_ERROR, 
      payload: error 
    })
  }), [state.sidebarOpen]) // Only recreate when necessary
  
  return (
    <AppStateContext.Provider value={state}>
      <AppDispatchContext.Provider value={actions}>
        {children}
      </AppDispatchContext.Provider>
    </AppStateContext.Provider>
  )
}
```

## Context Performance Optimization

**Why**: Prevent unnecessary re-renders in large apps with many context consumers.

### The Context Re-render Problem

**From real-world experience**: Context has a bad reputation because:

1. **All Consumers Re-render** - When Context value changes, EVERY consumer re-renders
2. **Can't Prevent with Memo** - Standard memoization techniques don't work
3. **Parent Re-renders Cascade** - If Context provider re-renders, all consumers re-render

```javascript
// ❌ This won't prevent re-renders
const Component = memo(() => {
  const { value } = useContext(MyContext); // Still re-renders!
  return <div>{value}</div>;
});

// ❌ This also won't work
const useStableValue = () => {
  const { value } = useContext(MyContext);
  return useMemo(() => value, []); // Component still re-renders!
};
```

### Critical Rule: Always Memoize Context Value

**From real-world experience**: "This is one of the few cases where always memoizing by default is actually not premature optimization."

```javascript
// ❌ Dangerous: Parent re-render = all consumers re-render
const Provider = ({ children }) => {
  const [state, setState] = useState();
  const value = { state, setState }; // New object every render!
  
  return <Context.Provider value={value}>{children}</Context.Provider>;
};

// ✅ Safe: Parent re-render doesn't affect consumers
const Provider = ({ children }) => {
  const [state, setState] = useState();
  const value = useMemo(() => ({ state, setState }), [state]);
  
  return <Context.Provider value={value}>{children}</Context.Provider>;
};
```

### Context Selector Pattern with HOC

**From real-world experience**: "We can leverage the power of Higher Order Components" to mimic Redux-like selectors.

```javascript
// HOC that provides stable props even when context changes
const withNavigationOpen = (Component) => {
  // Memoize the component inside HOC
  const MemoizedComponent = React.memo(Component);
  
  return (props) => {
    // This component re-renders on context change
    const { open } = useContext(NavigationContext);
    
    // But MemoizedComponent won't if props don't change!
    return <MemoizedComponent {...props} openNav={open} />;
  };
};

// Usage: Component won't re-render when other context values change
const HeavyComponent = withNavigationOpen(({ openNav }) => {
  console.log('I only re-render if props change, not context!');
  return <button onClick={openNav}>Open Nav</button>;
});
```

### Alternative Selector Implementation

```javascript
// Custom hook for selecting specific values
function createContextSelector(Context) {
  return function useContextSelector(selector) {
    const context = useContext(Context)
    const selectedRef = useRef()
    const [, forceRender] = useReducer(x => x + 1, 0)
    
    const selected = selector(context)
    
    // Only re-render if selected value changed
    useEffect(() => {
      if (selectedRef.current !== selected) {
        selectedRef.current = selected
        forceRender()
      }
    })
    
    return selected
  }
}

// Usage
const useAppStateSelector = createContextSelector(AppStateContext)

function UserName() {
  // Only re-renders when user.name changes
  const userName = useAppStateSelector(state => state.user?.name)
  return <span>{userName}</span>
}

function ThemeToggle() {
  // Only re-renders when theme changes
  const theme = useAppStateSelector(state => state.theme)
  const { setTheme } = useContext(AppDispatchContext)
  
  return (
    <button onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}>
      {theme === 'light' ? '🌙' : '☀️'}
    </button>
  )
}
```

### Optimized Provider Pattern

```javascript
// Factory for creating optimized providers
function createOptimizedContext(name) {
  const StateContext = createContext()
  const DispatchContext = createContext()
  
  function Provider({ children, initialState, reducer }) {
    const [state, dispatch] = useReducer(reducer, initialState)
    
    // Memoize dispatch wrapper for better DX
    const dispatchWithLogging = useMemo(() => {
      return (action) => {
        if (process.env.NODE_ENV === 'development') {
          console.group(`${name} Action: ${action.type}`)
          console.log('Previous State:', state)
          console.log('Action:', action)
          console.groupEnd()
        }
        dispatch(action)
      }
    }, [state])
    
    return (
      <StateContext.Provider value={state}>
        <DispatchContext.Provider value={dispatchWithLogging}>
          {children}
        </DispatchContext.Provider>
      </StateContext.Provider>
    )
  }
  
  function useState() {
    const context = useContext(StateContext)
    if (context === undefined) {
      throw new Error(`useState must be used within ${name}Provider`)
    }
    return context
  }
  
  function useDispatch() {
    const context = useContext(DispatchContext)
    if (context === undefined) {
      throw new Error(`useDispatch must be used within ${name}Provider`)
    }
    return context
  }
  
  return { Provider, useState, useDispatch }
}

// Create specific contexts
const Auth = createOptimizedContext('Auth')
const Theme = createOptimizedContext('Theme')
const Cart = createOptimizedContext('Cart')

// Usage
function App() {
  return (
    <Auth.Provider initialState={authInitialState} reducer={authReducer}>
      <Theme.Provider initialState={themeInitialState} reducer={themeReducer}>
        <Cart.Provider initialState={cartInitialState} reducer={cartReducer}>
          <Router />
        </Cart.Provider>
      </Theme.Provider>
    </Auth.Provider>
  )
}
```

## Real-World Context Insights

### Context Can Actually IMPROVE Performance

**From real-world experience**: "Context can prevent unnecessary re-renders and significantly improve the performance of our apps."

```javascript
// ❌ Without Context: Entire page re-renders on state change
const Page = () => {
  const [isNavExpanded, setIsNavExpanded] = useState();
  
  return (
    <>
      <Sidebar isNavExpanded={isNavExpanded} /> {/* Re-renders! */}
      <MainContent isNavExpanded={isNavExpanded} /> {/* Re-renders! */}
      <VerySlowComponent /> {/* Also re-renders! */}
    </>
  );
};

// ✅ With Context: Only consumers re-render
const Page = () => {
  return (
    <NavigationProvider>
      <Sidebar /> {/* Only button inside re-renders */}
      <MainContent /> {/* Only affected parts re-render */}
      <VerySlowComponent /> {/* Doesn't re-render! */}
    </NavigationProvider>
  );
};
```

### The Mental Model for State Management

**From real-world experience**: "Understanding Context is very useful when it comes to external state management libraries like Redux. The mental model is exactly the same."

Key insights:
- Context allows "teleporting" data without prop drilling
- All state management libraries use similar patterns
- Master Context = Master Redux, Zustand, Jotai, etc.

### useState vs useReducer Trade-offs

**From real-world experience**: When to use each:

```javascript
// ✅ useState: Simple, independent values
const [isOpen, setIsOpen] = useState(false);
const [count, setCount] = useState(0);

// ✅ useReducer: Complex state with related updates
const [state, dispatch] = useReducer(reducer, {
  isNavExpanded: false,
  selectedItem: null,
  filters: [],
  sortOrder: 'asc'
});

// Real benefit: Stable dispatch for split contexts
const api = useMemo(() => ({
  toggle: () => dispatch({ type: 'TOGGLE' }), // No dependencies!
  select: (id) => dispatch({ type: 'SELECT', id }),
  setFilter: (filter) => dispatch({ type: 'SET_FILTER', filter })
}), []); // Never changes!
```

## Insights from Official React Documentation

### When NOT to Use Context

**From official docs**: "Before you use context, try passing props or passing JSX as children."

Context is designed for "teleporting" data to distant components. However, it's not always the right solution:

```javascript
// ❌ Unnecessary context for 1-2 levels
function App() {
  return (
    <ThemeContext.Provider value="dark">
      <Header />
    </ThemeContext.Provider>
  )
}

function Header() {
  const theme = useContext(ThemeContext)
  return <div className={theme}>...</div>
}

// ✅ Better: Just pass props
function App() {
  return <Header theme="dark" />
}

function Header({ theme }) {
  return <div className={theme}>...</div>
}
```

**Use context only when**:
- Multiple components at different nesting levels need the same data
- The data needs to "teleport" through many intermediate components
- No parent-child relationship exists between data source and consumer

### Object.is Comparison and Dependencies

**From official docs**: "React will compare each dependency with its previous value using the Object.is comparison."

This is crucial for understanding why memoization works:

```javascript
// Understanding Object.is behavior
Object.is(3, 3)           // true
Object.is('hello', 'hello') // true
Object.is({}, {})         // false (different objects)
Object.is([], [])         // false (different arrays)

// Why this matters for context
function Provider({ children }) {
  // ❌ Bad: New object every render, Object.is({}, {}) is false
  const value = { theme: 'dark', user: currentUser }
  
  // ✅ Good: Memoized, only changes when dependencies change
  const value = useMemo(
    () => ({ theme: 'dark', user: currentUser }),
    [currentUser] // Object.is comparison on dependencies
  )
  
  return <Context.Provider value={value}>{children}</Context.Provider>
}
```

### Strict Mode Behavior

**From official docs**: "In Strict Mode, React will call your calculation function twice in order to help you find accidental impurities."

Important for debugging:

```javascript
function MyProvider({ children }) {
  // This will run TWICE in development with Strict Mode
  const value = useMemo(() => {
    console.log('Computing context value') // Logs twice!
    return { /* ... */ }
  }, [])
  
  // Don't worry - this is development only behavior
  // Production builds run once
}
```

### Performance Reality Check

**From official docs**: "Optimizing with useMemo is only valuable in a few cases."

Don't over-optimize. Memoize context values when:
- The context has many consumers (10+ components)
- The value is expensive to compute
- Children are wrapped in `memo()`
- The context updates frequently

```javascript
// ❌ Over-optimization for simple values
const theme = useMemo(() => 'dark', []) // Unnecessary

// ✅ Good optimization for complex values
const value = useMemo(() => ({
  user: currentUser,
  permissions: calculatePermissions(currentUser),
  preferences: userPreferences,
  actions: { logout, updateProfile }
}), [currentUser, userPreferences])
```

### Context Default Values Behavior

**From official docs**: "The defaultValue is only used when a component does not have a matching Provider above it in the tree."

```javascript
// Default value behavior
const ThemeContext = createContext('light') // Default value

// Case 1: With Provider - default ignored
<ThemeContext.Provider value="dark">
  <Component /> {/* Receives "dark" */}
</ThemeContext.Provider>

// Case 2: Without Provider - default used
<Component /> {/* Receives "light" (default) */}

// Common pattern: null default with error checking
const AuthContext = createContext(null)

function useAuth() {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider')
  }
  return context
}
```

## Best Practices

1. **Start with Props**: Try props before reaching for context
2. **Always Memoize Context Value**: "Not premature optimization" - prevents cascade re-renders
3. **Split Contexts**: Separate frequently changing values from stable ones
4. **Use Reducers for Split Contexts**: Dispatch is stable, enabling better splitting
5. **Avoid Large Contexts**: Split into smaller, focused contexts
6. **Custom Hooks**: Always provide custom hooks for consuming context
7. **Error Boundaries**: Add error boundaries around context providers
8. **Consider Alternatives**: Component composition can often solve prop drilling
9. **Use HOCs for Selectors**: When you need Redux-like selectors without a library
10. **Profile Before Optimizing**: Context might actually improve performance

### When to Use Context vs Props

| Use Context When                                    | Use Props When                      |
|-----------------------------------------------------|-------------------------------------|
| Data needed by many components at different levels  | Data flows parent → child directly  |
| Avoiding prop drilling through 3+ levels            | Only 1-2 levels deep                |
| Global app state (theme, auth, locale)              | Component-specific state            |
| Cross-cutting concerns                              | Clear data flow is important        |

### Common Context Pitfalls to Avoid

1. **Forgetting to Memoize**: Provider re-renders → all consumers re-render
2. **Single Large Context**: Any change triggers all consumers
3. **Not Splitting State/Actions**: Actions re-create when state changes
4. **Assuming Memo Works**: `React.memo` doesn't prevent context re-renders
5. **Overusing Context**: Sometimes composition or props are better

## Debugging Context

### React DevTools
- Install React Developer Tools browser extension
- Look for context providers in component tree
- Inspect context values in real-time
- Track which components consume context

### Common Debugging Patterns

```javascript
// Debug context changes
function DebugProvider({ children }) {
  const [state, setState] = useState(initialState)
  
  // Log all state changes
  useEffect(() => {
    console.log('Context state updated:', state)
  }, [state])
  
  // Track render count
  const renderCount = useRef(0)
  renderCount.current++
  console.log(`Provider rendered ${renderCount.current} times`)
  
  const value = useMemo(() => ({ state, setState }), [state])
  
  return (
    <Context.Provider value={value}>
      {children}
    </Context.Provider>
  )
}
```

## Related Patterns

- [Performance Patterns](performance-patterns.md) - General optimization techniques
- [State Management Patterns](state-management-patterns.md) - Complex state handling
- [Composition Patterns](composition-patterns.md) - Component composition strategies