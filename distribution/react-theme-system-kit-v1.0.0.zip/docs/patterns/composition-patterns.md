# Composition Patterns

**Category**: Component Composition  
**Purpose**: Flexible component APIs and composition strategies  
**Last Updated**: 2025-01-14

## 📚 Table of Contents

1. [Render Props Pattern](#render-props-pattern)
2. [Compound Components with Context](#compound-components-with-context)
3. [Custom Hooks vs HOCs](#custom-hooks-vs-hocs)
4. [HOC Use Cases](#hoc-use-cases-when-hooks-wont-work)

## Render Props Pattern

**Why**: Maximum flexibility in rendering. Allows parent components to control exactly how data is displayed while child components handle the logic.

```javascript
// Generic DataList component with render props
export function DataList({ 
  data, 
  loading, 
  error, 
  renderItem, 
  renderEmpty,
  renderError,
  renderLoading 
}) {
  if (loading) {
    return renderLoading ? renderLoading() : <DefaultSkeleton />
  }
  
  if (error) {
    return renderError ? renderError(error) : <DefaultError error={error} />
  }
  
  if (!data || data.length === 0) {
    return renderEmpty ? renderEmpty() : <DefaultEmpty />
  }
  
  return (
    <div className="space-y-2">
      {data.map((item, index) => (
        <div key={item.id || index}>
          {renderItem(item, index)}
        </div>
      ))}
    </div>
  )
}

// Usage
<DataList
  data={users}
  loading={isLoading}
  error={error}
  renderItem={(user) => <UserCard user={user} />}
  renderEmpty={() => <EmptyState message="No users found" />}
  renderLoading={() => <UserListSkeleton count={5} />}
/>
```

## Compound Components with Context

**Why**: Creates intuitive APIs for complex components. Children components automatically receive shared state and handlers without prop drilling.

```javascript
// Compound Select Component
const SelectContext = createContext()

function Select({ children, value, onChange }) {
  const [isOpen, setIsOpen] = useState(false)
  
  return (
    <SelectContext.Provider value={{ value, onChange, isOpen, setIsOpen }}>
      <div className="relative">
        {children}
      </div>
    </SelectContext.Provider>
  )
}

function SelectTrigger({ children }) {
  const { value, isOpen, setIsOpen } = useContext(SelectContext)
  
  return (
    <button
      onClick={() => setIsOpen(!isOpen)}
      className="flex items-center justify-between w-full px-4 py-2 border rounded"
    >
      {children || value || 'Select an option'}
      <ChevronDownIcon className={cn(
        "h-4 w-4 transition-transform",
        isOpen && "rotate-180"
      )} />
    </button>
  )
}

function SelectContent({ children }) {
  const { isOpen } = useContext(SelectContext)
  
  if (!isOpen) return null
  
  return (
    <div className="absolute top-full mt-1 w-full bg-white border rounded shadow-lg z-10">
      {children}
    </div>
  )
}

function SelectItem({ value, children }) {
  const { onChange, setIsOpen } = useContext(SelectContext)
  
  return (
    <button
      onClick={() => {
        onChange(value)
        setIsOpen(false)
      }}
      className="w-full px-4 py-2 text-left hover:bg-gray-100"
    >
      {children}
    </button>
  )
}

// Usage - Clean and intuitive
<Select value={selected} onChange={setSelected}>
  <SelectTrigger />
  <SelectContent>
    <SelectItem value="apple">Apple</SelectItem>
    <SelectItem value="banana">Banana</SelectItem>
    <SelectItem value="orange">Orange</SelectItem>
  </SelectContent>
</Select>
```

## Custom Hooks vs HOCs

**Why**: Both patterns share logic, but hooks are preferred for their simplicity and composability. HOCs still have specific use cases.

### Custom Hook Pattern (Preferred)

```javascript
// Custom hook for data fetching
function useApiData(url) {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true)
        const response = await fetch(url)
        if (!response.ok) throw new Error('Failed to fetch')
        const json = await response.json()
        setData(json)
      } catch (err) {
        setError(err)
      } finally {
        setLoading(false)
      }
    }
    
    fetchData()
  }, [url])
  
  return { data, loading, error }
}

// Usage - Simple and composable
function UserList() {
  const { data: users, loading, error } = useApiData('/api/users')
  
  if (loading) return <Spinner />
  if (error) return <ErrorMessage error={error} />
  
  return <UserGrid users={users} />
}
```

### HOC Pattern (Specific Use Cases)

```javascript
// HOC for error boundary behavior
function withErrorBoundary(Component, FallbackComponent) {
  return class WithErrorBoundary extends React.Component {
    state = { hasError: false, error: null }
    
    static getDerivedStateFromError(error) {
      return { hasError: true, error }
    }
    
    componentDidCatch(error, errorInfo) {
      console.error('Error caught by boundary:', error, errorInfo)
    }
    
    render() {
      if (this.state.hasError) {
        return <FallbackComponent error={this.state.error} />
      }
      
      return <Component {...this.props} />
    }
  }
}

// Usage
const SafeUserProfile = withErrorBoundary(UserProfile, ErrorFallback)
```

## HOC Use Cases (When Hooks Won't Work)

**Why**: HOCs are still valuable for lifecycle methods, error boundaries, and render hijacking.

### 1. Error Boundaries (Class Components Required)

```javascript
function withErrorBoundary(Component, FallbackComponent) {
  return class extends React.Component {
    state = { hasError: false }
    
    static getDerivedStateFromError(error) {
      return { hasError: true }
    }
    
    render() {
      if (this.state.hasError) {
        return <FallbackComponent />
      }
      return <Component {...this.props} />
    }
  }
}
```

### 2. Render Hijacking/Conditional Rendering

```javascript
function withAuth(Component) {
  return function WithAuthComponent(props) {
    const { user, loading } = useAuth()
    
    if (loading) return <Spinner />
    if (!user) return <Navigate to="/login" />
    
    return <Component {...props} user={user} />
  }
}

// Usage
const ProtectedDashboard = withAuth(Dashboard)
```

### 3. Props Manipulation/Injection

```javascript
function withTheme(Component) {
  return function WithThemeComponent(props) {
    const theme = useTheme()
    const enhancedProps = {
      ...props,
      theme,
      primaryColor: theme.colors.primary,
      isDarkMode: theme.mode === 'dark'
    }
    
    return <Component {...enhancedProps} />
  }
}
```

### 4. Performance Monitoring

```javascript
function withPerformanceTracking(Component) {
  return function WithPerformanceTracking(props) {
    useEffect(() => {
      const startTime = performance.now()
      
      return () => {
        const endTime = performance.now()
        const renderTime = endTime - startTime
        
        // Track to analytics
        analytics.track('component_render_time', {
          component: Component.name,
          duration: renderTime
        })
      }
    })
    
    return <Component {...props} />
  }
}
```

## Best Practices

1. **Prefer Hooks**: Use custom hooks for logic sharing in most cases
2. **HOCs for Cross-Cutting**: Use HOCs for error boundaries, auth, analytics
3. **Compound for Complex UI**: Use compound components for complex, multi-part components
4. **Render Props for Flexibility**: Use render props when maximum flexibility is needed
5. **Don't Over-Engineer**: Start simple, add patterns when clear benefits emerge

## Related Patterns

- [Performance Patterns](performance-patterns.md) - Optimization techniques
- [Context Patterns](context-patterns.md) - Context-based composition
- [Configuration Patterns](configuration-patterns.md) - Flexible component APIs