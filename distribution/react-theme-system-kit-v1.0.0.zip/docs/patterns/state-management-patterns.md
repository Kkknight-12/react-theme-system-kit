# State Management Patterns

**Category**: Complex State Handling  
**Purpose**: Managing complex application state effectively  
**Last Updated**: 2025-01-14

## 📚 Table of Contents

1. [Multi-step Form Pattern](#multi-step-form-pattern)
2. [Undo/Redo Pattern](#undoredo-pattern)
3. [Complex State Handling](#complex-state-handling)

## Multi-step Form Pattern

**Why**: Break complex forms into manageable steps with validation and progress tracking.

### Complete Multi-step Form Implementation

```javascript
// Form context for sharing state between steps
const FormContext = createContext()

function MultiStepForm({ steps, onComplete }) {
  const [currentStep, setCurrentStep] = useState(0)
  const [formData, setFormData] = useState({})
  const [errors, setErrors] = useState({})
  const [visitedSteps, setVisitedSteps] = useState(new Set([0]))
  
  const updateFormData = (stepData) => {
    setFormData(prev => ({ ...prev, ...stepData }))
  }
  
  const validateStep = async (stepIndex) => {
    const step = steps[stepIndex]
    if (!step.validate) return true
    
    try {
      await step.validate(formData)
      setErrors(prev => ({ ...prev, [stepIndex]: null }))
      return true
    } catch (error) {
      setErrors(prev => ({ ...prev, [stepIndex]: error }))
      return false
    }
  }
  
  const goToStep = async (stepIndex) => {
    // Validate current step before leaving
    const isValid = await validateStep(currentStep)
    if (!isValid && stepIndex > currentStep) return
    
    setCurrentStep(stepIndex)
    setVisitedSteps(prev => new Set([...prev, stepIndex]))
  }
  
  const nextStep = async () => {
    if (currentStep === steps.length - 1) {
      // Final submission
      const isValid = await validateStep(currentStep)
      if (isValid) {
        onComplete(formData)
      }
    } else {
      goToStep(currentStep + 1)
    }
  }
  
  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }
  
  const CurrentStepComponent = steps[currentStep].component
  
  return (
    <FormContext.Provider value={{
      formData,
      updateFormData,
      errors: errors[currentStep],
      currentStep,
      totalSteps: steps.length
    }}>
      <div className="max-w-2xl mx-auto">
        {/* Progress indicator */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            {steps.map((step, index) => (
              <div
                key={index}
                className="flex items-center"
              >
                <button
                  onClick={() => goToStep(index)}
                  disabled={!visitedSteps.has(index)}
                  className={cn(
                    "w-10 h-10 rounded-full flex items-center justify-center",
                    "border-2 transition-colors",
                    index === currentStep && "bg-blue-500 border-blue-500 text-white",
                    index < currentStep && "bg-green-500 border-green-500 text-white",
                    index > currentStep && visitedSteps.has(index) && "border-gray-300 hover:border-blue-300",
                    index > currentStep && !visitedSteps.has(index) && "border-gray-200 cursor-not-allowed"
                  )}
                >
                  {index < currentStep ? (
                    <CheckIcon className="h-5 w-5" />
                  ) : (
                    index + 1
                  )}
                </button>
                
                {index < steps.length - 1 && (
                  <div className={cn(
                    "w-full h-1 mx-2",
                    index < currentStep ? "bg-green-500" : "bg-gray-200"
                  )} />
                )}
              </div>
            ))}
          </div>
          
          <div className="text-center">
            <h2 className="text-xl font-semibold">{steps[currentStep].title}</h2>
            <p className="text-gray-600 mt-1">{steps[currentStep].description}</p>
          </div>
        </div>
        
        {/* Current step */}
        <div className="bg-white rounded-lg border p-6 mb-6">
          <CurrentStepComponent />
        </div>
        
        {/* Navigation */}
        <div className="flex justify-between">
          <Button
            variant="outline"
            onClick={prevStep}
            disabled={currentStep === 0}
          >
            Previous
          </Button>
          
          <Button
            onClick={nextStep}
          >
            {currentStep === steps.length - 1 ? 'Complete' : 'Next'}
          </Button>
        </div>
      </div>
    </FormContext.Provider>
  )
}

// Individual step components
function PersonalInfoStep() {
  const { formData, updateFormData, errors } = useContext(FormContext)
  const [localData, setLocalData] = useState({
    firstName: formData.firstName || '',
    lastName: formData.lastName || '',
    email: formData.email || ''
  })
  
  useEffect(() => {
    updateFormData(localData)
  }, [localData])
  
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <Input
          label="First Name"
          value={localData.firstName}
          onChange={(e) => setLocalData(prev => ({ ...prev, firstName: e.target.value }))}
          error={errors?.firstName}
          required
        />
        <Input
          label="Last Name"
          value={localData.lastName}
          onChange={(e) => setLocalData(prev => ({ ...prev, lastName: e.target.value }))}
          error={errors?.lastName}
          required
        />
      </div>
      
      <Input
        label="Email"
        type="email"
        value={localData.email}
        onChange={(e) => setLocalData(prev => ({ ...prev, email: e.target.value }))}
        error={errors?.email}
        required
      />
    </div>
  )
}

// Usage
const formSteps = [
  {
    title: 'Personal Information',
    description: 'Tell us about yourself',
    component: PersonalInfoStep,
    validate: async (data) => {
      const errors = {}
      if (!data.firstName) errors.firstName = 'First name is required'
      if (!data.lastName) errors.lastName = 'Last name is required'
      if (!data.email) errors.email = 'Email is required'
      else if (!/\S+@\S+\.\S+/.test(data.email)) errors.email = 'Email is invalid'
      
      if (Object.keys(errors).length > 0) throw errors
    }
  },
  {
    title: 'Address Information',
    description: 'Where can we reach you?',
    component: AddressStep,
    validate: async (data) => {
      // Address validation
    }
  },
  {
    title: 'Review & Submit',
    description: 'Check your information',
    component: ReviewStep
  }
]

<MultiStepForm 
  steps={formSteps}
  onComplete={async (data) => {
    await api.submitForm(data)
    navigate('/success')
  }}
/>
```

## Undo/Redo Pattern

**Why**: Allow users to undo/redo actions for better user experience.

### Generic Undo/Redo Hook

```javascript
function useUndoRedo(initialState) {
  const [history, setHistory] = useState([initialState])
  const [currentIndex, setCurrentIndex] = useState(0)
  
  const state = history[currentIndex]
  
  const setState = useCallback((newState) => {
    // Remove any future history when adding new state
    const newHistory = history.slice(0, currentIndex + 1)
    newHistory.push(newState)
    
    // Limit history size
    if (newHistory.length > 50) {
      newHistory.shift()
    } else {
      setCurrentIndex(currentIndex + 1)
    }
    
    setHistory(newHistory)
  }, [history, currentIndex])
  
  const undo = useCallback(() => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1)
    }
  }, [currentIndex])
  
  const redo = useCallback(() => {
    if (currentIndex < history.length - 1) {
      setCurrentIndex(currentIndex + 1)
    }
  }, [currentIndex, history.length])
  
  const canUndo = currentIndex > 0
  const canRedo = currentIndex < history.length - 1
  
  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.metaKey || e.ctrlKey) {
        if (e.key === 'z' && !e.shiftKey && canUndo) {
          e.preventDefault()
          undo()
        } else if ((e.key === 'z' && e.shiftKey || e.key === 'y') && canRedo) {
          e.preventDefault()
          redo()
        }
      }
    }
    
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [undo, redo, canUndo, canRedo])
  
  return {
    state,
    setState,
    undo,
    redo,
    canUndo,
    canRedo,
    history: history.length
  }
}

// Drawing app example
function DrawingCanvas() {
  const {
    state: drawing,
    setState: setDrawing,
    undo,
    redo,
    canUndo,
    canRedo
  } = useUndoRedo({ strokes: [] })
  
  const handleNewStroke = (stroke) => {
    setDrawing({
      strokes: [...drawing.strokes, stroke]
    })
  }
  
  return (
    <div>
      <div className="flex gap-2 mb-4">
        <Button
          onClick={undo}
          disabled={!canUndo}
          variant="outline"
          size="sm"
        >
          <UndoIcon className="h-4 w-4" />
          Undo
        </Button>
        <Button
          onClick={redo}
          disabled={!canRedo}
          variant="outline"
          size="sm"
        >
          <RedoIcon className="h-4 w-4" />
          Redo
        </Button>
      </div>
      
      <Canvas
        strokes={drawing.strokes}
        onNewStroke={handleNewStroke}
      />
    </div>
  )
}
```

### Text Editor with Undo/Redo

```javascript
function TextEditor() {
  const {
    state: content,
    setState: setContent,
    undo,
    redo,
    canUndo,
    canRedo
  } = useUndoRedo({ text: '', selection: null })
  
  const textareaRef = useRef(null)
  const [isTyping, setIsTyping] = useState(false)
  const typingTimeoutRef = useRef(null)
  
  const handleChange = (e) => {
    const newText = e.target.value
    const selection = {
      start: e.target.selectionStart,
      end: e.target.selectionEnd
    }
    
    // Debounce history updates while typing
    if (!isTyping) {
      setIsTyping(true)
    }
    
    clearTimeout(typingTimeoutRef.current)
    typingTimeoutRef.current = setTimeout(() => {
      setContent({ text: newText, selection })
      setIsTyping(false)
    }, 500)
    
    // Update display immediately
    textareaRef.current.value = newText
  }
  
  // Restore selection after undo/redo
  useEffect(() => {
    if (content.selection && textareaRef.current) {
      textareaRef.current.setSelectionRange(
        content.selection.start,
        content.selection.end
      )
    }
  }, [content])
  
  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <div className="flex gap-2">
          <Button onClick={undo} disabled={!canUndo} size="sm">
            Undo
          </Button>
          <Button onClick={redo} disabled={!canRedo} size="sm">
            Redo
          </Button>
        </div>
        <span className="text-sm text-gray-500">
          {content.text.length} characters
        </span>
      </div>
      
      <textarea
        ref={textareaRef}
        className="w-full h-64 p-4 border rounded-lg"
        defaultValue={content.text}
        onChange={handleChange}
        placeholder="Start typing..."
      />
    </div>
  )
}
```

## Complex State Handling

**Why**: Manage interconnected state with derived values and side effects.

### State Machine Pattern

```javascript
// Order processing state machine
const ORDER_STATES = {
  DRAFT: 'draft',
  SUBMITTED: 'submitted',
  PROCESSING: 'processing',
  SHIPPED: 'shipped',
  DELIVERED: 'delivered',
  CANCELLED: 'cancelled'
}

const ORDER_TRANSITIONS = {
  [ORDER_STATES.DRAFT]: [ORDER_STATES.SUBMITTED, ORDER_STATES.CANCELLED],
  [ORDER_STATES.SUBMITTED]: [ORDER_STATES.PROCESSING, ORDER_STATES.CANCELLED],
  [ORDER_STATES.PROCESSING]: [ORDER_STATES.SHIPPED, ORDER_STATES.CANCELLED],
  [ORDER_STATES.SHIPPED]: [ORDER_STATES.DELIVERED],
  [ORDER_STATES.DELIVERED]: [],
  [ORDER_STATES.CANCELLED]: []
}

function useOrderStateMachine(initialState = ORDER_STATES.DRAFT) {
  const [state, setState] = useState(initialState)
  const [history, setHistory] = useState([{ state: initialState, timestamp: Date.now() }])
  
  const canTransitionTo = (targetState) => {
    return ORDER_TRANSITIONS[state]?.includes(targetState) || false
  }
  
  const transitionTo = (targetState, metadata = {}) => {
    if (!canTransitionTo(targetState)) {
      throw new Error(`Cannot transition from ${state} to ${targetState}`)
    }
    
    setState(targetState)
    setHistory(prev => [...prev, {
      state: targetState,
      previousState: state,
      timestamp: Date.now(),
      metadata
    }])
  }
  
  const getAvailableTransitions = () => {
    return ORDER_TRANSITIONS[state] || []
  }
  
  return {
    state,
    canTransitionTo,
    transitionTo,
    getAvailableTransitions,
    history,
    isTerminal: ORDER_TRANSITIONS[state]?.length === 0
  }
}

// Usage in order component
function OrderManager({ order }) {
  const {
    state,
    canTransitionTo,
    transitionTo,
    getAvailableTransitions,
    history
  } = useOrderStateMachine(order.status)
  
  const handleStatusChange = async (newStatus) => {
    try {
      await api.updateOrderStatus(order.id, newStatus)
      transitionTo(newStatus, { updatedBy: currentUser.id })
      toast.success(`Order status updated to ${newStatus}`)
    } catch (error) {
      toast.error('Failed to update order status')
    }
  }
  
  return (
    <div className="space-y-6">
      {/* Current status */}
      <div className="bg-white rounded-lg border p-6">
        <h3 className="text-lg font-semibold mb-4">Order Status</h3>
        <div className="flex items-center gap-4">
          <Badge variant={state === ORDER_STATES.CANCELLED ? 'danger' : 'primary'}>
            {state}
          </Badge>
          <span className="text-sm text-gray-500">
            Last updated: {formatRelativeTime(history[history.length - 1].timestamp)}
          </span>
        </div>
      </div>
      
      {/* Available actions */}
      {getAvailableTransitions().length > 0 && (
        <div className="bg-white rounded-lg border p-6">
          <h3 className="text-lg font-semibold mb-4">Update Status</h3>
          <div className="flex gap-2">
            {getAvailableTransitions().map(transition => (
              <Button
                key={transition}
                onClick={() => handleStatusChange(transition)}
                variant={transition === ORDER_STATES.CANCELLED ? 'danger' : 'primary'}
              >
                Mark as {transition}
              </Button>
            ))}
          </div>
        </div>
      )}
      
      {/* History */}
      <div className="bg-white rounded-lg border p-6">
        <h3 className="text-lg font-semibold mb-4">Status History</h3>
        <div className="space-y-3">
          {history.map((entry, index) => (
            <div key={index} className="flex items-center gap-3 text-sm">
              <div className="w-2 h-2 bg-gray-400 rounded-full" />
              <span className="font-medium">{entry.state}</span>
              <span className="text-gray-500">
                {formatDateTime(entry.timestamp)}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
```

### Complex Filter State

```javascript
function useComplexFilters(initialFilters) {
  const [filters, setFilters] = useState(initialFilters)
  const [savedFilterSets, setSavedFilterSets] = useState([])
  
  // Derived state
  const activeFilterCount = useMemo(() => {
    return Object.entries(filters).reduce((count, [key, value]) => {
      const initial = initialFilters[key]
      if (Array.isArray(value)) {
        return count + (value.length > 0 ? 1 : 0)
      }
      return count + (value !== initial ? 1 : 0)
    }, 0)
  }, [filters, initialFilters])
  
  const hasActiveFilters = activeFilterCount > 0
  
  // Filter operations
  const updateFilter = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }))
  }
  
  const resetFilters = () => {
    setFilters(initialFilters)
  }
  
  const resetFilter = (key) => {
    setFilters(prev => ({ ...prev, [key]: initialFilters[key] }))
  }
  
  // Saved filter sets
  const saveFilterSet = (name) => {
    setSavedFilterSets(prev => [
      ...prev,
      {
        id: Date.now(),
        name,
        filters: { ...filters },
        createdAt: new Date()
      }
    ])
  }
  
  const loadFilterSet = (filterSetId) => {
    const filterSet = savedFilterSets.find(fs => fs.id === filterSetId)
    if (filterSet) {
      setFilters(filterSet.filters)
    }
  }
  
  const deleteFilterSet = (filterSetId) => {
    setSavedFilterSets(prev => prev.filter(fs => fs.id !== filterSetId))
  }
  
  // Serialize/deserialize for URL
  const serializeFilters = () => {
    return btoa(JSON.stringify(filters))
  }
  
  const deserializeFilters = (serialized) => {
    try {
      const decoded = JSON.parse(atob(serialized))
      setFilters(decoded)
    } catch (error) {
      console.error('Failed to deserialize filters')
    }
  }
  
  return {
    filters,
    updateFilter,
    resetFilters,
    resetFilter,
    activeFilterCount,
    hasActiveFilters,
    savedFilterSets,
    saveFilterSet,
    loadFilterSet,
    deleteFilterSet,
    serializeFilters,
    deserializeFilters
  }
}

// Usage in a product filter component
function ProductFilters({ onFiltersChange }) {
  const {
    filters,
    updateFilter,
    resetFilters,
    activeFilterCount,
    savedFilterSets,
    saveFilterSet,
    loadFilterSet
  } = useComplexFilters({
    search: '',
    categories: [],
    priceRange: [0, 1000],
    brands: [],
    inStock: false,
    sortBy: 'relevance'
  })
  
  const [showSaveDialog, setShowSaveDialog] = useState(false)
  
  useEffect(() => {
    onFiltersChange(filters)
  }, [filters, onFiltersChange])
  
  return (
    <div className="space-y-6">
      {/* Active filters summary */}
      {activeFilterCount > 0 && (
        <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
          <span className="text-sm font-medium">
            {activeFilterCount} active filter{activeFilterCount > 1 ? 's' : ''}
          </span>
          <button
            onClick={resetFilters}
            className="text-sm text-blue-600 hover:text-blue-700"
          >
            Clear all
          </button>
        </div>
      )}
      
      {/* Saved filter sets */}
      {savedFilterSets.length > 0 && (
        <div>
          <h3 className="text-sm font-medium mb-2">Saved Filters</h3>
          <div className="space-y-2">
            {savedFilterSets.map(filterSet => (
              <button
                key={filterSet.id}
                onClick={() => loadFilterSet(filterSet.id)}
                className="w-full text-left p-2 border rounded hover:bg-gray-50"
              >
                <div className="flex items-center justify-between">
                  <span className="font-medium">{filterSet.name}</span>
                  <span className="text-xs text-gray-500">
                    {formatDate(filterSet.createdAt)}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
      
      {/* Filter controls */}
      <div className="space-y-4">
        {/* Search */}
        <Input
          placeholder="Search products..."
          value={filters.search}
          onChange={(e) => updateFilter('search', e.target.value)}
        />
        
        {/* Categories */}
        <div>
          <label className="block text-sm font-medium mb-2">Categories</label>
          <CategorySelector
            selected={filters.categories}
            onChange={(categories) => updateFilter('categories', categories)}
          />
        </div>
        
        {/* Price range */}
        <div>
          <label className="block text-sm font-medium mb-2">
            Price: ${filters.priceRange[0]} - ${filters.priceRange[1]}
          </label>
          <RangeSlider
            min={0}
            max={1000}
            value={filters.priceRange}
            onChange={(range) => updateFilter('priceRange', range)}
          />
        </div>
        
        {/* Save current filters */}
        <Button
          onClick={() => setShowSaveDialog(true)}
          variant="outline"
          size="sm"
          className="w-full"
        >
          Save Current Filters
        </Button>
      </div>
      
      {/* Save dialog */}
      <SaveFilterDialog
        isOpen={showSaveDialog}
        onClose={() => setShowSaveDialog(false)}
        onSave={(name) => {
          saveFilterSet(name)
          setShowSaveDialog(false)
        }}
      />
    </div>
  )
}
```

## Best Practices

1. **State Colocation**: Keep state as close to where it's used as possible
2. **Derived State**: Calculate values from state rather than storing redundant data
3. **State Machines**: Use for complex workflows with defined transitions
4. **Immutability**: Always create new objects/arrays when updating state
5. **Persistence**: Consider localStorage for form drafts and user preferences
6. **Performance**: Use useMemo for expensive calculations from state

## Related Patterns

- [Data Fetching Patterns](data-fetching-patterns.md) - Managing server state
- [Performance Patterns](performance-patterns.md) - Optimizing state updates
- [Context Patterns](context-patterns.md) - Sharing state across components