# Ref Patterns

**Category**: React Refs and Imperative APIs  
**Purpose**: DOM access, imperative APIs, and performance optimizations with refs  
**Last Updated**: 2025-01-14

## 📚 Table of Contents

1. [DOM Element Access](#dom-element-access)
2. [forwardRef Pattern](#forwardref-pattern)
3. [Imperative APIs with useImperativeHandle](#imperative-apis-with-useimperativehandle)
4. [When to Use Refs vs State](#when-to-use-refs-vs-state)
5. [Debouncing & Throttling Patterns](#debouncing--throttling-patterns)
6. [useLayoutEffect for DOM Measurements](#uselayouteffect-for-dom-measurements)

## DOM Element Access

**Why**: Direct DOM manipulation for focus management, scroll control, or third-party library integration.

### Basic DOM Ref Usage

```javascript
function SearchForm() {
  const inputRef = useRef(null)
  
  useEffect(() => {
    // Auto-focus on mount
    inputRef.current?.focus()
  }, [])
  
  const handleReset = () => {
    inputRef.current.value = ''
    inputRef.current.focus()
  }
  
  return (
    <form>
      <input 
        ref={inputRef}
        type="search"
        placeholder="Search..."
      />
      <button type="button" onClick={handleReset}>
        Clear
      </button>
    </form>
  )
}
```

### Scroll Management

```javascript
function MessageList({ messages }) {
  const listRef = useRef(null)
  const [autoScroll, setAutoScroll] = useState(true)
  
  // Auto-scroll to bottom on new messages
  useEffect(() => {
    if (autoScroll && listRef.current) {
      listRef.current.scrollTop = listRef.current.scrollHeight
    }
  }, [messages, autoScroll])
  
  // Detect if user scrolled up
  const handleScroll = () => {
    if (listRef.current) {
      const { scrollTop, scrollHeight, clientHeight } = listRef.current
      const isAtBottom = scrollHeight - scrollTop - clientHeight < 10
      setAutoScroll(isAtBottom)
    }
  }
  
  return (
    <div 
      ref={listRef}
      className="h-96 overflow-auto"
      onScroll={handleScroll}
    >
      {messages.map(msg => (
        <Message key={msg.id} {...msg} />
      ))}
    </div>
  )
}
```

## forwardRef Pattern

**Why**: Pass refs through component boundaries to access child DOM elements or imperative APIs.

### Basic forwardRef

```javascript
// Custom Input component that forwards ref
const Input = forwardRef(({ label, error, ...props }, ref) => {
  const id = useId()
  
  return (
    <div className="space-y-1">
      <label htmlFor={id} className="block text-sm font-medium">
        {label}
      </label>
      <input
        ref={ref}
        id={id}
        className={cn(
          "w-full px-3 py-2 border rounded-md",
          error && "border-red-500"
        )}
        {...props}
      />
      {error && (
        <p className="text-sm text-red-600">{error}</p>
      )}
    </div>
  )
})

// Usage
function LoginForm() {
  const emailRef = useRef(null)
  const passwordRef = useRef(null)
  
  const focusFirstError = () => {
    if (!emailRef.current.value) {
      emailRef.current.focus()
    } else if (!passwordRef.current.value) {
      passwordRef.current.focus()
    }
  }
  
  return (
    <form>
      <Input ref={emailRef} label="Email" type="email" />
      <Input ref={passwordRef} label="Password" type="password" />
      <button onClick={focusFirstError}>Submit</button>
    </form>
  )
}
```

### Ref to Custom Component Method

```javascript
// Video player with imperative API
const VideoPlayer = forwardRef(({ src }, ref) => {
  const videoRef = useRef(null)
  const [isPlaying, setIsPlaying] = useState(false)
  
  useImperativeHandle(ref, () => ({
    play: () => {
      videoRef.current?.play()
      setIsPlaying(true)
    },
    pause: () => {
      videoRef.current?.pause()
      setIsPlaying(false)
    },
    seekTo: (time) => {
      if (videoRef.current) {
        videoRef.current.currentTime = time
      }
    }
  }), [])
  
  return (
    <div className="relative">
      <video ref={videoRef} src={src} />
      <div className="absolute bottom-4 left-4">
        {isPlaying ? 'Playing' : 'Paused'}
      </div>
    </div>
  )
})

// Usage
function VideoPage() {
  const playerRef = useRef(null)
  
  return (
    <div>
      <VideoPlayer ref={playerRef} src="video.mp4" />
      <div className="flex gap-2 mt-4">
        <button onClick={() => playerRef.current?.play()}>
          Play
        </button>
        <button onClick={() => playerRef.current?.pause()}>
          Pause
        </button>
        <button onClick={() => playerRef.current?.seekTo(30)}>
          Skip to 0:30
        </button>
      </div>
    </div>
  )
}
```

## Imperative APIs with useImperativeHandle

**Why**: Expose specific methods from child components while hiding internal implementation.

### Form with Imperative Validation

```javascript
const Form = forwardRef(({ children, onSubmit }, ref) => {
  const [errors, setErrors] = useState({})
  const fieldsRef = useRef({})
  
  useImperativeHandle(ref, () => ({
    validate: () => {
      const newErrors = {}
      let isValid = true
      
      Object.entries(fieldsRef.current).forEach(([name, field]) => {
        if (field.validate) {
          const error = field.validate()
          if (error) {
            newErrors[name] = error
            isValid = false
          }
        }
      })
      
      setErrors(newErrors)
      return isValid
    },
    
    reset: () => {
      Object.values(fieldsRef.current).forEach(field => {
        if (field.reset) field.reset()
      })
      setErrors({})
    },
    
    focusFirstError: () => {
      const firstError = Object.entries(errors)[0]
      if (firstError) {
        const [name] = firstError
        fieldsRef.current[name]?.focus?.()
      }
    }
  }), [errors])
  
  const registerField = (name, fieldRef) => {
    fieldsRef.current[name] = fieldRef
  }
  
  return (
    <form onSubmit={onSubmit}>
      {React.Children.map(children, child => {
        if (React.isValidElement(child) && child.props.name) {
          return React.cloneElement(child, {
            error: errors[child.props.name],
            registerField
          })
        }
        return child
      })}
    </form>
  )
})

// Field component
const TextField = forwardRef(({ 
  name, 
  label, 
  required, 
  error, 
  registerField,
  ...props 
}, ref) => {
  const inputRef = useRef(null)
  const [value, setValue] = useState('')
  
  useEffect(() => {
    if (registerField) {
      registerField(name, {
        validate: () => {
          if (required && !value) {
            return `${label} is required`
          }
          return null
        },
        reset: () => setValue(''),
        focus: () => inputRef.current?.focus()
      })
    }
  }, [name, value, required, label, registerField])
  
  return (
    <div>
      <label>{label}</label>
      <input
        ref={inputRef}
        value={value}
        onChange={(e) => setValue(e.target.value)}
        {...props}
      />
      {error && <span className="text-red-500">{error}</span>}
    </div>
  )
})

// Usage
function ContactForm() {
  const formRef = useRef(null)
  
  const handleSubmit = (e) => {
    e.preventDefault()
    
    if (formRef.current?.validate()) {
      // Submit form
      console.log('Form is valid!')
    } else {
      formRef.current?.focusFirstError()
    }
  }
  
  return (
    <>
      <Form ref={formRef} onSubmit={handleSubmit}>
        <TextField name="name" label="Name" required />
        <TextField name="email" label="Email" type="email" required />
        <TextField name="message" label="Message" />
        <button type="submit">Submit</button>
      </Form>
      
      <button onClick={() => formRef.current?.reset()}>
        Reset Form
      </button>
    </>
  )
}
```

## When to Use Refs vs State

**Why**: Refs don't trigger re-renders. Use them for values that don't affect visual output.

### Use State When:
- Value affects what's rendered
- Value is displayed in UI
- Changes should trigger effects

### Use Refs When:
- Storing DOM elements
- Storing timeout/interval IDs
- Storing previous values
- Storing values for callbacks
- Avoiding re-renders

```javascript
function Timer() {
  const [time, setTime] = useState(0)
  const [isRunning, setIsRunning] = useState(false)
  
  // Use ref for interval ID (doesn't affect UI)
  const intervalRef = useRef(null)
  
  // Use ref for callback to avoid recreating interval
  const callbackRef = useRef()
  callbackRef.current = () => {
    setTime(t => t + 1)
  }
  
  useEffect(() => {
    if (isRunning) {
      intervalRef.current = setInterval(() => {
        callbackRef.current()
      }, 1000)
    } else {
      clearInterval(intervalRef.current)
    }
    
    return () => clearInterval(intervalRef.current)
  }, [isRunning])
  
  const reset = () => {
    setTime(0)
    setIsRunning(false)
    clearInterval(intervalRef.current)
  }
  
  return (
    <div>
      <div>Time: {time}s</div>
      <button onClick={() => setIsRunning(!isRunning)}>
        {isRunning ? 'Pause' : 'Start'}
      </button>
      <button onClick={reset}>Reset</button>
    </div>
  )
}
```

## Debouncing & Throttling Patterns

**Why**: Optimize performance for frequent events (scroll, resize, input).

### Debounced Search

```javascript
function useDebounce(value, delay) {
  const [debouncedValue, setDebouncedValue] = useState(value)
  
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedValue(value)
    }, delay)
    
    return () => clearTimeout(timer)
  }, [value, delay])
  
  return debouncedValue
}

// Search component
function Search({ onSearch }) {
  const [query, setQuery] = useState('')
  const debouncedQuery = useDebounce(query, 300)
  
  useEffect(() => {
    if (debouncedQuery) {
      onSearch(debouncedQuery)
    }
  }, [debouncedQuery, onSearch])
  
  return (
    <input
      type="search"
      value={query}
      onChange={(e) => setQuery(e.target.value)}
      placeholder="Search..."
    />
  )
}
```

### Throttled Scroll Handler

```javascript
function useThrottle(callback, delay) {
  const lastRunRef = useRef(0)
  const timeoutRef = useRef(null)
  
  const throttledCallback = useCallback((...args) => {
    const now = Date.now()
    const timeSinceLastRun = now - lastRunRef.current
    
    if (timeSinceLastRun >= delay) {
      callback(...args)
      lastRunRef.current = now
    } else {
      clearTimeout(timeoutRef.current)
      timeoutRef.current = setTimeout(() => {
        callback(...args)
        lastRunRef.current = Date.now()
      }, delay - timeSinceLastRun)
    }
  }, [callback, delay])
  
  return throttledCallback
}

// Infinite scroll component
function InfiniteList({ loadMore }) {
  const listRef = useRef(null)
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(false)
  
  const handleScroll = useThrottle(() => {
    if (listRef.current && !loading) {
      const { scrollTop, scrollHeight, clientHeight } = listRef.current
      const scrollPercentage = (scrollTop + clientHeight) / scrollHeight
      
      if (scrollPercentage > 0.8) {
        setLoading(true)
        loadMore().then(newItems => {
          setItems(prev => [...prev, ...newItems])
          setLoading(false)
        })
      }
    }
  }, 200)
  
  return (
    <div 
      ref={listRef}
      onScroll={handleScroll}
      className="h-96 overflow-auto"
    >
      {items.map(item => (
        <div key={item.id}>{item.name}</div>
      ))}
      {loading && <Spinner />}
    </div>
  )
}
```

### Auto-save Pattern

```javascript
function AutoSaveForm({ initialData, onSave }) {
  const [formData, setFormData] = useState(initialData)
  const [saveStatus, setSaveStatus] = useState('saved')
  const saveTimeoutRef = useRef(null)
  
  // Debounced save
  useEffect(() => {
    if (JSON.stringify(formData) !== JSON.stringify(initialData)) {
      setSaveStatus('saving')
      
      clearTimeout(saveTimeoutRef.current)
      saveTimeoutRef.current = setTimeout(() => {
        onSave(formData).then(() => {
          setSaveStatus('saved')
        }).catch(() => {
          setSaveStatus('error')
        })
      }, 1000)
    }
    
    return () => clearTimeout(saveTimeoutRef.current)
  }, [formData, initialData, onSave])
  
  const updateField = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }))
    setSaveStatus('typing')
  }
  
  return (
    <form>
      <div className="flex justify-between mb-4">
        <h2>Edit Profile</h2>
        <span className="text-sm text-gray-500">
          {saveStatus === 'typing' && 'Typing...'}
          {saveStatus === 'saving' && 'Saving...'}
          {saveStatus === 'saved' && 'All changes saved'}
          {saveStatus === 'error' && 'Error saving'}
        </span>
      </div>
      
      <input
        value={formData.name}
        onChange={(e) => updateField('name', e.target.value)}
        placeholder="Name"
      />
      
      <textarea
        value={formData.bio}
        onChange={(e) => updateField('bio', e.target.value)}
        placeholder="Bio"
      />
    </form>
  )
}
```

## useLayoutEffect for DOM Measurements

**Why**: When you need to measure DOM elements and adjust UI based on those measurements without visual flickering.

### The Problem: Flickering UI

When measuring DOM elements in `useEffect` and then adjusting them, users see a flash of the initial render:

```javascript
// ❌ Problem: Visible flicker
function ResponsiveNavigation({ items }) {
  const [visibleItems, setVisibleItems] = useState(items.length)
  const navRef = useRef(null)
  
  useEffect(() => {
    if (!navRef.current) return
    
    const container = navRef.current
    const { width: containerWidth } = container.getBoundingClientRect()
    
    // Get all item widths
    const children = [...container.children]
    let totalWidth = 0
    let lastVisible = 0
    
    for (let i = 0; i < children.length - 1; i++) { // -1 to exclude "more" button
      totalWidth += children[i].getBoundingClientRect().width
      if (totalWidth <= containerWidth - 100) { // Reserve space for "more" button
        lastVisible = i
      }
    }
    
    setVisibleItems(lastVisible + 1)
  }, [items])
  
  const showMore = visibleItems < items.length
  const displayItems = items.slice(0, visibleItems)
  
  return (
    <nav ref={navRef} className="flex gap-4">
      {/* Initial render shows ALL items, then hides some = FLICKER! */}
      {displayItems.map(item => (
        <a key={item.id} href={item.href}>{item.name}</a>
      ))}
      {showMore && <button>More...</button>}
    </nav>
  )
}
```

### The Solution: useLayoutEffect

```javascript
// ✅ Solution: No flicker!
function ResponsiveNavigation({ items }) {
  const [visibleItems, setVisibleItems] = useState(-1) // -1 = not calculated yet
  const navRef = useRef(null)
  const moreButtonRef = useRef(null)
  
  useLayoutEffect(() => {
    if (!navRef.current || !moreButtonRef.current) return
    
    const calculateVisibleItems = () => {
      const container = navRef.current
      const moreButton = moreButtonRef.current
      const { width: containerWidth } = container.getBoundingClientRect()
      const { width: moreButtonWidth } = moreButton.getBoundingClientRect()
      
      const children = [...container.children]
      let totalWidth = 0
      let lastVisible = items.length - 1
      
      // Calculate how many items fit with "more" button
      for (let i = 0; i < children.length - 1; i++) {
        const childWidth = children[i].getBoundingClientRect().width
        if (totalWidth + childWidth + moreButtonWidth > containerWidth) {
          lastVisible = i - 1
          break
        }
        totalWidth += childWidth
      }
      
      setVisibleItems(Math.max(1, lastVisible + 1)) // Always show at least 1
    }
    
    calculateVisibleItems()
    
    // Recalculate on resize
    window.addEventListener('resize', calculateVisibleItems)
    return () => window.removeEventListener('resize', calculateVisibleItems)
  }, [items])
  
  // First render: show all items but hidden
  if (visibleItems === -1) {
    return (
      <nav ref={navRef} className="flex gap-4 opacity-0">
        {items.map(item => (
          <a key={item.id} href={item.href}>{item.name}</a>
        ))}
        <button ref={moreButtonRef}>More...</button>
      </nav>
    )
  }
  
  const showMore = visibleItems < items.length
  const displayItems = items.slice(0, visibleItems)
  
  return (
    <nav ref={navRef} className="flex gap-4">
      {displayItems.map(item => (
        <a key={item.id} href={item.href}>{item.name}</a>
      ))}
      {showMore && <button ref={moreButtonRef}>More...</button>}
    </nav>
  )
}
```

### Understanding the Difference

**useEffect**: Runs asynchronously after browser paint
- Browser renders initial state → Paint → useEffect runs → State update → Re-render → Paint again (FLICKER!)
- Good for: Most side effects, data fetching, subscriptions

**useLayoutEffect**: Runs synchronously before browser paint
- Browser renders → useLayoutEffect runs → State update → Re-render → Paint once (NO FLICKER!)
- Good for: DOM measurements, preventing visual flashes
- Warning: Can hurt performance if overused (blocks painting)

### Browser Rendering Process

```javascript
// How browsers work (simplified)
// 1. Task Queue processes JavaScript
// 2. Browser aims for 60 FPS (paint every ~16ms)
// 3. Synchronous code blocks painting

// ❌ This blocks painting
function badExample() {
  element.style.color = 'red'
  blockFor(1000) // Synchronous delay
  element.style.color = 'blue'
  blockFor(1000)
  element.style.color = 'green'
  // User only sees green - no intermediate states!
}

// ✅ This allows painting between
function goodExample() {
  element.style.color = 'red'
  setTimeout(() => {
    element.style.color = 'blue'
    setTimeout(() => {
      element.style.color = 'green'
    }, 0)
  }, 0)
  // User sees red → blue → green transitions
}
```

### SSR Considerations

**Problem**: `useLayoutEffect` doesn't run on the server, causing hydration mismatches.

```javascript
// ❌ SSR Problem: Flicker returns on server-rendered pages
function ResponsiveNav({ items }) {
  const [visibleItems, setVisibleItems] = useState(-1)
  
  useLayoutEffect(() => {
    // This won't run on server!
    // Initial HTML shows all items, then hides some after hydration
  }, [])
}

// ✅ SSR Solution: Show loading state or subset
function ResponsiveNav({ items }) {
  const [mounted, setMounted] = useState(false)
  const [visibleItems, setVisibleItems] = useState(-1)
  
  useEffect(() => {
    setMounted(true)
  }, [])
  
  useLayoutEffect(() => {
    if (!mounted) return
    // Now safe to measure
  }, [mounted])
  
  // SSR: Show first 3 items or loading state
  if (!mounted) {
    return (
      <nav className="flex gap-4">
        {items.slice(0, 3).map(item => (
          <a key={item.id} href={item.href}>{item.name}</a>
        ))}
        {items.length > 3 && <button>More...</button>}
      </nav>
    )
  }
  
  // Client: Show responsive navigation
  // ... rest of the component
}
```

### Common Use Cases

1. **Tooltip/Popover Positioning**
```javascript
function Tooltip({ children, content }) {
  const [position, setPosition] = useState({ top: 0, left: 0 })
  const triggerRef = useRef(null)
  const tooltipRef = useRef(null)
  const [show, setShow] = useState(false)
  
  useLayoutEffect(() => {
    if (!show || !triggerRef.current || !tooltipRef.current) return
    
    const trigger = triggerRef.current.getBoundingClientRect()
    const tooltip = tooltipRef.current.getBoundingClientRect()
    
    // Calculate position without causing reflow
    setPosition({
      top: trigger.top - tooltip.height - 8,
      left: trigger.left + (trigger.width - tooltip.width) / 2
    })
  }, [show])
  
  return (
    <>
      <span 
        ref={triggerRef}
        onMouseEnter={() => setShow(true)}
        onMouseLeave={() => setShow(false)}
      >
        {children}
      </span>
      {show && (
        <div 
          ref={tooltipRef}
          className="tooltip"
          style={{ 
            position: 'fixed',
            top: position.top,
            left: position.left
          }}
        >
          {content}
        </div>
      )}
    </>
  )
}
```

2. **Text Truncation with "Show More"**
```javascript
function TruncatedText({ text, maxLines = 3 }) {
  const [isTruncated, setIsTruncated] = useState(false)
  const [isExpanded, setIsExpanded] = useState(false)
  const textRef = useRef(null)
  
  useLayoutEffect(() => {
    if (!textRef.current) return
    
    const element = textRef.current
    const lineHeight = parseInt(getComputedStyle(element).lineHeight)
    const maxHeight = lineHeight * maxLines
    
    setIsTruncated(element.scrollHeight > maxHeight)
  }, [text, maxLines])
  
  return (
    <div>
      <p 
        ref={textRef}
        className={cn(
          "overflow-hidden",
          !isExpanded && isTruncated && `line-clamp-${maxLines}`
        )}
      >
        {text}
      </p>
      {isTruncated && (
        <button onClick={() => setIsExpanded(!isExpanded)}>
          {isExpanded ? 'Show Less' : 'Show More'}
        </button>
      )}
    </div>
  )
}
```

### Performance Guidelines

1. **Use useEffect by default** - Only use useLayoutEffect when you see visual issues
2. **Keep it fast** - useLayoutEffect blocks painting, so keep calculations minimal
3. **Batch DOM reads** - Read all measurements at once, then update state once
4. **Consider CSS alternatives** - Sometimes pure CSS (like container queries) can solve the problem

## Best Practices

1. **Don't Overuse Refs**: Prefer state for values that affect rendering
2. **Clean Up**: Always clean up timers and listeners
3. **Stable References**: Use refs to maintain stable callback references
4. **Type Safety**: Type your refs properly in TypeScript
5. **Document Intent**: Comment why you're using a ref vs state

## Related Patterns

- [Performance Patterns](performance-patterns.md) - Using refs for optimization
- [State Management](state-management-patterns.md) - When to use state vs refs
- [UI Component Patterns](ui-component-patterns.md) - Refs in complex components