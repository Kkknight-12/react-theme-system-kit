# Loading & Animation Patterns

**Category**: Loading States and Animations  
**Purpose**: Smooth loading experiences and delightful animations  
**Last Updated**: 2025-01-14

## 📚 Table of Contents

1. [Skeleton Components](#skeleton-components)
2. [Progressive Loading Pattern](#progressive-loading-pattern)
3. [Framer Motion Patterns](#framer-motion-patterns)
4. [Micro-interactions](#micro-interactions)

## Skeleton Components

**Why**: Show content structure while loading to reduce perceived wait time.

### Basic Skeleton Components

```javascript
// Reusable skeleton pulse animation
const shimmer = cn(
  "relative overflow-hidden",
  "before:absolute before:inset-0",
  "before:-translate-x-full before:animate-[shimmer_2s_infinite]",
  "before:bg-gradient-to-r before:from-transparent",
  "before:via-white/60 before:to-transparent"
)

// Text skeleton
function TextSkeleton({ lines = 1, className }) {
  return (
    <div className={cn("space-y-3", className)}>
      {Array.from({ length: lines }).map((_, i) => (
        <div
          key={i}
          className={cn(
            "h-4 bg-gray-200 rounded",
            shimmer,
            // Last line is often shorter
            i === lines - 1 && lines > 1 && "w-3/4"
          )}
        />
      ))}
    </div>
  )
}

// Card skeleton
function CardSkeleton() {
  return (
    <div className="bg-white rounded-lg border p-6">
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className={cn("h-10 w-10 bg-gray-200 rounded-full", shimmer)} />
          <div>
            <div className={cn("h-4 w-32 bg-gray-200 rounded mb-2", shimmer)} />
            <div className={cn("h-3 w-24 bg-gray-200 rounded", shimmer)} />
          </div>
        </div>
        <div className={cn("h-8 w-20 bg-gray-200 rounded", shimmer)} />
      </div>
      
      {/* Content */}
      <TextSkeleton lines={3} className="mb-4" />
      
      {/* Footer */}
      <div className="flex gap-2">
        <div className={cn("h-8 w-16 bg-gray-200 rounded", shimmer)} />
        <div className={cn("h-8 w-16 bg-gray-200 rounded", shimmer)} />
      </div>
    </div>
  )
}

// Table skeleton
function TableSkeleton({ rows = 5, columns = 4 }) {
  return (
    <div className="overflow-hidden rounded-lg border">
      {/* Header */}
      <div className="bg-gray-50 border-b">
        <div className="grid grid-cols-4 gap-4 p-4">
          {Array.from({ length: columns }).map((_, i) => (
            <div key={i} className={cn("h-4 bg-gray-200 rounded", shimmer)} />
          ))}
        </div>
      </div>
      
      {/* Rows */}
      {Array.from({ length: rows }).map((_, rowIndex) => (
        <div key={rowIndex} className="border-b last:border-0">
          <div className="grid grid-cols-4 gap-4 p-4">
            {Array.from({ length: columns }).map((_, colIndex) => (
              <div 
                key={colIndex} 
                className={cn(
                  "h-4 bg-gray-200 rounded",
                  shimmer,
                  // Vary widths for realism
                  colIndex === 0 && "w-3/4",
                  colIndex === 2 && "w-1/2"
                )}
              />
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}
```

### Content-Specific Skeletons

```javascript
// User profile skeleton
function UserProfileSkeleton() {
  return (
    <div className="max-w-2xl mx-auto">
      {/* Header */}
      <div className="bg-white rounded-lg border p-6 mb-6">
        <div className="flex items-start gap-6">
          <div className={cn("h-24 w-24 bg-gray-200 rounded-full", shimmer)} />
          <div className="flex-1">
            <div className={cn("h-8 w-48 bg-gray-200 rounded mb-2", shimmer)} />
            <div className={cn("h-4 w-32 bg-gray-200 rounded mb-4", shimmer)} />
            <div className="flex gap-2">
              <div className={cn("h-9 w-24 bg-gray-200 rounded", shimmer)} />
              <div className={cn("h-9 w-24 bg-gray-200 rounded", shimmer)} />
            </div>
          </div>
        </div>
      </div>
      
      {/* Stats */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        {[1, 2, 3].map(i => (
          <div key={i} className="bg-white rounded-lg border p-4">
            <div className={cn("h-4 w-20 bg-gray-200 rounded mb-2", shimmer)} />
            <div className={cn("h-8 w-16 bg-gray-200 rounded", shimmer)} />
          </div>
        ))}
      </div>
      
      {/* Content */}
      <div className="bg-white rounded-lg border p-6">
        <div className={cn("h-6 w-32 bg-gray-200 rounded mb-4", shimmer)} />
        <TextSkeleton lines={5} />
      </div>
    </div>
  )
}

// Product grid skeleton
function ProductGridSkeleton({ count = 6 }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="bg-white rounded-lg border overflow-hidden">
          {/* Image */}
          <div className={cn("h-48 bg-gray-200", shimmer)} />
          
          {/* Details */}
          <div className="p-4">
            <div className={cn("h-4 w-3/4 bg-gray-200 rounded mb-2", shimmer)} />
            <div className={cn("h-3 w-1/2 bg-gray-200 rounded mb-3", shimmer)} />
            <div className="flex items-center justify-between">
              <div className={cn("h-5 w-20 bg-gray-200 rounded", shimmer)} />
              <div className={cn("h-8 w-8 bg-gray-200 rounded-full", shimmer)} />
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
```

## Progressive Loading Pattern

**Why**: Load and display content in stages for better perceived performance.

### Progressive Image Loading

```javascript
function ProgressiveImage({ 
  src, 
  placeholder, 
  alt,
  className,
  ...props 
}) {
  const [imageSrc, setImageSrc] = useState(placeholder)
  const [loading, setLoading] = useState(true)
  const imgRef = useRef(null)
  
  useEffect(() => {
    const img = new Image()
    img.src = src
    
    img.onload = () => {
      setImageSrc(src)
      setLoading(false)
    }
    
    // Cleanup
    return () => {
      img.onload = null
    }
  }, [src])
  
  return (
    <div className={cn("relative overflow-hidden", className)}>
      <img
        ref={imgRef}
        src={imageSrc}
        alt={alt}
        className={cn(
          "w-full h-full object-cover transition-all duration-300",
          loading && "blur-sm scale-105"
        )}
        {...props}
      />
      {loading && (
        <div className="absolute inset-0 bg-gray-100 animate-pulse" />
      )}
    </div>
  )
}

// Usage
<ProgressiveImage
  src="/high-res-image.jpg"
  placeholder="/low-res-placeholder.jpg"
  alt="Product image"
  className="aspect-square"
/>
```

### Progressive Content Loading

```javascript
function DashboardPage() {
  const [criticalData, setCriticalData] = useState(null)
  const [enhancedData, setEnhancedData] = useState(null)
  const [loading, setLoading] = useState({ critical: true, enhanced: true })
  
  // Load critical data first
  useEffect(() => {
    api.getCriticalDashboardData().then(data => {
      setCriticalData(data)
      setLoading(prev => ({ ...prev, critical: false }))
    })
  }, [])
  
  // Load enhanced data after critical
  useEffect(() => {
    if (!criticalData) return
    
    api.getEnhancedDashboardData().then(data => {
      setEnhancedData(data)
      setLoading(prev => ({ ...prev, enhanced: false }))
    })
  }, [criticalData])
  
  return (
    <div className="space-y-6">
      {/* Critical section - show skeleton or data */}
      {loading.critical ? (
        <StatsSkeleton />
      ) : (
        <StatsOverview data={criticalData.stats} />
      )}
      
      {/* Important but not critical */}
      {loading.critical ? (
        <ActivitySkeleton />
      ) : (
        <RecentActivity 
          activities={criticalData.recentActivity}
          detailed={enhancedData?.activityDetails}
        />
      )}
      
      {/* Enhanced features - progressive enhancement */}
      {!loading.enhanced && enhancedData && (
        <>
          <AdvancedAnalytics data={enhancedData.analytics} />
          <Recommendations items={enhancedData.recommendations} />
        </>
      )}
    </div>
  )
}
```

## Framer Motion Patterns

**Why**: Create smooth, physics-based animations for better UX.

### Page Transitions

```javascript
import { motion, AnimatePresence } from 'framer-motion'

// Page transition wrapper
function PageTransition({ children }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
    >
      {children}
    </motion.div>
  )
}

// Stagger children animation
function StaggerList({ items }) {
  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }
  
  const item = {
    hidden: { opacity: 0, x: -20 },
    show: { opacity: 1, x: 0 }
  }
  
  return (
    <motion.ul
      variants={container}
      initial="hidden"
      animate="show"
      className="space-y-4"
    >
      {items.map((listItem) => (
        <motion.li
          key={listItem.id}
          variants={item}
          className="p-4 bg-white rounded-lg border"
        >
          {listItem.content}
        </motion.li>
      ))}
    </motion.ul>
  )
}
```

### Interactive Animations

```javascript
// Hover card with spring animation
function HoverCard({ children }) {
  return (
    <motion.div
      className="p-6 bg-white rounded-lg border cursor-pointer"
      whileHover={{ 
        scale: 1.05,
        boxShadow: "0 10px 30px rgba(0,0,0,0.1)"
      }}
      whileTap={{ scale: 0.95 }}
      transition={{ type: "spring", stiffness: 300 }}
    >
      {children}
    </motion.div>
  )
}

// Drag to delete
function DraggableItem({ item, onDelete }) {
  const [isDragging, setIsDragging] = useState(false)
  
  return (
    <motion.div
      drag="x"
      dragConstraints={{ left: -200, right: 0 }}
      onDragStart={() => setIsDragging(true)}
      onDragEnd={(_, info) => {
        setIsDragging(false)
        if (info.offset.x < -100) {
          onDelete(item.id)
        }
      }}
      animate={{ x: 0 }}
      transition={{ type: "spring", stiffness: 500 }}
      className="relative"
    >
      {/* Delete indicator */}
      <div className="absolute inset-y-0 -left-20 flex items-center">
        <TrashIcon className="h-5 w-5 text-red-500" />
      </div>
      
      {/* Item content */}
      <div className={cn(
        "p-4 bg-white rounded-lg border",
        isDragging && "opacity-50"
      )}>
        {item.content}
      </div>
    </motion.div>
  )
}
```

### Layout Animations

```javascript
// Animated layout grid
function AnimatedGrid({ items, viewMode }) {
  return (
    <motion.div 
      layout
      className={cn(
        "grid gap-4",
        viewMode === 'grid' ? "grid-cols-3" : "grid-cols-1"
      )}
    >
      <AnimatePresence>
        {items.map(item => (
          <motion.div
            key={item.id}
            layout
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ duration: 0.3 }}
            className="bg-white rounded-lg border p-4"
          >
            {item.content}
          </motion.div>
        ))}
      </AnimatePresence>
    </motion.div>
  )
}

// Collapsible section
function CollapsibleSection({ title, children }) {
  const [isOpen, setIsOpen] = useState(false)
  
  return (
    <div className="border rounded-lg overflow-hidden">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full p-4 flex items-center justify-between hover:bg-gray-50"
      >
        <span className="font-medium">{title}</span>
        <motion.div
          animate={{ rotate: isOpen ? 180 : 0 }}
          transition={{ duration: 0.2 }}
        >
          <ChevronDownIcon className="h-5 w-5" />
        </motion.div>
      </button>
      
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0 }}
            animate={{ height: "auto" }}
            exit={{ height: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div className="p-4 border-t">
              {children}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
```

## Micro-interactions

**Why**: Small animations that provide feedback and delight users.

### Button Interactions

```javascript
// Success button animation
function SuccessButton({ onClick, children }) {
  const [isSuccess, setIsSuccess] = useState(false)
  
  const handleClick = async () => {
    try {
      await onClick()
      setIsSuccess(true)
      setTimeout(() => setIsSuccess(false), 2000)
    } catch (error) {
      // Handle error
    }
  }
  
  return (
    <motion.button
      onClick={handleClick}
      className="relative px-6 py-2 bg-blue-500 text-white rounded-lg overflow-hidden"
      whileTap={{ scale: 0.95 }}
    >
      <AnimatePresence mode="wait">
        {isSuccess ? (
          <motion.div
            key="success"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -20, opacity: 0 }}
            className="flex items-center gap-2"
          >
            <CheckIcon className="h-5 w-5" />
            <span>Success!</span>
          </motion.div>
        ) : (
          <motion.div
            key="default"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -20, opacity: 0 }}
          >
            {children}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.button>
  )
}

// Loading button
function LoadingButton({ onClick, children, ...props }) {
  const [isLoading, setIsLoading] = useState(false)
  
  const handleClick = async () => {
    setIsLoading(true)
    try {
      await onClick()
    } finally {
      setIsLoading(false)
    }
  }
  
  return (
    <button
      onClick={handleClick}
      disabled={isLoading}
      className="relative px-6 py-2 bg-blue-500 text-white rounded-lg disabled:opacity-50"
      {...props}
    >
      <span className={cn(isLoading && "invisible")}>
        {children}
      </span>
      
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center">
          <svg 
            className="animate-spin h-5 w-5" 
            viewBox="0 0 24 24"
          >
            <circle 
              className="opacity-25" 
              cx="12" 
              cy="12" 
              r="10" 
              stroke="currentColor" 
              strokeWidth="4" 
            />
            <path 
              className="opacity-75" 
              fill="currentColor" 
              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" 
            />
          </svg>
        </div>
      )}
    </button>
  )
}
```

### Notification Animations

```javascript
// Toast notification
function Toast({ message, type = 'info', onClose }) {
  useEffect(() => {
    const timer = setTimeout(onClose, 5000)
    return () => clearTimeout(timer)
  }, [onClose])
  
  const icons = {
    info: <InfoIcon className="h-5 w-5" />,
    success: <CheckCircleIcon className="h-5 w-5" />,
    warning: <AlertTriangleIcon className="h-5 w-5" />,
    error: <XCircleIcon className="h-5 w-5" />
  }
  
  const colors = {
    info: "bg-blue-500",
    success: "bg-green-500",
    warning: "bg-yellow-500",
    error: "bg-red-500"
  }
  
  return (
    <motion.div
      initial={{ x: 300, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: 300, opacity: 0 }}
      className={cn(
        "flex items-center gap-3 px-4 py-3 rounded-lg text-white shadow-lg",
        colors[type]
      )}
    >
      {icons[type]}
      <span className="flex-1">{message}</span>
      <button onClick={onClose}>
        <XIcon className="h-4 w-4" />
      </button>
    </motion.div>
  )
}

// Number counter animation
function AnimatedCounter({ value, duration = 1000 }) {
  const [displayValue, setDisplayValue] = useState(0)
  
  useEffect(() => {
    let startTime
    let animationFrame
    
    const animate = (timestamp) => {
      if (!startTime) startTime = timestamp
      const progress = Math.min((timestamp - startTime) / duration, 1)
      
      setDisplayValue(Math.floor(progress * value))
      
      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate)
      }
    }
    
    animationFrame = requestAnimationFrame(animate)
    
    return () => {
      if (animationFrame) {
        cancelAnimationFrame(animationFrame)
      }
    }
  }, [value, duration])
  
  return <span>{displayValue.toLocaleString()}</span>
}
```

## Best Practices

1. **Performance First**: Use CSS transforms over position changes
2. **Accessibility**: Respect prefers-reduced-motion
3. **Purposeful**: Every animation should have a clear purpose
4. **Consistent**: Use consistent timing and easing functions
5. **Subtle**: Less is often more with animations
6. **Test**: Test on lower-end devices

## Related Patterns

- [UI Component Patterns](ui-component-patterns.md) - Component structure
- [Performance Patterns](performance-patterns.md) - Animation performance
- [Data Fetching Patterns](data-fetching-patterns.md) - Loading states