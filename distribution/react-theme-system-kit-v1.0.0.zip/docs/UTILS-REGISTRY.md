# Utility Functions Registry - ALWAYS USE THESE UTILITIES

**CRITICAL**: Before creating ANY new utility function, check if it exists here. If it does, you MUST use it.

## Table of Contents
1. [Formatting Utilities](#formatting-utilities)
2. [Data Manipulation](#data-manipulation)
3. [Mock Data Generation](#mock-data-generation)
4. [Date & Time Utilities](#date--time-utilities)
5. [String Utilities](#string-utilities)
6. [Number Utilities](#number-utilities)
7. [Array Utilities](#array-utilities)
8. [Object Utilities](#object-utilities)
9. [Validation Utilities](#validation-utilities)
10. [Storage Utilities](#storage-utilities)
11. [API Utilities](#api-utilities)
12. [Style Utilities](#style-utilities)

---

## Formatting Utilities

### formatCurrency
**Location**: `utils/format.ts`  
**Import**: `import { formatCurrency } from '@/utils/format'`

```ts
formatCurrency(1234.56) // "$1,234.56"
formatCurrency(1234.56, 'EUR') // "€1,234.56"
formatCurrency(1234.56, 'GBP') // "£1,234.56"
formatCurrency(1234, 'USD', { decimals: 0 }) // "$1,234"
```

### formatNumber
**Location**: `utils/format.ts`  
**Import**: `import { formatNumber } from '@/utils/format'`

```ts
formatNumber(1234567) // "1,234,567"
formatNumber(1234.567, { decimals: 2 }) // "1,234.57"
formatNumber(0.123, { style: 'percent' }) // "12.3%"
formatNumber(1234567, { notation: 'compact' }) // "1.2M"
```

### formatDate
**Location**: `utils/format.ts`  
**Import**: `import { formatDate } from '@/utils/format'`

```ts
formatDate(new Date()) // "Jan 15, 2024"
formatDate('2024-01-15', 'full') // "Monday, January 15, 2024"
formatDate(new Date(), 'short') // "1/15/24"
formatDate(new Date(), 'time') // "3:45 PM"
formatDate(new Date(), 'datetime') // "Jan 15, 2024 at 3:45 PM"
```

### formatFileSize
**Location**: `utils/format.ts`  
**Import**: `import { formatFileSize } from '@/utils/format'`

```ts
formatFileSize(1024) // "1 KB"
formatFileSize(1048576) // "1 MB"
formatFileSize(1073741824) // "1 GB"
formatFileSize(1234567) // "1.18 MB"
```

### formatPhoneNumber
**Location**: `utils/format.ts`  
**Import**: `import { formatPhoneNumber } from '@/utils/format'`

```ts
formatPhoneNumber('1234567890') // "(123) 456-7890"
formatPhoneNumber('+11234567890') // "+1 (123) 456-7890"
formatPhoneNumber('1234567890', 'dots') // "123.456.7890"
```

---

## Data Manipulation

### groupBy
**Location**: `utils/data.ts`  
**Import**: `import { groupBy } from '@/utils/data'`

```ts
const users = [
  { id: 1, role: 'admin', name: 'John' },
  { id: 2, role: 'user', name: 'Jane' },
  { id: 3, role: 'admin', name: 'Bob' }
]

groupBy(users, 'role')
// { admin: [...], user: [...] }

groupBy(users, (user) => user.name[0])
// { J: [...], B: [...] }
```

### sortBy
**Location**: `utils/data.ts`  
**Import**: `import { sortBy } from '@/utils/data'`

```ts
sortBy(users, 'name') // Ascending by name
sortBy(users, 'name', 'desc') // Descending by name
sortBy(users, ['role', 'name']) // Multiple fields
sortBy(users, (user) => user.age) // Custom function
```

### filterBy
**Location**: `utils/data.ts`  
**Import**: `import { filterBy } from '@/utils/data'`

```ts
filterBy(products, { category: 'electronics' })
filterBy(users, { role: 'admin', active: true })
filterBy(items, (item) => item.price > 100)
```

### paginate
**Location**: `utils/data.ts`  
**Import**: `import { paginate } from '@/utils/data'`

```ts
const result = paginate(items, { page: 1, pageSize: 10 })
// { data: [...], total: 100, page: 1, pageSize: 10, totalPages: 10 }
```

### searchItems
**Location**: `utils/data.ts`  
**Import**: `import { searchItems } from '@/utils/data'`

```ts
searchItems(users, 'john', ['name', 'email'])
searchItems(products, 'laptop', ['title', 'description', 'category'])
```

---

## Mock Data Generation

### generateMockData
**Location**: `utils/mock.ts`  
**Import**: `import { generateMockData } from '@/utils/mock'`

```ts
// Generate users
const users = generateMockData('user', 10)
// Returns array of 10 user objects with id, name, email, avatar, etc.

// Generate products
const products = generateMockData('product', 20)
// Returns array of 20 products with id, name, price, category, etc.

// Available types:
// 'user', 'product', 'order', 'invoice', 'transaction', 
// 'customer', 'employee', 'project', 'task', 'message'
```

### generateId
**Location**: `utils/mock.ts`  
**Import**: `import { generateId } from '@/utils/mock'`

```ts
generateId() // "a3f2d8c9"
generateId('user') // "user_a3f2d8c9"
generateId('INV', 6) // "INV-123456"
```

### generateName
**Location**: `utils/mock.ts`  
**Import**: `import { generateName } from '@/utils/mock'`

```ts
generateName() // "John Doe"
generateName('first') // "John"
generateName('last') // "Doe"
generateName('full') // "John Michael Doe"
```

### generateEmail
**Location**: `utils/mock.ts`  
**Import**: `import { generateEmail } from '@/utils/mock'`

```ts
generateEmail('John Doe') // "john.doe@example.com"
generateEmail() // "user123@example.com"
```

### generateAvatar
**Location**: `utils/mock.ts`  
**Import**: `import { generateAvatar } from '@/utils/mock'`

```ts
generateAvatar('John Doe') // "https://api.dicebear.com/7.x/initials/svg?seed=JD"
generateAvatar() // Random avatar URL
```

### generatePrice
**Location**: `utils/mock.ts`  
**Import**: `import { generatePrice } from '@/utils/mock'`

```ts
generatePrice() // 29.99
generatePrice(10, 100) // Random between 10-100
generatePrice(100, 1000, 0) // No decimals
```

---

## Date & Time Utilities

### getRelativeTime
**Location**: `utils/date.ts`  
**Import**: `import { getRelativeTime } from '@/utils/date'`

```ts
getRelativeTime(new Date()) // "just now"
getRelativeTime(subMinutes(new Date(), 5)) // "5 minutes ago"
getRelativeTime(subDays(new Date(), 2)) // "2 days ago"
getRelativeTime(addHours(new Date(), 3)) // "in 3 hours"
```

### isToday
**Location**: `utils/date.ts`  
**Import**: `import { isToday, isYesterday, isTomorrow } from '@/utils/date'`

```ts
isToday(new Date()) // true
isYesterday(subDays(new Date(), 1)) // true
isTomorrow(addDays(new Date(), 1)) // true
```

### getDateRange
**Location**: `utils/date.ts`  
**Import**: `import { getDateRange } from '@/utils/date'`

```ts
getDateRange('today') // { start: Date, end: Date }
getDateRange('yesterday')
getDateRange('last7days')
getDateRange('last30days')
getDateRange('thisMonth')
getDateRange('lastMonth')
getDateRange('thisYear')
```

### addBusinessDays
**Location**: `utils/date.ts`  
**Import**: `import { addBusinessDays } from '@/utils/date'`

```ts
addBusinessDays(new Date('2024-01-12'), 3) // Skips weekends
```

---

## String Utilities

### capitalize
**Location**: `utils/string.ts`  
**Import**: `import { capitalize, capitalizeWords } from '@/utils/string'`

```ts
capitalize('hello world') // "Hello world"
capitalizeWords('hello world') // "Hello World"
```

### truncate
**Location**: `utils/string.ts`  
**Import**: `import { truncate } from '@/utils/string'`

```ts
truncate('Long text here...', 10) // "Long te..."
truncate('Long text here...', 10, '***') // "Long te***"
```

### slugify
**Location**: `utils/string.ts`  
**Import**: `import { slugify } from '@/utils/string'`

```ts
slugify('Hello World!') // "hello-world"
slugify('Product Name #123') // "product-name-123"
```

### camelCase / snakeCase / kebabCase
**Location**: `utils/string.ts`  
**Import**: `import { camelCase, snakeCase, kebabCase } from '@/utils/string'`

```ts
camelCase('hello world') // "helloWorld"
snakeCase('helloWorld') // "hello_world"
kebabCase('hello_world') // "hello-world"
```

### stripHtml
**Location**: `utils/string.ts`  
**Import**: `import { stripHtml } from '@/utils/string'`

```ts
stripHtml('<p>Hello <b>World</b></p>') // "Hello World"
```

---

## Number Utilities

### clamp
**Location**: `utils/number.ts`  
**Import**: `import { clamp } from '@/utils/number'`

```ts
clamp(5, 0, 10) // 5
clamp(15, 0, 10) // 10
clamp(-5, 0, 10) // 0
```

### randomInt
**Location**: `utils/number.ts`  
**Import**: `import { randomInt, randomFloat } from '@/utils/number'`

```ts
randomInt(1, 10) // Random integer between 1-10
randomFloat(1, 10) // Random float between 1-10
randomFloat(1, 10, 2) // Random float with 2 decimals
```

### percentage
**Location**: `utils/number.ts`  
**Import**: `import { percentage } from '@/utils/number'`

```ts
percentage(25, 100) // 25
percentage(50, 200) // 25
percentage(75, 150, 1) // 50.0 (1 decimal)
```

### roundTo
**Location**: `utils/number.ts`  
**Import**: `import { roundTo } from '@/utils/number'`

```ts
roundTo(3.14159, 2) // 3.14
roundTo(3.14159, 4) // 3.1416
roundTo(1234.5, -2) // 1200 (round to hundreds)
```

---

## Array Utilities

### chunk
**Location**: `utils/array.ts`  
**Import**: `import { chunk } from '@/utils/array'`

```ts
chunk([1, 2, 3, 4, 5], 2) // [[1, 2], [3, 4], [5]]
```

### unique
**Location**: `utils/array.ts`  
**Import**: `import { unique, uniqueBy } from '@/utils/array'`

```ts
unique([1, 2, 2, 3, 3, 3]) // [1, 2, 3]
uniqueBy(users, 'email') // Remove duplicate emails
uniqueBy(items, (item) => item.category)
```

### shuffle
**Location**: `utils/array.ts`  
**Import**: `import { shuffle } from '@/utils/array'`

```ts
shuffle([1, 2, 3, 4, 5]) // Randomly ordered array
```

### move
**Location**: `utils/array.ts`  
**Import**: `import { move } from '@/utils/array'`

```ts
move([1, 2, 3, 4], 0, 2) // [2, 3, 1, 4]
```

### difference / intersection
**Location**: `utils/array.ts`  
**Import**: `import { difference, intersection } from '@/utils/array'`

```ts
difference([1, 2, 3], [2, 3, 4]) // [1]
intersection([1, 2, 3], [2, 3, 4]) // [2, 3]
```

---

## Object Utilities

### pick / omit
**Location**: `utils/object.ts`  
**Import**: `import { pick, omit } from '@/utils/object'`

```ts
const user = { id: 1, name: 'John', email: 'john@example.com', password: '123' }

pick(user, ['id', 'name']) // { id: 1, name: 'John' }
omit(user, ['password']) // { id: 1, name: 'John', email: '...' }
```

### deepMerge
**Location**: `utils/object.ts`  
**Import**: `import { deepMerge } from '@/utils/object'`

```ts
deepMerge(
  { a: 1, b: { c: 2 } },
  { b: { d: 3 }, e: 4 }
)
// { a: 1, b: { c: 2, d: 3 }, e: 4 }
```

### deepClone
**Location**: `utils/object.ts`  
**Import**: `import { deepClone } from '@/utils/object'`

```ts
const original = { a: 1, b: { c: 2 } }
const cloned = deepClone(original)
// Modifying cloned won't affect original
```

### isEmpty
**Location**: `utils/object.ts`  
**Import**: `import { isEmpty } from '@/utils/object'`

```ts
isEmpty({}) // true
isEmpty([]) // true
isEmpty('') // true
isEmpty(null) // true
isEmpty({ a: 1 }) // false
```

---

## Validation Utilities

### isEmail
**Location**: `utils/validation.ts`  
**Import**: `import { isEmail } from '@/utils/validation'`

```ts
isEmail('john@example.com') // true
isEmail('invalid.email') // false
```

### isURL
**Location**: `utils/validation.ts`  
**Import**: `import { isURL } from '@/utils/validation'`

```ts
isURL('https://example.com') // true
isURL('example.com') // false
isURL('http://localhost:3000') // true
```

### isPhoneNumber
**Location**: `utils/validation.ts`  
**Import**: `import { isPhoneNumber } from '@/utils/validation'`

```ts
isPhoneNumber('(123) 456-7890') // true
isPhoneNumber('+1 123 456 7890') // true
isPhoneNumber('123') // false
```

### isStrongPassword
**Location**: `utils/validation.ts`  
**Import**: `import { isStrongPassword } from '@/utils/validation'`

```ts
isStrongPassword('Pass123!') // true
isStrongPassword('weak') // false
// Requires: 8+ chars, uppercase, lowercase, number, special char
```

### validateCreditCard
**Location**: `utils/validation.ts`  
**Import**: `import { validateCreditCard } from '@/utils/validation'`

```ts
validateCreditCard('4111111111111111') // { valid: true, type: 'visa' }
validateCreditCard('5500000000000004') // { valid: true, type: 'mastercard' }
```

---

## Storage Utilities

### localStorage helpers
**Location**: `utils/storage.ts`  
**Import**: `import { getLocalItem, setLocalItem, removeLocalItem } from '@/utils/storage'`

```ts
// Type-safe localStorage with JSON parsing
setLocalItem('user', { id: 1, name: 'John' })
const user = getLocalItem('user') // Parsed object
removeLocalItem('user')

// With expiration
setLocalItem('token', 'abc123', { expires: 3600 }) // 1 hour
```

### sessionStorage helpers
**Location**: `utils/storage.ts`  
**Import**: `import { getSessionItem, setSessionItem } from '@/utils/storage'`

```ts
setSessionItem('tempData', { foo: 'bar' })
const data = getSessionItem('tempData')
```

### cookies helpers
**Location**: `utils/storage.ts`  
**Import**: `import { getCookie, setCookie, removeCookie } from '@/utils/storage'`

```ts
setCookie('token', 'abc123', { days: 7 })
const token = getCookie('token')
removeCookie('token')
```

---

## API Utilities

### apiClient
**Location**: `utils/api.ts`  
**Import**: `import { apiClient } from '@/utils/api'`

```ts
// GET request
const users = await apiClient.get('/users')

// POST request
const newUser = await apiClient.post('/users', {
  name: 'John',
  email: 'john@example.com'
})

// PUT request
await apiClient.put('/users/1', { name: 'Updated' })

// DELETE request
await apiClient.delete('/users/1')

// With options
const data = await apiClient.get('/users', {
  params: { page: 1, limit: 10 },
  headers: { 'X-Custom': 'value' }
})
```

### handleApiError
**Location**: `utils/api.ts`  
**Import**: `import { handleApiError } from '@/utils/api'`

```ts
try {
  const data = await apiClient.get('/users')
} catch (error) {
  const message = handleApiError(error)
  // Returns user-friendly error message
}
```

### buildQueryString
**Location**: `utils/api.ts`  
**Import**: `import { buildQueryString } from '@/utils/api'`

```ts
buildQueryString({ page: 1, sort: 'name', filter: 'active' })
// "?page=1&sort=name&filter=active"
```

---

## Style Utilities

### cn (classNames)
**Location**: `utils/style.ts`  
**Import**: `import { cn } from '@/utils/style'`

```ts
// Combines classNames, handles conditionals
cn('base-class', condition && 'conditional-class', {
  'active': isActive,
  'disabled': isDisabled
})
```

### getColorFromString
**Location**: `utils/style.ts`  
**Import**: `import { getColorFromString } from '@/utils/style'`

```ts
// Generate consistent color from string (for avatars, etc.)
getColorFromString('John Doe') // "#4A5568"
getColorFromString('Jane Smith') // "#E53E3E"
```

### hexToRgb / rgbToHex
**Location**: `utils/style.ts`  
**Import**: `import { hexToRgb, rgbToHex } from '@/utils/style'`

```ts
hexToRgb('#FF0000') // { r: 255, g: 0, b: 0 }
rgbToHex(255, 0, 0) // "#FF0000"
```

### generateGradient
**Location**: `utils/style.ts`  
**Import**: `import { generateGradient } from '@/utils/style'`

```ts
generateGradient('#FF0000', '#0000FF') 
// "linear-gradient(to right, #FF0000, #0000FF)"

generateGradient('#FF0000', '#0000FF', 45)
// "linear-gradient(45deg, #FF0000, #0000FF)"
```

---

## Usage Guidelines

1. **ALWAYS check this registry before creating new utilities**
2. **Import from the exact paths shown**
3. **Use utilities for consistency across the app**
4. **Update this registry when adding new utilities**

## Common Patterns

### Data Table with Utilities
```tsx
import { sortBy, filterBy, paginate, searchItems } from '@/utils/data'
import { formatCurrency, formatDate } from '@/utils/format'

function ProductTable({ products, filters, searchQuery }) {
  // Search
  let filtered = searchItems(products, searchQuery, ['name', 'description'])
  
  // Filter
  filtered = filterBy(filtered, filters)
  
  // Sort
  filtered = sortBy(filtered, 'createdAt', 'desc')
  
  // Paginate
  const { data, ...paginationInfo } = paginate(filtered, {
    page: currentPage,
    pageSize: 10
  })
  
  // Format for display
  const formatted = data.map(item => ({
    ...item,
    price: formatCurrency(item.price),
    date: formatDate(item.createdAt)
  }))
  
  return <DataTable data={formatted} />
}
```

### Form Validation
```tsx
import { isEmail, isStrongPassword } from '@/utils/validation'
import { capitalize } from '@/utils/string'

function validateForm(values) {
  const errors = {}
  
  if (!isEmail(values.email)) {
    errors.email = 'Invalid email address'
  }
  
  if (!isStrongPassword(values.password)) {
    errors.password = 'Password must be stronger'
  }
  
  values.name = capitalize(values.name)
  
  return errors
}
```

### Mock Data for Development
```tsx
import { generateMockData, generateId } from '@/utils/mock'
import { shuffle, chunk } from '@/utils/array'

// Generate dashboard data
const users = generateMockData('user', 50)
const products = generateMockData('product', 100)
const orders = generateMockData('order', 200)

// Create featured products
const featured = shuffle(products).slice(0, 4)

// Group products for display
const productGroups = chunk(products, 3)
```

## Remember

This registry ensures consistent data handling across your entire application. Every formatting, validation, and data manipulation should use these utilities instead of creating new ones.