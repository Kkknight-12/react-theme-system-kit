# Theme System Learnings from Professional Template Analysis

## Key Theme Architecture Insights

### 1. **Primary vs Secondary Color Strategy**

#### What Changes with Theme:
- **Primary Color Only** - This is the brand color that changes between presets
  - Primary buttons and CTAs
  - Active states and selections
  - Links and accents
  - Focus rings
  - Progress indicators
  - Primary-colored badges/chips

#### What Remains Fixed:
- **Secondary Color** - Always blue (#3366FF / rgb(59, 130, 246))
  - Secondary buttons
  - Secondary badges
  - Info-related elements
- **Semantic Colors** - Consistent meaning across themes
  - Success: Green (#54D62C)
  - Error: Red (#FF4842)
  - Warning: Yellow (#FFC107)
  - Info: Blue (#1890FF)

### 2. **Button Color Hierarchy**

```javascript
// Primary - Changes with theme
<Button variant="contained">Primary Action</Button>

// Secondary - Always blue regardless of theme
<Button variant="contained" color="secondary">Secondary Action</Button>

// Neutral - Uses grey, adapts to light/dark mode only
<Button variant="outlined" color="inherit">Cancel</Button>

// Ghost - Transparent with hover state
<Button variant="text">Text Button</Button>

// Semantic - Fixed colors for specific actions
<Button variant="contained" color="error">Delete</Button>
<Button variant="contained" color="success">Confirm</Button>
```

### 3. **Theme Preset System**

The template uses 6 predefined theme presets:
1. **Default** - Green (#00AB55)
2. **Purple** - (#7635dc)
3. **Cyan** - (#1CCAFF)
4. **Blue** - (#2065D1)
5. **Orange** - (#fda92d)
6. **Red** - (#FF3030)

Each preset only changes the primary color and its shades.

### 4. **Color Application Rules**

#### Primary Color Usage (Changes with theme):
- Main action buttons
- Selected navigation items
- Active form elements
- Progress bars
- Selected chips/tags
- Icon buttons (primary actions)

#### Secondary Color Usage (Fixed blue):
- Secondary action buttons
- Information badges
- Secondary navigation elements
- Less important CTAs

#### Neutral Colors (Adapt to mode only):
- Backgrounds
- Borders
- Disabled states
- Shadows
- Text colors

### 5. **Dark Mode Strategy**

Dark mode changes affect:
- All text colors (primary, secondary, disabled)
- All backgrounds (default, paper, neutral)
- All borders and dividers
- Shadow intensities
- Overlay opacities

Dark mode does NOT change:
- Primary theme color
- Secondary color (remains blue)
- Semantic colors (success, error, warning)

### 6. **CSS Variable Structure**

```css
/* Theme-specific (changes with preset) */
--color-primary-*: Dynamic based on theme

/* Fixed across themes */
--color-secondary-*: Always blue values
--color-success-*: Always green values
--color-error-*: Always red values
--color-warning-*: Always yellow values

/* Mode-specific (changes with dark/light) */
--color-text-*: Different for light/dark
--color-background-*: Different for light/dark
--color-border-*: Different for light/dark
```

### 7. **Component Theming Patterns**

#### Navigation
- Active items use primary color
- Hover states use neutral colors
- Text adapts to mode

#### Cards
- Backgrounds use paper color (mode-dependent)
- Borders use border color (mode-dependent)
- Accents can use primary color

#### Forms
- Focus states use primary color
- Error states use error color (fixed)
- Disabled states use neutral colors

#### Data Display
- Charts use primary color for main data
- Secondary data uses grey scale
- Status indicators use semantic colors

### 8. **Design Rationale**

This pattern ensures:
1. **Brand Flexibility** - Primary color can be customized
2. **UI Consistency** - Secondary and semantic colors remain predictable
3. **User Experience** - Users learn color meanings once
4. **Accessibility** - Contrast ratios maintained across themes
5. **Developer Experience** - Clear rules for color application

### 9. **Implementation Best Practices**

1. **Never use primary color for semantic meaning** - It changes!
2. **Use secondary for consistent UI elements** across themes
3. **Reserve semantic colors for their purpose** (error, success, etc.)
4. **Test all themes in both light and dark modes**
5. **Ensure sufficient contrast** in all theme/mode combinations

### 10. **Common Mistakes to Avoid**

1. ❌ Making secondary color change with theme
2. ❌ Using primary color for error states
3. ❌ Hard-coding colors instead of using CSS variables
4. ❌ Forgetting to test dark mode with all themes
5. ❌ Using theme colors for semantic meaning

This architecture creates a professional, flexible theme system that balances customization with consistency.