# Coding Standards

**Project**: Modern Admin Dashboard Template  
**Last Updated**: [Current Date]  
**Version**: 1.0

## File Naming Conventions

### Components
- **PascalCase** for React components: `UserProfile.jsx`, `DataTable.jsx`
- Component folders use PascalCase: `UserCard/`, `StatCard/`

### Utilities & Hooks
- **kebab-case** for utility files: `format-currency.js`, `validate-email.js`
- **camelCase** for hooks: `useAuth.js`, `useTable.js`

### Pages
- **kebab-case** for page files: `user-profile.jsx`, `product-list.jsx`

### Assets
- **kebab-case** with descriptive names: `logo-dark.svg`, `hero-background.jpg`

## Component Structure

### Folder Organization
Components should be organized in folders when they have multiple files:

```
components/
  ui/
    Button/
      index.jsx          # Main component export
      Button.styles.js   # Styled components or style utilities
      Button.test.js     # Component tests
      Button.stories.js  # Storybook stories
    Card/
      index.jsx
      CardHeader.jsx     # Sub-components
      CardBody.jsx
      CardFooter.jsx
```

### Single File Components
Simple components can be single files:
```
components/
  ui/
    Badge.jsx
    Divider.jsx
    Spinner.jsx
```

## Import Order (Modern Approach)

Follow this strict order with blank lines between groups:

```javascript
// 1. React imports
import React, { useState, useEffect } from 'react'

// 2. Third-party library imports (alphabetically)
import { motion } from 'framer-motion'
import { useForm } from 'react-hook-form'
import { useNavigate } from 'react-router-dom'

// 3. Store imports (Redux/Zustand)
import { useDispatch, useSelector } from 'react-redux'
import { setUser } from '@/store/slices/userSlice'

// 4. Component imports (alphabetically)
import Button from '@/components/ui/Button'
import Card from '@/components/ui/Card'
import DataTable from '@/components/ui/DataTable'

// 5. Hook imports
import useAuth from '@/hooks/useAuth'
import useTable from '@/hooks/useTable'

// 6. Utility imports
import { formatCurrency, formatDate } from '@/utils/format'
import { validateEmail } from '@/utils/validation'

// 7. Constant/Config imports
import { API_ENDPOINTS } from '@/config/api'
import { ROUTES } from '@/config/routes'

// 8. Style imports
import styles from './Component.module.css'
import './Component.css'
```

## Component Guidelines

### Function Declaration
```javascript
/**
 * UserCard component displays user information in a card format
 * @param {Object} props - Component props
 * @param {Object} props.user - User data object
 * @param {string} props.variant - Card variant (default, compact, detailed)
 * @param {Function} props.onEdit - Edit callback function
 * @returns {JSX.Element} UserCard component
 */
export default function UserCard({ 
  user, 
  variant = 'default', 
  onEdit 
}) {
  // Component logic here
  return (
    <Card>
      {/* Component JSX */}
    </Card>
  )
}
```

### Props Handling
```javascript
// ✅ Preferred: Destructure with defaults
function Button({ 
  variant = 'primary', 
  size = 'md', 
  children,
  onClick,
  disabled = false,
  loading = false,
  ...rest 
}) {
  // Component logic
}

// ✅ For many props: Use object destructuring
function ComplexForm({ formConfig }) {
  const { 
    fields, 
    validation, 
    onSubmit, 
    initialValues 
  } = formConfig
  
  // Component logic
}
```

## CSS Classes with Tailwind

### Using cn() Utility
Always use the `cn()` utility for conditional classes and better readability:

```javascript
import { cn } from '@/lib/utils'

// ✅ Good: Clean and readable
<div 
  className={cn(
    // Base styles
    "flex items-center justify-between",
    "rounded-lg border p-4",
    // Conditional styles
    variant === 'primary' && "bg-primary-500 text-white",
    variant === 'secondary' && "bg-gray-100 text-gray-900",
    // State styles
    disabled && "opacity-50 cursor-not-allowed",
    // Responsive styles
    "hover:shadow-md transition-shadow",
    // Custom className prop
    className
  )}
>

// ❌ Bad: Hard to read
<div className="flex items-center justify-between rounded-lg border p-4 bg-primary-500 text-white hover:shadow-md transition-shadow">
```

### Style Organization
```javascript
const buttonStyles = {
  base: "inline-flex items-center justify-center rounded-md font-medium transition-colors",
  sizes: {
    sm: "h-8 px-3 text-sm",
    md: "h-10 px-4",
    lg: "h-12 px-6 text-lg"
  },
  variants: {
    primary: "bg-primary-500 text-white hover:bg-primary-600",
    secondary: "bg-gray-100 text-gray-900 hover:bg-gray-200",
    outline: "border-2 border-primary-500 text-primary-500 hover:bg-primary-50"
  }
}

// Usage
<button className={cn(
  buttonStyles.base,
  buttonStyles.sizes[size],
  buttonStyles.variants[variant]
)}>
```

## Comments

### JSDoc Comments
Required for all exported functions and components:

```javascript
/**
 * Formats a number as currency
 * @param {number} amount - The amount to format
 * @param {string} currency - Currency code (default: 'USD')
 * @param {Object} options - Formatting options
 * @returns {string} Formatted currency string
 * @example
 * formatCurrency(1234.56) // "$1,234.56"
 * formatCurrency(1234.56, 'EUR') // "€1,234.56"
 */
export function formatCurrency(amount, currency = 'USD', options = {}) {
  // Implementation
}
```

### Inline Comments
Use for complex logic explanation:

```javascript
function calculateDiscount(price, discountPercentage) {
  // Ensure discount is between 0 and 100
  const validDiscount = Math.max(0, Math.min(100, discountPercentage))
  
  // Calculate discount amount and round to 2 decimal places
  const discountAmount = (price * validDiscount) / 100
  return Math.round(discountAmount * 100) / 100
}
```

### TODO Comments
Allowed with developer name and date:

```javascript
// TODO: [John, 2024-01-15] Implement pagination for large datasets
// TODO: [Sarah, 2024-01-16] Add error boundary for this component
// FIXME: [Mike, 2024-01-14] Handle edge case when user has no data
```

## Error Handling

### Async Functions
Always use try-catch:

```javascript
/**
 * Fetches user data from API
 * @param {string} userId - User ID
 * @returns {Promise<Object>} User data
 * @throws {Error} When user not found or API error
 */
export async function fetchUser(userId) {
  try {
    const response = await axios.get(`/api/users/${userId}`)
    return response.data
  } catch (error) {
    console.error('Error fetching user:', error)
    
    // Re-throw with meaningful message
    if (error.response?.status === 404) {
      throw new Error('User not found')
    }
    
    throw new Error('Failed to fetch user data')
  }
}
```

### Error Boundaries
Create for each major section:

```javascript
import React from 'react'

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props)
    this.state = { hasError: false, error: null }
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error }
  }

  componentDidCatch(error, errorInfo) {
    console.error('Error caught by boundary:', error, errorInfo)
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="error-fallback">
          <h2>Something went wrong</h2>
          <details>
            <summary>Error details</summary>
            <pre>{this.state.error?.toString()}</pre>
          </details>
        </div>
      )
    }

    return this.props.children
  }
}
```

## State Management

### Local State
```javascript
// ✅ Good: Descriptive state names
const [isLoading, setIsLoading] = useState(false)
const [userData, setUserData] = useState(null)
const [formErrors, setFormErrors] = useState({})

// ❌ Bad: Generic names
const [data, setData] = useState()
const [flag, setFlag] = useState()
```

### Redux Patterns
```javascript
// Slice naming: feature + Slice
// File: store/slices/userSlice.js

import { createSlice } from '@reduxjs/toolkit'

const userSlice = createSlice({
  name: 'user',
  initialState: {
    currentUser: null,
    isLoading: false,
    error: null
  },
  reducers: {
    setUser: (state, action) => {
      state.currentUser = action.payload
    },
    clearUser: (state) => {
      state.currentUser = null
    }
  }
})

export const { setUser, clearUser } = userSlice.actions
export default userSlice.reducer
```

## Form Handling

### React Hook Form Pattern
```javascript
import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'

// Validation schema
const schema = yup.object({
  email: yup.string().email('Invalid email').required('Email is required'),
  password: yup.string().min(8, 'Password must be at least 8 characters').required('Password is required')
})

export default function LoginForm({ onSubmit }) {
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    reset
  } = useForm({
    resolver: yupResolver(schema),
    defaultValues: {
      email: '',
      password: ''
    }
  })

  const handleFormSubmit = async (data) => {
    try {
      await onSubmit(data)
      reset()
    } catch (error) {
      console.error('Form submission error:', error)
    }
  }

  return (
    <form onSubmit={handleSubmit(handleFormSubmit)}>
      {/* Form fields */}
    </form>
  )
}
```

## Code Quality Rules

### DRY (Don't Repeat Yourself)
Extract repeated code into utilities or components:

```javascript
// ❌ Bad: Repeated logic
function ProductCard({ product }) {
  const formattedPrice = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD'
  }).format(product.price)
  // ...
}

function CartItem({ item }) {
  const formattedPrice = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD'
  }).format(item.price)
  // ...
}

// ✅ Good: Extracted utility
import { formatCurrency } from '@/utils/format'

function ProductCard({ product }) {
  const formattedPrice = formatCurrency(product.price)
  // ...
}
```

### Early Returns
Use early returns to reduce nesting:

```javascript
// ✅ Good: Early returns
function UserProfile({ userId }) {
  if (!userId) {
    return <EmptyState message="No user selected" />
  }

  const user = useUser(userId)
  
  if (user.isLoading) {
    return <Spinner />
  }

  if (user.error) {
    return <ErrorMessage error={user.error} />
  }

  return <ProfileContent user={user.data} />
}
```

### Pure Functions
Keep functions pure when possible:

```javascript
// ✅ Good: Pure function
function calculateTotal(items) {
  return items.reduce((sum, item) => sum + item.price * item.quantity, 0)
}

// ❌ Bad: Side effects
let total = 0
function calculateTotal(items) {
  total = 0 // Modifying external variable
  items.forEach(item => {
    total += item.price * item.quantity
  })
  return total
}
```

## Git Commit Messages

Follow conventional commits:

```
feat: add user authentication
fix: resolve navigation bug in mobile view
docs: update installation guide
style: format code with prettier
refactor: extract common table logic
test: add unit tests for formatters
chore: update dependencies
```

## Accessibility

Always include ARIA labels and semantic HTML:

```javascript
// ✅ Good: Accessible
<button
  onClick={handleDelete}
  aria-label="Delete user"
  className={cn("p-2 hover:bg-gray-100 rounded")}
>
  <TrashIcon className="h-4 w-4" aria-hidden="true" />
</button>

// ✅ Good: Semantic HTML
<nav aria-label="Main navigation">
  <ul>
    <li><a href="/dashboard">Dashboard</a></li>
  </ul>
</nav>
```

## Performance Guidelines

### Memoization
Use when appropriate:

```javascript
import { memo, useMemo, useCallback } from 'react'

// Memoize expensive calculations
const expensiveValue = useMemo(() => {
  return calculateExpensiveValue(data)
}, [data])

// Memoize callbacks passed to children
const handleClick = useCallback((id) => {
  dispatch(selectItem(id))
}, [dispatch])

// Memoize components that receive same props often
export default memo(ExpensiveComponent)
```

### Lazy Loading
```javascript
import { lazy, Suspense } from 'react'

// Lazy load heavy components
const Dashboard = lazy(() => import('./pages/Dashboard'))

// Use with Suspense
<Suspense fallback={<Spinner />}>
  <Dashboard />
</Suspense>
```

## Summary

These standards ensure:
- Consistent code across the team
- Easy maintenance and debugging
- Better performance and accessibility
- Clear documentation
- Reduced bugs through proper error handling

All code must follow these standards before merging to main branch.