# Component Registry - ALWAYS USE THESE COMPONENTS FIRST

**CRITICAL**: Before creating ANY new component, check if it exists here. If it does, you MUST use it.

## Table of Contents
1. [Base UI Components](#base-ui-components)
2. [Form Components](#form-components)
3. [Layout Components](#layout-components)
4. [Data Display Components](#data-display-components)
5. [Feedback Components](#feedback-components)
6. [Navigation Components](#navigation-components)
7. [Overlay Components](#overlay-components)
8. [Feature Components](#feature-components)
9. [Utility Components](#utility-components)

---

## Base UI Components

### Button (shadcn/ui)
**Location**: `components/ui/button.jsx`  
**Import**: `import { Button } from '@/components/ui/button'`  
**Props**: `variant`, `size`, `disabled`, `asChild`
**Source**: shadcn/ui component

```tsx
// Variants: primary, secondary, outline, ghost, danger, success
// Sizes: xs, sm, md, lg, xl

<Button variant="primary" size="md">Click me</Button>
<Button variant="outline" size="sm" loading>Loading...</Button>
<Button variant="ghost" leftIcon={<PlusIcon />}>Add Item</Button>
<Button variant="danger" fullWidth>Delete Account</Button>
```

### IconButton ✅ CUSTOM
**Location**: `components/ui/icon-button.jsx`  
**Import**: `import { IconButton } from '@/components/ui/icon-button'`  
**Props**: `variant`, `size`, `disabled`, `tooltip`, `asChild`
**Source**: Custom implementation

```tsx
<IconButton variant="ghost" size="sm" tooltip="Edit">
  <EditIcon />
</IconButton>
```

### Card (shadcn/ui)
**Location**: `components/ui/card.jsx`  
**Import**: `import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card'`  
**Source**: shadcn/ui component

```tsx
<Card>
  <Card.Header>
    <Card.Title>Card Title</Card.Title>
    <Card.Description>Optional description</Card.Description>
  </Card.Header>
  <Card.Body>
    <p>Card content goes here</p>
  </Card.Body>
  <Card.Footer>
    <Button size="sm">Action</Button>
  </Card.Footer>
</Card>

// With image
<Card>
  <Card.Image src="/image.jpg" alt="Description" />
  <Card.Body>Content</Card.Body>
</Card>
```

### Badge (shadcn/ui)
**Location**: `components/ui/badge.jsx`  
**Import**: `import { Badge } from '@/components/ui/badge'`  
**Props**: `variant`
**Source**: shadcn/ui component

```tsx
// Variants: default, primary, success, warning, danger, info
// Sizes: xs, sm, md

<Badge variant="success">Active</Badge>
<Badge variant="warning" size="xs">Pending</Badge>
<Badge variant="danger" dot>3 Errors</Badge>
```

### Avatar (shadcn/ui)
**Location**: `components/ui/avatar.jsx`  
**Import**: `import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'`  
**Source**: shadcn/ui component

```tsx
// Sizes: xs, sm, md, lg, xl
// Status: online, offline, busy, away

<Avatar src="/user.jpg" alt="John Doe" size="md" status="online" />
<Avatar fallback="JD" size="lg" />

// Avatar Group
<AvatarGroup max={3}>
  <Avatar src="/user1.jpg" />
  <Avatar src="/user2.jpg" />
  <Avatar src="/user3.jpg" />
  <Avatar src="/user4.jpg" /> {/* Will show +1 */}
</AvatarGroup>
```

### Chip ✅ CUSTOM
**Location**: `components/ui/chip.jsx`  
**Import**: `import { Chip } from '@/components/ui/chip'`  
**Props**: `variant`, `size`, `onDelete`
**Source**: Custom implementation

```tsx
<Chip>Default Chip</Chip>
<Chip variant="primary" onDelete={() => {}}>Deletable</Chip>
<Chip clickable onClick={() => {}}>Clickable</Chip>
<Chip icon={<TagIcon />}>With Icon</Chip>
```

### Divider ✅ CUSTOM
**Location**: `components/ui/divider.jsx`  
**Import**: `import { Divider } from '@/components/ui/divider'`  
**Props**: `orientation`, `children` (for text)
**Source**: Custom implementation

```tsx
<Divider />
<Divider text="OR" />
<Divider orientation="vertical" className="h-20" />
<Divider variant="dashed" />
```

---

## Form Components

### Input (shadcn/ui)
**Location**: `components/ui/input.jsx`  
**Import**: `import { Input } from '@/components/ui/input'`  
**Props**: Standard HTML input props
**Source**: shadcn/ui component

```tsx
<Input 
  label="Email Address" 
  type="email" 
  placeholder="john@example.com"
  required
/>

<Input 
  label="Password"
  type="password"
  error="Password is too short"
  helperText="Must be at least 8 characters"
/>

<Input 
  label="Search"
  leftIcon={<SearchIcon />}
  placeholder="Search..."
/>
```

### Select (shadcn/ui)
**Location**: `components/ui/select.jsx`  
**Import**: `import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'`  
**Source**: shadcn/ui component

```tsx
const options = [
  { value: 'us', label: 'United States' },
  { value: 'uk', label: 'United Kingdom' },
  { value: 'ca', label: 'Canada' }
]

<Select 
  label="Country" 
  options={options}
  placeholder="Select a country"
/>

<Select 
  label="Skills"
  options={skillOptions}
  multiple
  searchable
/>
```

### Checkbox (shadcn/ui)
**Location**: `components/ui/checkbox.jsx`  
**Import**: `import { Checkbox } from '@/components/ui/checkbox'`  
**Props**: `checked`, `onCheckedChange`, `disabled`
**Source**: shadcn/ui component

```tsx
<Checkbox label="Remember me" />
<Checkbox label="I agree to terms" required />
<Checkbox label="Select all" indeterminate />
```

### Radio (shadcn/ui)
**Location**: `components/ui/radio-group.jsx`  
**Import**: `import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'`
**Source**: shadcn/ui component  

```tsx
<RadioGroup label="Plan" name="plan" defaultValue="pro">
  <Radio value="free" label="Free Plan" />
  <Radio value="pro" label="Pro Plan" />
  <Radio value="enterprise" label="Enterprise" />
</RadioGroup>
```

### Switch (shadcn/ui)
**Location**: `components/ui/switch.jsx`  
**Import**: `import { Switch } from '@/components/ui/switch'`  
**Props**: `checked`, `onCheckedChange`, `disabled`
**Source**: shadcn/ui component

```tsx
<Switch label="Enable notifications" />
<Switch label="Dark mode" defaultChecked />
<Switch label="Maintenance mode" size="lg" />
```

### Textarea (shadcn/ui)
**Location**: `components/ui/textarea.jsx`  
**Import**: `import { Textarea } from '@/components/ui/textarea'`  
**Props**: Standard HTML textarea props
**Source**: shadcn/ui component

```tsx
<Textarea 
  label="Description" 
  rows={4}
  placeholder="Enter description..."
  maxLength={500}
  showCount
/>
```

### FormField
**Location**: `components/ui/form/FormField.tsx`  
**Import**: `import { FormField } from '@/components/ui/form/FormField'`  
**Note**: Wrapper for consistent form field styling

```tsx
<FormField label="Username" required error="Username taken">
  <Input />
</FormField>
```

---

## Layout Components

### Container ✅ CUSTOM
**Location**: `components/ui/container.jsx`  
**Import**: `import { Container, Section } from '@/components/ui/container'`  
**Props**: `size`, `padding`
**Source**: Custom implementation

```tsx
// Sizes: sm, md, lg, xl, 2xl, full
<Container size="lg">
  <h1>Page Content</h1>
</Container>

<Container size="sm" centered>
  <LoginForm />
</Container>
```

### Grid ✅ CUSTOM
**Location**: `components/ui/grid.jsx`  
**Import**: `import { Grid, GridItem } from '@/components/ui/grid'`  
**Props**: `cols`, `gap`, `responsive`
**Source**: Custom implementation

```tsx
// Responsive columns
<Grid cols={{ base: 1, md: 2, lg: 3 }} gap={6}>
  <Card>Item 1</Card>
  <Card>Item 2</Card>
  <Card>Item 3</Card>
</Grid>

// Fixed columns
<Grid cols={4} gap={4}>
  {items.map(item => <Card key={item.id}>{item.name}</Card>)}
</Grid>
```

### Stack ✅ CUSTOM
**Location**: `components/ui/stack.jsx`  
**Import**: `import { Stack, HStack, VStack } from '@/components/ui/stack'`  
**Props**: `direction`, `align`, `justify`, `wrap`, `gap`
**Source**: Custom implementation

```tsx
// Vertical stack (default)
<Stack spacing={4}>
  <Card>Item 1</Card>
  <Card>Item 2</Card>
</Stack>

// Horizontal stack
<Stack direction="horizontal" spacing={2} align="center">
  <Avatar />
  <Text>Username</Text>
</Stack>
```

### Flex
**Location**: `components/ui/layout/Flex.tsx`  
**Import**: `import { Flex } from '@/components/ui/layout/Flex'`  
**Props**: `align`, `justify`, `gap`, `wrap`, `direction`

```tsx
<Flex justify="between" align="center">
  <h2>Title</h2>
  <Button>Action</Button>
</Flex>

<Flex gap={4} wrap>
  {tags.map(tag => <Chip key={tag}>{tag}</Chip>)}
</Flex>
```

---

## Data Display Components

### Table (shadcn/ui)
**Location**: `components/ui/table.jsx`  
**Import**: `import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'`  
**Source**: shadcn/ui component

```tsx
const columns = [
  { key: 'name', label: 'Name', sortable: true },
  { key: 'email', label: 'Email' },
  { key: 'role', label: 'Role' },
  { 
    key: 'actions', 
    label: 'Actions',
    render: (row) => (
      <Button size="xs" variant="ghost">Edit</Button>
    )
  }
]

<Table 
  columns={columns}
  data={users}
  sortable
  selectable
  pagination={{
    pageSize: 10,
    total: 100,
    current: 1
  }}
/>
```

### DataTable
**Location**: `components/ui/table/DataTable.tsx`  
**Import**: `import { DataTable } from '@/components/ui/table/DataTable'`  
**Note**: Advanced table with built-in search, filters, export

```tsx
<DataTable 
  data={products}
  columns={columns}
  searchable
  searchPlaceholder="Search products..."
  filters={[
    { key: 'category', label: 'Category', type: 'select' },
    { key: 'price', label: 'Price Range', type: 'range' }
  ]}
  exportable
  bulkActions={[
    { label: 'Delete', action: (selected) => {} },
    { label: 'Export', action: (selected) => {} }
  ]}
/>
```

### List ✅ CUSTOM
**Location**: `components/ui/list.jsx`  
**Import**: `import { List, ListItem, ListItemButton, ListItemIcon, ListItemText, ListSubheader, ListDivider } from '@/components/ui/list'`
**Source**: Custom implementation  

```tsx
<List>
  <ListItem>
    <ListItem.Icon><UserIcon /></ListItem.Icon>
    <ListItem.Content>
      <ListItem.Title>John Doe</ListItem.Title>
      <ListItem.Description>john@example.com</ListItem.Description>
    </ListItem.Content>
    <ListItem.Action>
      <IconButton><EditIcon /></IconButton>
    </ListItem.Action>
  </ListItem>
</List>
```

### StatCard
**Location**: `components/ui/StatCard.tsx`  
**Import**: `import { StatCard } from '@/components/ui/StatCard'`  
**Props**: `title`, `value`, `change`, `icon`, `trend`

```tsx
<StatCard
  title="Total Revenue"
  value="$45,231"
  change="+12.5%"
  trend="up"
  icon={<DollarIcon />}
/>

<StatCard
  title="Active Users"
  value="2,543"
  change="-3.2%"
  trend="down"
  icon={<UsersIcon />}
/>
```

### EmptyState
**Location**: `components/ui/EmptyState.tsx`  
**Import**: `import { EmptyState } from '@/components/ui/EmptyState'`  
**Props**: `title`, `description`, `icon`, `action`

```tsx
<EmptyState
  icon={<InboxIcon />}
  title="No messages"
  description="You don't have any messages yet"
  action={
    <Button variant="primary">Compose Message</Button>
  }
/>
```

---

## Feedback Components

### Alert (shadcn/ui)
**Location**: `components/ui/alert.jsx`  
**Import**: `import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'`  
**Source**: shadcn/ui component

```tsx
// Variants: info, success, warning, danger
<Alert variant="info">This is an informational message</Alert>

<Alert 
  variant="danger" 
  title="Error occurred"
  closable
>
  Failed to save changes. Please try again.
</Alert>
```

### Toast (shadcn/ui - Sonner)
**Location**: `components/ui/sonner.jsx`  
**Import**: `import { toast } from 'sonner'`  
**Source**: shadcn/ui component using Sonner library

```tsx
// Success toast
toast.success('Changes saved successfully')

// Error toast
toast.error('Failed to delete item')

// Custom toast
toast({
  title: 'New message',
  description: 'You have a new message from John',
  action: <Button size="xs">View</Button>
})
```

### Progress (shadcn/ui)
**Location**: `components/ui/progress.jsx`  
**Import**: `import { Progress } from '@/components/ui/progress'`  
**Props**: `value`, `max`, `className`
**Source**: shadcn/ui component

```tsx
<Progress value={60} label="60% Complete" />
<Progress value={75} variant="success" />
<Progress value={30} size="sm" />
```

### Skeleton (shadcn/ui)
**Location**: `components/ui/skeleton.jsx`  
**Import**: `import { Skeleton } from '@/components/ui/skeleton'`  
**Props**: `className`
**Source**: shadcn/ui component

```tsx
// Text skeleton
<Skeleton variant="text" width="200px" />

// Circular skeleton
<Skeleton variant="circular" width="40px" height="40px" />

// Rectangular skeleton
<Skeleton variant="rectangular" width="100%" height="200px" />

// Full component skeleton
<Card>
  <Skeleton variant="rectangular" height="200px" />
  <Card.Body>
    <Skeleton variant="text" width="60%" />
    <Skeleton variant="text" width="100%" />
    <Skeleton variant="text" width="80%" />
  </Card.Body>
</Card>
```

### Spinner ✅ CUSTOM
**Location**: `components/ui/spinner.jsx`  
**Import**: `import { Spinner, SpinnerOverlay } from '@/components/ui/spinner'`  
**Props**: `size`, `variant`
**Source**: Custom implementation

```tsx
<Spinner size="sm" />
<Spinner size="lg" variant="primary" />
```

---

## Navigation Components

### Tabs (shadcn/ui)
**Location**: `components/ui/tabs.jsx`  
**Import**: `import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'`
**Source**: shadcn/ui component  

```tsx
<Tabs defaultValue="overview">
  <Tabs.List>
    <Tabs.Tab value="overview">Overview</Tabs.Tab>
    <Tabs.Tab value="analytics">Analytics</Tabs.Tab>
    <Tabs.Tab value="settings">Settings</Tabs.Tab>
  </Tabs.List>
  
  <Tabs.Panel value="overview">
    Overview content
  </Tabs.Panel>
  <Tabs.Panel value="analytics">
    Analytics content
  </Tabs.Panel>
  <Tabs.Panel value="settings">
    Settings content
  </Tabs.Panel>
</Tabs>
```

### Breadcrumb (shadcn/ui)
**Location**: `components/ui/breadcrumb.jsx`  
**Import**: `import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator } from '@/components/ui/breadcrumb'`
**Source**: shadcn/ui component  

```tsx
<Breadcrumb>
  <Breadcrumb.Item href="/">Home</Breadcrumb.Item>
  <Breadcrumb.Item href="/products">Products</Breadcrumb.Item>
  <Breadcrumb.Item current>Product Details</Breadcrumb.Item>
</Breadcrumb>
```

### Pagination
**Location**: `components/ui/Pagination.tsx`  
**Import**: `import { Pagination } from '@/components/ui/Pagination'`  
**Props**: `current`, `total`, `pageSize`, `onChange`, `showTotal`

```tsx
<Pagination
  current={1}
  total={100}
  pageSize={10}
  onChange={(page) => console.log(page)}
  showTotal
/>
```

### Steps
**Location**: `components/ui/Steps.tsx`  
**Import**: `import { Steps } from '@/components/ui/Steps'`  

```tsx
<Steps current={1}>
  <Steps.Step title="Account Info" description="Basic details" />
  <Steps.Step title="Verification" description="Verify email" />
  <Steps.Step title="Complete" description="Setup done" />
</Steps>
```

---

## Overlay Components

### Modal/Dialog (shadcn/ui)
**Location**: `components/ui/dialog.jsx`  
**Import**: `import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'`
**Source**: shadcn/ui component

```tsx
<Modal
  open={isOpen}
  onClose={() => setIsOpen(false)}
  title="Delete Confirmation"
  footer={
    <>
      <Button variant="ghost" onClick={() => setIsOpen(false)}>
        Cancel
      </Button>
      <Button variant="danger">Delete</Button>
    </>
  }
>
  Are you sure you want to delete this item?
</Modal>
```

### Drawer (shadcn/ui)
**Location**: `components/ui/drawer.jsx`  
**Import**: `import { Drawer, DrawerClose, DrawerContent, DrawerDescription, DrawerFooter, DrawerHeader, DrawerTitle, DrawerTrigger } from '@/components/ui/drawer'`
**Source**: shadcn/ui component

```tsx
// Positions: left, right, top, bottom
// Sizes: sm, md, lg, xl

<Drawer
  open={isOpen}
  onClose={() => setIsOpen(false)}
  position="right"
  title="Filters"
  size="md"
>
  <FilterContent />
</Drawer>
```

### Popover (shadcn/ui)
**Location**: `components/ui/popover.jsx`  
**Import**: `import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'`
**Source**: shadcn/ui component  

```tsx
<Popover>
  <Popover.Trigger>
    <Button>Open Popover</Button>
  </Popover.Trigger>
  <Popover.Content>
    <div className="p-4">
      Popover content here
    </div>
  </Popover.Content>
</Popover>
```

### Tooltip (shadcn/ui)
**Location**: `components/ui/tooltip.jsx`  
**Import**: `import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip'`
**Source**: shadcn/ui component

```tsx
<Tooltip content="This is helpful information" placement="top">
  <IconButton>
    <InfoIcon />
  </IconButton>
</Tooltip>
```

### Dropdown Menu (shadcn/ui)
**Location**: `components/ui/dropdown-menu.jsx`  
**Import**: `import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'`
**Source**: shadcn/ui component  

```tsx
<Dropdown>
  <Dropdown.Trigger>
    <Button variant="ghost">
      Options <ChevronDownIcon />
    </Button>
  </Dropdown.Trigger>
  <Dropdown.Menu>
    <Dropdown.Item onClick={() => {}}>Edit</Dropdown.Item>
    <Dropdown.Item onClick={() => {}}>Duplicate</Dropdown.Item>
    <Dropdown.Divider />
    <Dropdown.Item variant="danger">Delete</Dropdown.Item>
  </Dropdown.Menu>
</Dropdown>
```

---

## Feature Components

### SearchBar
**Location**: `components/features/SearchBar.tsx`  
**Import**: `import { SearchBar } from '@/components/features/SearchBar'`  
**Props**: `placeholder`, `onSearch`, `suggestions`, `loading`

```tsx
<SearchBar
  placeholder="Search products..."
  onSearch={(query) => handleSearch(query)}
  suggestions={searchSuggestions}
/>
```

### FilterPanel
**Location**: `components/features/FilterPanel.tsx`  
**Import**: `import { FilterPanel } from '@/components/features/FilterPanel'`  

```tsx
<FilterPanel
  filters={[
    {
      id: 'category',
      label: 'Category',
      type: 'checkbox',
      options: categories
    },
    {
      id: 'price',
      label: 'Price Range',
      type: 'range',
      min: 0,
      max: 1000
    }
  ]}
  onChange={(filters) => applyFilters(filters)}
/>
```

### DatePicker
**Location**: `components/features/DatePicker.tsx`  
**Import**: `import { DatePicker, DateRangePicker } from '@/components/features/DatePicker'`  

```tsx
<DatePicker
  label="Select Date"
  value={date}
  onChange={setDate}
  minDate={new Date()}
/>

<DateRangePicker
  label="Date Range"
  value={dateRange}
  onChange={setDateRange}
/>
```

### TimePicker
**Location**: `components/features/TimePicker.tsx`  
**Import**: `import { TimePicker } from '@/components/features/TimePicker'`  

```tsx
<TimePicker
  label="Select Time"
  value={time}
  onChange={setTime}
  format="12h"
/>
```

### FileUpload
**Location**: `components/features/FileUpload.tsx`  
**Import**: `import { FileUpload } from '@/components/features/FileUpload'`  
**Props**: `accept`, `multiple`, `maxSize`, `onUpload`

```tsx
<FileUpload
  accept="image/*"
  multiple
  maxSize={5} // MB
  onUpload={(files) => handleUpload(files)}
/>
```

### ImageGallery
**Location**: `components/features/ImageGallery.tsx`  
**Import**: `import { ImageGallery } from '@/components/features/ImageGallery'`  

```tsx
<ImageGallery
  images={[
    { src: '/img1.jpg', alt: 'Image 1' },
    { src: '/img2.jpg', alt: 'Image 2' }
  ]}
  thumbnails
  zoom
/>
```

### Chart
**Location**: `components/features/charts/`  
**Import**: Various chart components

```tsx
// Line Chart
import { LineChart } from '@/components/features/charts/LineChart'
<LineChart data={salesData} height={300} />

// Bar Chart
import { BarChart } from '@/components/features/charts/BarChart'
<BarChart data={revenueData} stacked />

// Pie Chart
import { PieChart } from '@/components/features/charts/PieChart'
<PieChart data={distributionData} />

// Area Chart
import { AreaChart } from '@/components/features/charts/AreaChart'
<AreaChart data={trendData} smooth />
```

---

## Utility Components

### ErrorBoundary
**Location**: `components/utility/ErrorBoundary.tsx`  
**Import**: `import { ErrorBoundary } from '@/components/utility/ErrorBoundary'`  

```tsx
<ErrorBoundary fallback={<ErrorFallback />}>
  <ComponentThatMightError />
</ErrorBoundary>
```

### Portal
**Location**: `components/utility/Portal.tsx`  
**Import**: `import { Portal } from '@/components/utility/Portal'`  

```tsx
<Portal>
  <div className="fixed inset-0 z-50">
    Rendered at document root
  </div>
</Portal>
```

### LazyLoad
**Location**: `components/utility/LazyLoad.tsx`  
**Import**: `import { LazyLoad } from '@/components/utility/LazyLoad'`  

```tsx
<LazyLoad height={200} offset={100}>
  <ExpensiveComponent />
</LazyLoad>
```

### CopyToClipboard
**Location**: `components/utility/CopyToClipboard.tsx`  
**Import**: `import { CopyToClipboard } from '@/components/utility/CopyToClipboard'`  

```tsx
<CopyToClipboard text="Text to copy">
  <Button variant="ghost" size="sm">
    Copy
  </Button>
</CopyToClipboard>
```

---

## Usage Guidelines

1. **ALWAYS check this registry before creating new components**
2. **Use the exact import paths shown**
3. **Follow the prop patterns demonstrated**
4. **Compose complex UIs from these base components**
5. **Update this registry when adding new shared components**

## Component Composition Examples

### User Card (Composed)
```tsx
import { Card } from '@/components/ui/Card'
import { Avatar } from '@/components/ui/Avatar'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'

function UserCard({ user }) {
  return (
    <Card>
      <Card.Body>
        <Flex align="center" gap={4}>
          <Avatar src={user.avatar} size="lg" />
          <Stack spacing={1}>
            <Flex align="center" gap={2}>
              <h3>{user.name}</h3>
              <Badge variant={user.status}>{user.status}</Badge>
            </Flex>
            <p className="text-gray-500">{user.email}</p>
          </Stack>
        </Flex>
      </Card.Body>
      <Card.Footer>
        <Button variant="outline" size="sm">View Profile</Button>
      </Card.Footer>
    </Card>
  )
}
```

### Dashboard Stat Section (Composed)
```tsx
import { Grid } from '@/components/ui/layout/Grid'
import { StatCard } from '@/components/ui/StatCard'

function DashboardStats({ stats }) {
  return (
    <Grid cols={{ base: 1, md: 2, lg: 4 }} gap={6}>
      <StatCard
        title="Total Revenue"
        value={stats.revenue}
        change={stats.revenueChange}
        trend={stats.revenueTrend}
        icon={<DollarIcon />}
      />
      <StatCard
        title="New Users"
        value={stats.users}
        change={stats.usersChange}
        trend={stats.usersTrend}
        icon={<UsersIcon />}
      />
      {/* More stat cards... */}
    </Grid>
  )
}
```

## Remember

This registry is your single source of truth. Every AI session should start by reading this file to ensure consistent component usage across the entire application.