# React 19 Comprehensive Guide

## Table of Contents
1. [Introduction](#introduction)
2. [What's New in React 19](#whats-new-in-react-19)
   - [Actions](#actions)
   - [New Hooks](#new-hooks)
   - [React Server Components](#react-server-components)
   - [Improvements](#improvements)
3. [Migration Guide](#migration-guide)
   - [Breaking Changes](#breaking-changes)
   - [Removed APIs](#removed-apis)
   - [TypeScript Changes](#typescript-changes)
4. [New Features Deep Dive](#new-features-deep-dive)
5. [Code Examples](#code-examples)

---

## Introduction

React 19 was released on December 5, 2024, bringing significant improvements to data fetching, form handling, and server-side rendering. This guide covers everything you need to know about React 19, including new features, breaking changes, and migration strategies.

## What's New in React 19

### Actions

Actions are one of the most significant additions to React 19. They allow you to handle async operations, pending states, errors, and optimistic updates automatically.

#### Before Actions (React 18):
```jsx
function UpdateName({}) {
  const [name, setName] = useState("");
  const [error, setError] = useState(null);
  const [isPending, setIsPending] = useState(false);

  const handleSubmit = async () => {
    setIsPending(true);
    const error = await updateName(name);
    setIsPending(false);
    if (error) {
      setError(error);
      return;
    } 
    redirect("/path");
  };

  return (
    <div>
      <input value={name} onChange={(event) => setName(event.target.value)} />
      <button onClick={handleSubmit} disabled={isPending}>
        Update
      </button>
      {error && <p>{error}</p>}
    </div>
  );
}
```

#### With Actions (React 19):
```jsx
function UpdateName({}) {
  const [name, setName] = useState("");
  const [error, setError] = useState(null);
  const [isPending, startTransition] = useTransition();

  const handleSubmit = () => {
    startTransition(async () => {
      const error = await updateName(name);
      if (error) {
        setError(error);
        return;
      } 
      redirect("/path");
    })
  };

  return (
    <div>
      <input value={name} onChange={(event) => setName(event.target.value)} />
      <button onClick={handleSubmit} disabled={isPending}>
        Update
      </button>
      {error && <p>{error}</p>}
    </div>
  );
}
```

Actions provide:
- **Pending state**: Automatically managed during async operations
- **Optimistic updates**: Show instant feedback while requests process
- **Error handling**: Built-in error boundaries support
- **Forms**: Native integration with `<form>` elements

### New Hooks

#### 1. `useActionState`
Simplifies common patterns for Actions:

```jsx
const [error, submitAction, isPending] = useActionState(
  async (previousState, formData) => {
    const error = await updateName(formData.get("name"));
    if (error) {
      return error;
    }
    redirect("/path");
    return null;
  },
  null,
);
```

#### 2. `useFormStatus`
Access parent form state without prop drilling:

```jsx
import {useFormStatus} from 'react-dom';

function DesignButton() {
  const {pending} = useFormStatus();
  return <button type="submit" disabled={pending} />
}
```

#### 3. `useOptimistic`
Handle optimistic UI updates:

```jsx
function ChangeName({currentName, onUpdateName}) {
  const [optimisticName, setOptimisticName] = useOptimistic(currentName);

  const submitAction = async formData => {
    const newName = formData.get("name");
    setOptimisticName(newName);
    const updatedName = await updateName(newName);
    onUpdateName(updatedName);
  };

  return (
    <form action={submitAction}>
      <p>Your name is: {optimisticName}</p>
      <input type="text" name="name" disabled={currentName !== optimisticName} />
    </form>
  );
}
```

#### 4. `use`
Read resources in render (promises and context):

```jsx
import {use} from 'react';

function Comments({commentsPromise}) {
  // `use` will suspend until the promise resolves
  const comments = use(commentsPromise);
  return comments.map(comment => <p key={comment.id}>{comment}</p>);
}

// Can also read context conditionally
function Heading({children}) {
  if (children == null) {
    return null;
  }
  
  // This would not work with useContext
  const theme = use(ThemeContext);
  return <h1 style={{color: theme.color}}>{children}</h1>;
}
```

### React Server Components

Server Components render on the server, reducing bundle size and improving performance:

```jsx
// This component runs on the server
async function BlogPost({id}) {
  const post = await db.posts.get(id);
  
  return (
    <article>
      <h1>{post.title}</h1>
      <p>{post.content}</p>
    </article>
  );
}
```

#### Server Actions
Allow Client Components to call server-side functions:

```jsx
// server-action.js
"use server";

export async function updateUser(userId, data) {
  await db.users.update(userId, data);
}

// client-component.jsx
import {updateUser} from './server-action';

function Profile({userId}) {
  return (
    <form action={async (formData) => {
      await updateUser(userId, {
        name: formData.get('name')
      });
    }}>
      <input name="name" />
      <button type="submit">Update</button>
    </form>
  );
}
```

### Form Actions

React 19 integrates Actions with forms:

```jsx
<form action={actionFunction}>
  <input name="name" />
  <button type="submit">Submit</button>
</form>
```

Forms automatically:
- Reset on successful submission
- Manage pending states
- Handle errors

### Improvements

#### 1. ref as a prop
No more forwardRef needed:

```jsx
// React 18
const MyInput = React.forwardRef((props, ref) => {
  return <input {...props} ref={ref} />
});

// React 19
function MyInput({ref, ...props}) {
  return <input {...props} ref={ref} />
}
```

#### 2. Context as provider
Simpler Context API:

```jsx
// React 18
<ThemeContext.Provider value="dark">
  {children}
</ThemeContext.Provider>

// React 19
<ThemeContext value="dark">
  {children}
</ThemeContext>
```

#### 3. Cleanup functions for refs
```jsx
<input
  ref={(ref) => {
    // ref created
    
    // NEW: return cleanup function
    return () => {
      // ref cleanup
    };
  }}
/>
```

#### 4. `useDeferredValue` initial value
```jsx
function Search({deferredValue}) {
  // On initial render the value is ''
  // Then re-render with deferredValue
  const value = useDeferredValue(deferredValue, '');
  
  return <Results query={value} />;
}
```

#### 5. Document Metadata
Render meta tags anywhere:

```jsx
function BlogPost({post}) {
  return (
    <article>
      <h1>{post.title}</h1>
      <title>{post.title}</title>
      <meta name="author" content="Josh" />
      <link rel="author" href="https://twitter.com/joshcstory/" />
      <meta name="keywords" content={post.keywords} />
      <p>{post.content}</p>
    </article>
  );
}
```

#### 6. Stylesheet support
```jsx
function ComponentOne() {
  return (
    <Suspense fallback="loading...">
      <link rel="stylesheet" href="foo" precedence="default" />
      <link rel="stylesheet" href="bar" precedence="high" />
      <article class="foo-class bar-class">
        {...}
      </article>
    </Suspense>
  )
}
```

#### 7. Async script support
```jsx
function MyComponent() {
  return (
    <div>
      <script async={true} src="..." />
      Hello World
    </div>
  )
}
```

#### 8. Resource preloading
```jsx
import { prefetchDNS, preconnect, preload, preinit } from 'react-dom'

function MyComponent() {
  preinit('https://.../path/to/some/script.js', {as: 'script' })
  preload('https://.../path/to/font.woff', { as: 'font' })
  preload('https://.../path/to/stylesheet.css', { as: 'style' })
  prefetchDNS('https://...')
  preconnect('https://...')
}
```

#### 9. Better error reporting
Single, clear error messages with diffs for hydration mismatches:

```
Error: Hydration failed because the server rendered HTML didn't match the client.
<App>
  <span>
+   Client
-   Server
```

#### 10. Custom Elements support
Full support for custom elements, passing all tests on Custom Elements Everywhere.

## Migration Guide

### Installing React 19

```bash
npm install --save-exact react@^19.0.0 react-dom@^19.0.0
```

Or with Yarn:
```bash
yarn add --exact react@^19.0.0 react-dom@^19.0.0
```

### Breaking Changes

#### 1. Errors in render are not re-thrown
- Uncaught errors report to `window.reportError`
- Caught errors report to `console.error`

```jsx
const root = createRoot(container, {
  onUncaughtError: (error, errorInfo) => {
    // ... log error report
  },
  onCaughtError: (error, errorInfo) => {
    // ... log error report
  }
});
```

#### 2. Removed APIs

##### propTypes and defaultProps for functions
```jsx
// Before
function Heading({text}) {
  return <h1>{text}</h1>;
}
Heading.propTypes = {
  text: PropTypes.string,
};
Heading.defaultProps = {
  text: 'Hello, world!',
};

// After
interface Props {
  text?: string;
}
function Heading({text = 'Hello, world!'}: Props) {
  return <h1>{text}</h1>;
}
```

##### Legacy Context
```jsx
// Before
class Parent extends React.Component {
  static childContextTypes = {
    foo: PropTypes.string.isRequired,
  };
  getChildContext() {
    return { foo: 'bar' };
  }
}

// After
const FooContext = React.createContext();
class Parent extends React.Component {
  render() {
    return (
      <FooContext value='bar'>
        <Child />
      </FooContext>
    );
  }
}
```

##### String refs
```jsx
// Before
class MyComponent extends React.Component {
  componentDidMount() {
    this.refs.input.focus();
  }
  render() {
    return <input ref='input' />;
  }
}

// After
class MyComponent extends React.Component {
  componentDidMount() {
    this.input.focus();
  }
  render() {
    return <input ref={input => this.input = input} />;
  }
}
```

##### ReactDOM.render & ReactDOM.hydrate
```jsx
// Before
import {render} from 'react-dom';
render(<App />, document.getElementById('root'));

// After
import {createRoot} from 'react-dom/client';
const root = createRoot(document.getElementById('root'));
root.render(<App />);
```

### TypeScript Changes

#### Removed deprecated types
Run the codemod to update types:
```bash
npx types-react-codemod@latest preset-19 ./path-to-app
```

#### ref cleanups required
```jsx
// Before - implicit return
<div ref={current => (instance = current)} />

// After - explicit return
<div ref={current => {instance = current}} />
```

#### useRef requires an argument
```jsx
// Before
useRef()

// After
useRef(undefined)
```

#### JSX namespace changes
```typescript
// global.d.ts
// Before
namespace JSX {
  interface IntrinsicElements {
    "my-element": { myProp: string };
  }
}

// After
declare module "react" {
  namespace JSX {
    interface IntrinsicElements {
      "my-element": { myProp: string };
    }
  }
}
```

## New Features Deep Dive

### Actions Pattern
Actions represent a new paradigm for handling async operations:

1. **Automatic state management**: No manual pending/error states
2. **Built-in optimistic updates**: UI updates immediately
3. **Error boundaries integration**: Errors caught and handled
4. **Form integration**: Native form support

### Server Components Architecture
1. **Zero bundle size**: Server Components don't add to client JS
2. **Direct database access**: Fetch data without APIs
3. **Automatic code splitting**: Only send necessary code
4. **Streaming**: Progressive rendering support

### Performance Improvements
1. **Suspense improvements**: Better fallback handling
2. **Hydration improvements**: Skip third-party scripts
3. **Compiler optimizations**: Faster builds and runtime

## Code Examples

### Complete Form with Actions
```jsx
function ContactForm() {
  const [state, formAction, isPending] = useActionState(
    async (previousState, formData) => {
      const email = formData.get("email");
      const message = formData.get("message");
      
      try {
        await sendMessage({ email, message });
        return { success: true };
      } catch (error) {
        return { error: error.message };
      }
    },
    null
  );

  return (
    <form action={formAction}>
      <input 
        type="email" 
        name="email" 
        required 
        disabled={isPending}
      />
      <textarea 
        name="message" 
        required 
        disabled={isPending}
      />
      <button type="submit" disabled={isPending}>
        {isPending ? 'Sending...' : 'Send Message'}
      </button>
      {state?.error && <p className="error">{state.error}</p>}
      {state?.success && <p className="success">Message sent!</p>}
    </form>
  );
}
```

### Optimistic Todo List
```jsx
function TodoList({ todos }) {
  const [optimisticTodos, addOptimisticTodo] = useOptimistic(
    todos,
    (state, newTodo) => [...state, { id: Date.now(), text: newTodo, pending: true }]
  );

  const formAction = async (formData) => {
    const text = formData.get("todo");
    addOptimisticTodo(text);
    await createTodo(text);
  };

  return (
    <>
      <form action={formAction}>
        <input type="text" name="todo" />
        <button type="submit">Add</button>
      </form>
      <ul>
        {optimisticTodos.map(todo => (
          <li key={todo.id} style={{ opacity: todo.pending ? 0.5 : 1 }}>
            {todo.text}
          </li>
        ))}
      </ul>
    </>
  );
}
```

### Data Fetching with use()
```jsx
function UserProfile({ userPromise }) {
  const user = use(userPromise);
  
  return (
    <div>
      <h1>{user.name}</h1>
      <p>{user.email}</p>
    </div>
  );
}

function App({ userId }) {
  const userPromise = fetchUser(userId);
  
  return (
    <Suspense fallback={<div>Loading user...</div>}>
      <UserProfile userPromise={userPromise} />
    </Suspense>
  );
}
```

## Best Practices

1. **Use Actions for forms**: Replace manual form handling with Actions
2. **Adopt Server Components gradually**: Start with static content
3. **Leverage optimistic updates**: Improve perceived performance
4. **Update ref patterns**: Use ref as prop instead of forwardRef
5. **Simplify Context**: Use new Context syntax
6. **Add metadata in components**: SEO-friendly meta tags
7. **Preload critical resources**: Use new preloading APIs

## Conclusion

React 19 represents a significant evolution in React's capabilities, particularly around data fetching, forms, and server-side rendering. The new features reduce boilerplate, improve performance, and make React applications more robust and easier to maintain.

Key takeaways:
- Actions simplify async operations
- Server Components enable new architectures
- Many quality-of-life improvements
- Some breaking changes require migration
- TypeScript support improved

Start by upgrading to React 18.3 first to see deprecation warnings, then migrate to React 19 following this guide.