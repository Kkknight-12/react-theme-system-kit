# Component Patterns (ARCHIVED)

> ⚠️ **This file has been split into smaller, focused pattern files.**  
> **Please use [COMPONENT-PATTERNS-INDEX.md](../COMPONENT-PATTERNS-INDEX.md) instead.**  
> This file is kept for reference only.

**Project**: Modern Admin Dashboard Template  
**Purpose**: Advanced component patterns and composition strategies  
**Last Updated**: 2025-01-14  
**Status**: ARCHIVED - Split into patterns/ directory

## 🔗 Related Documents

- **CODING-STANDARDS.md** - Basic component structure, props handling, state management
- **THEME-SYSTEM.md** - Design tokens and theming patterns
- **MOCK-DATA-STRUCTURE.md** - Data structures for component examples
- **COMPONENT-REGISTRY.md** - Available components reference

## 🎯 Overview

Advanced component patterns for complex composition, performance optimization, and state management. Complements CODING-STANDARDS.md.

## 📚 Table of Contents

1. [Advanced Composition Patterns](#advanced-composition-patterns)
   - [Render Props Pattern](#render-props-pattern)
   - [Compound Components](#compound-components-with-context)
   - [Custom Hooks vs HOCs](#custom-hooks-vs-hocs)
   - [HOC Use Cases](#hoc-use-cases-when-hooks-wont-work)
2. [Performance Optimization Patterns](#performance-optimization-patterns)
   - [Memoization Fundamentals](#memoization-fundamentals)
   - [React.memo Rules](#reactmemo-rules)
   - [Practical Memoization Guidelines](#practical-memoization-guidelines)
   - [Elements vs Components Performance](#elements-vs-components-performance)
   - [Children as Props for Performance](#children-as-props-for-performance)
   - [Elements as Props Pattern](#elements-as-props-pattern)
3. [Configuration Patterns](#configuration-patterns)
   - [Elements as Props for Flexibility](#elements-as-props-for-flexibility)
   - [Default Props with cloneElement](#default-props-with-cloneelement)
4. [Ref Patterns](#-ref-patterns)
   - [DOM Element Access](#dom-element-access)
   - [forwardRef Pattern](#forwardref-pattern)
   - [Imperative APIs](#imperative-apis)
   - [When to Use Refs vs State](#when-to-use-refs-vs-state)
5. [Common UI Component Patterns](#-common-ui-component-patterns)
6. [Data Fetching Patterns](#-data-fetching-patterns)
7. [Loading & Skeleton Patterns](#-loading--skeleton-patterns)
8. [Animation Patterns](#-animation-patterns)
9. [Complex State Patterns](#-complex-state-patterns)
10. [Context Patterns & Performance](#-context-patterns--performance)
11. [Theme & Styling Patterns](#-theme--styling-patterns)

## 🔨 Advanced Composition Patterns

### Render Props Pattern

Use when you need maximum flexibility in rendering:

```javascript
// Generic DataList component with render props
export function DataList({ 
  data, 
  loading, 
  error, 
  renderItem, 
  renderEmpty,
  renderError,
  renderLoading 
}) {
  if (loading) {
    return renderLoading ? renderLoading() : <DefaultSkeleton />
  }
  
  if (error) {
    return renderError ? renderError(error) : <DefaultError error={error} />
  }
  
  if (!data || data.length === 0) {
    return renderEmpty ? renderEmpty() : <DefaultEmpty />
  }
  
  return (
    <div className="space-y-2">
      {data.map((item, index) => (
        <div key={item.id || index}>
          {renderItem(item, index)}
        </div>
      ))}
    </div>
  )
}

// Usage
<DataList
  data={users}
  loading={isLoading}
  error={error}
  renderItem={(user) => <UserCard user={user} />}
  renderEmpty={() => <EmptyState message="No users found" />}
  renderLoading={() => <UserListSkeleton count={5} />}
/>
```

### Compound Components with Context

For complex components with shared state (extends pattern in CODING-STANDARDS.md):

```javascript
// Table compound component with internal state management
const TableContext = createContext()

export function Table({ children, data, columns, ...props }) {
  const table = useTable({ data, columns })
  
  return (
    <TableContext.Provider value={table}>
      <div className="rounded-lg border bg-white shadow-sm" {...props}>
        {children}
      </div>
    </TableContext.Provider>
  )
}

// Sub-components access shared context
Table.Header = function TableHeader({ children }) {
  const { columns, sort, onSort } = useContext(TableContext)
  return (
    <thead className="bg-gray-50">
      {/* Header implementation */}
    </thead>
  )
}

Table.Body = function TableBody({ children }) {
  const { displayData, loading } = useContext(TableContext)
  return <tbody>{children || <DefaultRows data={displayData} />}</tbody>
}

Table.Pagination = function TablePagination() {
  const { page, pageSize, total, onPageChange } = useContext(TableContext)
  return <Pagination {...{ page, pageSize, total, onPageChange }} />
}

// Usage
<Table data={orders} columns={orderColumns}>
  <Table.Header />
  <Table.Body />
  <Table.Pagination />
</Table>
```

### Custom Hooks vs HOCs

**Prefer hooks** over HOCs for modern React (as per CODING-STANDARDS.md import order):

```javascript
// ✅ Good: Custom hook for auth
export function useRequireAuth(redirectTo = '/login') {
  const { user, loading } = useAuth()
  const navigate = useNavigate()
  
  useEffect(() => {
    if (!loading && !user) {
      navigate(redirectTo)
    }
  }, [user, loading, navigate, redirectTo])
  
  return { user, loading }
}

// Usage in component
export function DashboardPage() {
  const { user, loading } = useRequireAuth()
  
  if (loading) return <PageSkeleton />
  
  return <Dashboard user={user} />
}

// ❌ Avoid: HOC pattern (harder to type, compose)
export function withAuth(Component) {
  return function AuthenticatedComponent(props) {
    // HOC logic
  }
}
```

### HOC Use Cases (When Hooks Won't Work)

```javascript
// 1. Authentication wrapper
function withAuth(Component) {
  return function AuthenticatedComponent(props) {
    const { user } = useAuth()
    if (!user) return <Navigate to="/login" />
    return <Component {...props} user={user} />
  }
}

// 2. Error boundary (requires class component)
function withErrorBoundary(Component) {
  return class extends React.Component {
    state = { hasError: false }
    static getDerivedStateFromError() {
      return { hasError: true }
    }
    render() {
      if (this.state.hasError) return <ErrorFallback />
      return <Component {...this.props} />
    }
  }
}
```

## Performance Optimization Patterns

For cross-cutting concerns like keyboard shortcuts or preventing event propagation:

```javascript
// Suppress keyboard events from bubbling up
export const withSuppressKeyboardEvents = (Component) => {
  return (props) => {
    const handleKeyDown = (e) => {
      // Prevent global keyboard shortcuts when this component is focused
      e.stopPropagation()
    }
    
    return (
      <div onKeyDown={handleKeyDown}>
        <Component {...props} />
      </div>
    )
  }
}

// Global keyboard shortcuts HOC
export const withKeyboardShortcuts = (Component, shortcuts = {}) => {
  return (props) => {
    useEffect(() => {
      const handleKeyPress = (e) => {
        const key = `${e.ctrlKey ? 'ctrl+' : ''}${e.key}`
        const handler = shortcuts[key]
        
        if (handler) {
          e.preventDefault()
          handler(props)
        }
      }
      
      window.addEventListener('keydown', handleKeyPress)
      return () => window.removeEventListener('keydown', handleKeyPress)
    }, [props])
    
    return <Component {...props} />
  }
}

// Usage
const DialogWithShortcuts = withKeyboardShortcuts(Dialog, {
  'Escape': (props) => props.onClose?.(),
  'ctrl+s': (props) => props.onSave?.()
})

// Prevent shortcuts in modal from affecting parent
const ModalWithSuppressedKeys = withSuppressKeyboardEvents(Modal)
```

#### 3. Performance Monitoring

Adding performance metrics without cluttering component code:

```javascript
// Monitor component render performance
export const withRenderMetrics = (Component) => {
  return (props) => {
    const renderStart = performance.now()
    
    useEffect(() => {
      const renderEnd = performance.now()
      const renderTime = renderEnd - renderStart
      
      if (renderTime > 16) { // Longer than one frame (60fps)
        console.warn(`Slow render detected in ${Component.name}:`, {
          renderTime: `${renderTime.toFixed(2)}ms`,
          props: Object.keys(props)
        })
      }
    })
    
    return <Component {...props} />
  }
}

// Usage in development
const MonitoredDataTable = process.env.NODE_ENV === 'development' 
  ? withRenderMetrics(DataTable)
  : DataTable
```

#### 4. Analytics Event Tracking

Consistent analytics tracking across components:

```javascript
// Analytics HOC with lifecycle tracking
export const withAnalytics = (Component, eventName) => {
  return (props) => {
    const analytics = useAnalytics()
    
    // Track mount
    useEffect(() => {
      analytics.track(`${eventName}_viewed`, {
        component: Component.name,
        timestamp: new Date().toISOString()
      })
    }, [])
    
    // Enhanced callbacks with analytics
    const createTrackedHandler = (originalHandler, actionName) => {
      return (...args) => {
        analytics.track(`${eventName}_${actionName}`, {
          component: Component.name
        })
        originalHandler?.(...args)
      }
    }
    
    // Wrap all on* props
    const trackedProps = Object.entries(props).reduce((acc, [key, value]) => {
      if (key.startsWith('on') && typeof value === 'function') {
        acc[key] = createTrackedHandler(value, key.slice(2).toLowerCase())
      } else {
        acc[key] = value
      }
      return acc
    }, {})
    
    return <Component {...trackedProps} />
  }
}

// Usage
const ProductCardWithAnalytics = withAnalytics(ProductCard, 'product_card')
const CheckoutButtonWithAnalytics = withAnalytics(CheckoutButton, 'checkout')
```

#### When to Use HOCs vs Hooks

**Use Hooks (99% of cases)**: State/context access, sharing logic
**Use HOCs**: Cross-cutting concerns, intercepting callbacks, transparent wrappers

#### HOC Best Practices

1. **Name conventions**: Use `with` prefix (e.g., `withLogging`)
2. **Display name**: Set for debugging
   ```javascript
   const withExample = (Component) => {
     const WrappedComponent = (props) => <Component {...props} />
     WrappedComponent.displayName = `withExample(${Component.displayName || Component.name})`
     return WrappedComponent
   }
   ```
3. **Props forwarding**: Always forward all props
4. **Ref forwarding**: Use `forwardRef` if needed
5. **Static methods**: Copy static methods from wrapped component

#### Important Notes

- **Prefer hooks for 99% of use cases** - HOCs add complexity
- **Use HOCs only when hooks don't fit well** - Usually for cross-cutting concerns
- **Don't create HOCs in render** - Will cause remounts
- **Consider performance** - Each HOC adds a component layer

## 🚀 Performance Optimization Patterns

### Memoization Fundamentals

#### Reference vs Value Comparison
```javascript
// Primitives compare by value
const a = 1;
const b = 1;
a === b; // true

// Objects compare by reference
const a = { id: 1 };
const b = { id: 1 };
a === b; // false - different references

const c = a;
a === c; // true - same reference
```

#### How useMemo and useCallback Work
```javascript
// useCallback - memoizes the function itself
const handleClick = useCallback(() => {
  console.log('clicked');
}, []); // Empty deps = stable reference

// useMemo - memoizes the return value
const expensiveValue = useMemo(() => {
  return someExpensiveCalculation();
}, [dependency]);

// Common misconception: Both recreate their first argument function on every render!
// The difference is what they return (function vs result)
```

### React.memo Rules

#### When React.memo Works
```javascript
// ✅ GOOD: All props are memoized
const Child = React.memo(({ data, onClick }) => {
  return <div onClick={onClick}>{data.name}</div>;
});

const Parent = () => {
  const data = useMemo(() => ({ name: 'John' }), []);
  const onClick = useCallback(() => console.log('clicked'), []);
  
  return <Child data={data} onClick={onClick} />;
};
```

#### Common React.memo Pitfalls

```javascript
// ❌ ANTIPATTERN: Memoizing props without React.memo
const Parent = () => {
  // This useCallback is useless - Child will re-render anyway
  const onClick = useCallback(() => {}, []);
  return <Child onClick={onClick} />;
};

// ❌ BROKEN: Non-memoized inline props
const Parent = () => {
  return (
    <ChildMemo 
      data={{ id: 1 }} // New object every render!
      onClick={() => {}} // New function every render!
    />
  );
};

// ❌ BROKEN: Spreading props breaks memoization
const Wrapper = (props) => {
  return <ChildMemo {...props} />; // Can't control if props are memoized
};

// ❌ BROKEN: Children prop is not memoized
const Parent = () => {
  return (
    <ChildMemo>
      <div>Content</div> {/* This is a new object every render! */}
    </ChildMemo>
  );
};

// ✅ FIX: Memoize children too
const Parent = () => {
  const content = useMemo(() => <div>Content</div>, []);
  return <ChildMemo>{content}</ChildMemo>;
};
```

### Practical Memoization Guidelines

#### When to Use Memoization

1. **Dependencies in hooks**:
```javascript
const Parent = () => {
  // Must memoize if used in child's useEffect
  const fetchData = useCallback(async () => {
    const data = await api.getData();
    setData(data);
  }, []);
  
  return <Child onMount={fetchData} />;
};

const Child = ({ onMount }) => {
  useEffect(() => {
    onMount(); // Needs stable reference
  }, [onMount]);
};
```

#### With React.memo components:
```javascript
const ExpensiveList = React.memo(({ items, renderItem }) => {
  return items.map(renderItem);
});

const Parent = () => {
  const renderItem = useCallback((item) => (
    <ListItem key={item.id} {...item} />
  ), []);
  
  return <ExpensiveList items={items} renderItem={renderItem} />;
};
```

#### When NOT to Use Memoization

```javascript
// ❌ Over-memoization: Simple calculations
const Component = ({ user }) => {
  // Don't memoize trivial operations
  const fullName = useMemo(() => `${user.first} ${user.last}`, [user]);
  
  // Just do this instead:
  // const fullName = `${user.first} ${user.last}`;
};

// ❌ No re-renders: Component never re-renders
const StaticComponent = () => {
  // useMemo here just adds overhead on mount
  const value = useMemo(() => heavyCalculation(), []);
};

// ❌ Premature optimization: Measure first!
// Is sorting 300 items (2ms) worth the complexity vs 
// re-rendering the list components (20ms)?
```

### Escaping Stale Closures

Powerful technique for stable callbacks with fresh state access:

```javascript
// ❌ Problem: Stale closure with React.memo
const ExpensiveChild = React.memo(({ onClick }) => {
  return <button onClick={onClick}>Click</button>
})

function Parent() {
  const [count, setCount] = useState(0)
  
  // This creates stale closure if we try to memoize
  const handleClick = useCallback(() => {
    console.log(count) // Always logs initial value!
  }, []) // Empty deps = stale closure
  
  return <ExpensiveChild onClick={handleClick} />
}

// ✅ Solution: Ref + stable callback pattern
function Parent() {
  const [count, setCount] = useState(0)
  const countRef = useRef()
  
  // Update ref on every render
  useEffect(() => {
    countRef.current = count
  })
  
  // Stable callback that accesses fresh value via ref
  const handleClick = useCallback(() => {
    console.log(countRef.current) // Always latest!
  }, []) // Empty deps but fresh data!
  
  return <ExpensiveChild onClick={handleClick} />
}
```

#### Advanced Pattern: Ref Callback Hook
```javascript
function useStableCallback(callback) {
  const callbackRef = useRef(callback)
  
  // Update ref on every render
  useEffect(() => {
    callbackRef.current = callback
  })
  
  // Return stable callback that calls current ref
  return useCallback((...args) => {
    return callbackRef.current(...args)
  }, [])
}

// Usage
function Form() {
  const [formData, setFormData] = useState({})
  
  // Stable callback with access to latest formData
  const handleSubmit = useStableCallback(() => {
    console.log('Submitting:', formData)
    api.submitForm(formData)
  })
  
  return (
    <ExpensiveForm 
      onSubmit={handleSubmit}
      onChange={setFormData}
    />
  )
}
```

### Elements vs Components Performance

```javascript
// Component - A function that returns elements
const Button = (props) => {
  return <button>{props.label}</button>
}

// Element - An object that describes what to render
const buttonElement = <Button label="Click me" />
// This is actually: React.createElement(Button, { label: "Click me" })

// The element object looks like:
// {
//   type: Button,
//   props: { label: "Click me" },
//   // ... other React internals
// }
```

**Key insight**: When React compares elements before and after re-render using `Object.is()`, if the element object is the same reference, React skips re-rendering that component and its children.

### Children as Props for Performance

One of the most elegant ways to prevent unnecessary re-renders is passing components as children. This pattern leverages the fact that elements created outside a component won't re-render when that component's state changes.

#### The Problem

```javascript
// ❌ Poor performance - all children re-render on scroll
export function ScrollableArea() {
  const [scrollPosition, setScrollPosition] = useState(0)
  
  const handleScroll = (e) => {
    setScrollPosition(e.target.scrollTop)
  }
  
  return (
    <div className="scrollable" onScroll={handleScroll}>
      <FloatingNav position={scrollPosition} />
      <VerySlowComponent />
      <ExpensiveList />
      <HeavyVisualization />
    </div>
  )
}
```

#### The Solution

```javascript
// ✅ Excellent performance - only FloatingNav re-renders
export function ScrollableArea({ children }) {
  const [scrollPosition, setScrollPosition] = useState(0)
  
  const handleScroll = (e) => {
    setScrollPosition(e.target.scrollTop)
  }
  
  return (
    <div className="scrollable" onScroll={handleScroll}>
      <FloatingNav position={scrollPosition} />
      {children}
    </div>
  )
}

// Usage - slow components are passed as children
<ScrollableArea>
  <VerySlowComponent />
  <ExpensiveList />
  <HeavyVisualization />
</ScrollableArea>
```

**Why this works**: The children elements are created in the parent scope. When `ScrollableArea` re-renders due to state change, React sees that the children prop is the same object reference as before, so it skips re-rendering them.

### Elements as Props Pattern

This pattern extends beyond just children - any prop can be an element to prevent re-renders:

```javascript
// Flexible layout that doesn't re-render static content
export function DashboardLayout({ 
  header,
  sidebar, 
  content,
  showNotifications 
}) {
  const [notifications, setNotifications] = useState([])
  
  // Fetch notifications periodically
  useEffect(() => {
    const interval = setInterval(fetchNotifications, 5000)
    return () => clearInterval(interval)
  }, [])
  
  return (
    <div className="dashboard">
      <div className="header">
        {header}
        {showNotifications && <NotificationBell count={notifications.length} />}
      </div>
      <div className="sidebar">{sidebar}</div>
      <div className="content">{content}</div>
    </div>
  )
}

// Usage - header, sidebar, content won't re-render when notifications update
<DashboardLayout
  header={<Header />}
  sidebar={<NavigationMenu />}
  content={<MainContent />}
  showNotifications
/>
```


## 🔧 Configuration Patterns

### Elements as Props for Flexibility


Avoid props explosion:

```javascript
// ✅ Clean and flexible
function Button({ icon, children, onClick }) {
  return (
    <button onClick={onClick} className="btn">
      {icon}
      {children}
    </button>
  )
}

// Usage - infinite flexibility
<Button icon={<LoadingSpinner />}>Submit</Button>
<Button icon={<CheckIcon color="green" />}>Save</Button>
<Button icon={<Avatar src="/user.jpg" size="sm" />}>Profile</Button>
```

### Modal with Flexible Sections

```javascript
export function Modal({ 
  header,
  content,
  footer,
  isOpen,
  onClose 
}) {
  if (!isOpen) return null
  
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        {header && <div className="modal-header">{header}</div>}
        <div className="modal-content">{content}</div>
        {footer && <div className="modal-footer">{footer}</div>}
      </div>
    </div>
  )
}

// Usage examples
<Modal
  isOpen={showSuccess}
  onClose={() => setShowSuccess(false)}
  header={<h2>Success!</h2>}
  content={<SuccessMessage />}
  footer={<Button onClick={() => setShowSuccess(false)}>Close</Button>}
/>

<Modal
  isOpen={showForm}
  onClose={() => setShowForm(false)}
  header={
    <div className="flex justify-between">
      <h2>Edit Profile</h2>
      <CloseButton onClick={() => setShowForm(false)} />
    </div>
  }
  content={<ProfileForm />}
  footer={
    <>
      <Button variant="ghost" onClick={() => setShowForm(false)}>Cancel</Button>
      <Button variant="primary" onClick={handleSave}>Save Changes</Button>
    </>
  }
/>
```

### Default Props with cloneElement

When you need to provide default props to elements passed as props:

```javascript
export function IconButton({ icon, size = 'md', variant = 'primary', ...props }) {
  // Define default icon props based on button props
  const iconDefaults = {
    size: size === 'lg' ? 24 : size === 'sm' ? 16 : 20,
    color: variant === 'primary' ? 'white' : 'currentColor',
    'aria-hidden': true
  }
  
  // Clone icon with defaults, but allow overrides
  const enhancedIcon = React.cloneElement(icon, {
    ...iconDefaults,
    ...icon.props // Original props override defaults
  })
  
  return (
    <button 
      className={cn('icon-btn', `icon-btn--${size}`, `icon-btn--${variant}`)}
      {...props}
    >
      {enhancedIcon}
    </button>
  )
}

// Usage
<IconButton icon={<SaveIcon />} /> // Uses default size and color
<IconButton icon={<SaveIcon size={32} />} size="lg" /> // Override default size
<IconButton icon={<DeleteIcon color="red" />} variant="ghost" /> // Override color
```

**⚠️ Warning**: Be careful with cloneElement - always preserve original props to avoid confusing behavior.

### Render Props for Complex Interactions

```javascript
export function DragDropZone({ onDrop, renderContent }) {
  const [isDragging, setIsDragging] = useState(false)
  const [draggedFiles, setDraggedFiles] = useState([])
  
  const handleDragEnter = (e) => {
    e.preventDefault()
    setIsDragging(true)
  }
  
  const handleDragLeave = (e) => {
    e.preventDefault()
    setIsDragging(false)
  }
  
  const handleDrop = (e) => {
    e.preventDefault()
    setIsDragging(false)
    const files = Array.from(e.dataTransfer.files)
    setDraggedFiles(files)
    onDrop(files)
  }
  
  const zoneProps = {
    onDragEnter: handleDragEnter,
    onDragLeave: handleDragLeave,
    onDragOver: (e) => e.preventDefault(),
    onDrop: handleDrop,
    className: cn(
      'drag-drop-zone',
      isDragging && 'drag-drop-zone--active'
    )
  }
  
  return renderContent({
    zoneProps,
    isDragging,
    draggedFiles,
    fileCount: draggedFiles.length
  })
}

// Usage - full control over rendering
<DragDropZone
  onDrop={handleFileUpload}
  renderContent={({ zoneProps, isDragging, fileCount }) => (
    <div {...zoneProps}>
      {isDragging ? (
        <div className="text-center p-8">
          <UploadIcon className="animate-bounce" />
          <p>Drop files here...</p>
        </div>
      ) : fileCount > 0 ? (
        <div className="p-4">
          <CheckIcon className="text-green-500" />
          <p>{fileCount} files selected</p>
        </div>
      ) : (
        <div className="text-center p-8">
          <UploadIcon />
          <p>Drag files here or click to browse</p>
        </div>
      )}
    </div>
  )}
/>
```


## 📍 Ref Patterns

### DOM Element Access

Use refs for direct DOM manipulation like focus, scroll, or measurements:

```javascript
export function SearchInput({ onSearch }) {
  const inputRef = useRef(null)
  
  useEffect(() => {
    // Auto-focus on mount
    inputRef.current?.focus()
  }, [])
  
  const handleClear = () => {
    if (inputRef.current) {
      inputRef.current.value = ''
      inputRef.current.focus()
    }
  }
  
  return (
    <div className="relative">
      <input
        ref={inputRef}
        type="text"
        className="pr-10"
        onKeyDown={(e) => {
          if (e.key === 'Enter') {
            onSearch(e.target.value)
          }
        }}
      />
      <button
        onClick={handleClear}
        className="absolute right-2 top-1/2 -translate-y-1/2"
      >
        <XIcon />
      </button>
    </div>
  )
}
```

### forwardRef Pattern

Pass refs through component boundaries:

```javascript
// ❌ This won't work - ref is reserved
function Input({ ref, label }) {
  return <input ref={ref} />
}

// ✅ Use forwardRef to pass refs
const Input = forwardRef(({ label, ...props }, ref) => {
  return (
    <div>
      <label>{label}</label>
      <input ref={ref} {...props} />
    </div>
  )
})

// Usage
function Form() {
  const nameRef = useRef(null)
  
  const focusName = () => {
    nameRef.current?.focus()
  }
  
  return (
    <>
      <Input ref={nameRef} label="Name" />
      <button onClick={focusName}>Focus Name</button>
    </>
  )
}
```

### Imperative APIs

Expose component methods while hiding implementation:

```javascript
// Using useImperativeHandle
const FancyInput = forwardRef((props, ref) => {
  const inputRef = useRef(null)
  const [shake, setShake] = useState(false)
  
  useImperativeHandle(ref, () => ({
    focus: () => {
      inputRef.current?.focus()
    },
    shake: () => {
      setShake(true)
      setTimeout(() => setShake(false), 500)
    },
    clear: () => {
      if (inputRef.current) {
        inputRef.current.value = ''
      }
    }
  }), [])
  
  return (
    <input
      ref={inputRef}
      className={cn(
        "transition-transform",
        shake && "animate-shake"
      )}
      {...props}
    />
  )
})

// Usage
function LoginForm() {
  const passwordRef = useRef(null)
  
  const handleSubmit = () => {
    if (!password) {
      passwordRef.current?.shake()
      passwordRef.current?.focus()
    }
  }
  
  return (
    <>
      <FancyInput ref={passwordRef} type="password" />
      <button onClick={handleSubmit}>Login</button>
    </>
  )
}
```

### When to Use Refs vs State

#### Use Refs for:
- Values that don't affect render output
- DOM element references
- Storing previous values
- Timer/interval IDs
- External library instances

```javascript
function VideoPlayer({ src }) {
  const videoRef = useRef(null)
  const intervalRef = useRef(null)
  const previousVolumeRef = useRef(1)
  
  // Store non-render data
  const handleMute = () => {
    if (videoRef.current) {
      previousVolumeRef.current = videoRef.current.volume
      videoRef.current.volume = 0
    }
  }
  
  // Store timer IDs
  const startProgressTracking = () => {
    intervalRef.current = setInterval(() => {
      console.log('Progress:', videoRef.current?.currentTime)
    }, 1000)
  }
  
  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
      }
    }
  }, [])
  
  return <video ref={videoRef} src={src} />
}
```

#### Use State for:
- Values that affect what's rendered
- Values shown in the UI
- Values that trigger effects when changed

```javascript
function Counter() {
  // ✅ Use state - affects UI
  const [count, setCount] = useState(0)
  
  // ❌ Don't use ref for UI values
  // const countRef = useRef(0)
  
  return (
    <div>
      <p>Count: {count}</p>
      <button onClick={() => setCount(count + 1)}>+</button>
    </div>
  )
}
```

### Practical Ref Patterns

#### Previous Value Hook
```javascript
function usePrevious(value) {
  const ref = useRef()
  
  useEffect(() => {
    ref.current = value
  }, [value])
  
  return ref.current
}

// Usage
function PriceDisplay({ price }) {
  const prevPrice = usePrevious(price)
  
  return (
    <div>
      <span>{price}</span>
      {prevPrice && price > prevPrice && (
        <ArrowUpIcon className="text-red-500" />
      )}
    </div>
  )
}
```

#### Click Outside Detection
```javascript
function useClickOutside(handler) {
  const ref = useRef()
  
  useEffect(() => {
    const listener = (event) => {
      if (!ref.current || ref.current.contains(event.target)) {
        return
      }
      handler(event)
    }
    
    document.addEventListener('mousedown', listener)
    document.addEventListener('touchstart', listener)
    
    return () => {
      document.removeEventListener('mousedown', listener)
      document.removeEventListener('touchstart', listener)
    }
  }, [handler])
  
  return ref
}

// Usage
function Dropdown() {
  const [isOpen, setIsOpen] = useState(false)
  const dropdownRef = useClickOutside(() => setIsOpen(false))
  
  return (
    <div ref={dropdownRef} className="relative">
      <button onClick={() => setIsOpen(!isOpen)}>Menu</button>
      {isOpen && (
        <div className="absolute top-full mt-2">
          {/* Dropdown content */}
        </div>
      )}
    </div>
  )
}
```

### Debouncing & Throttling Patterns

Proper implementation with access to latest state:

```javascript
// ❌ Common mistake - recreates debounced function
function SearchInput() {
  const [query, setQuery] = useState('')
  
  const search = (value) => {
    console.log('Searching:', value)
  }
  
  // This recreates debounced function on every render!
  const debouncedSearch = debounce(search, 500)
  
  return (
    <input
      value={query}
      onChange={(e) => {
        setQuery(e.target.value)
        debouncedSearch(e.target.value)
      }}
    />
  )
}

// ✅ Solution 1: Memoize with useCallback
function SearchInput() {
  const [query, setQuery] = useState('')
  
  const search = useCallback((value) => {
    console.log('Searching:', value)
  }, [])
  
  const debouncedSearch = useMemo(
    () => debounce(search, 500),
    [search]
  )
  
  return (
    <input
      value={query}
      onChange={(e) => {
        setQuery(e.target.value)
        debouncedSearch(e.target.value)
      }}
    />
  )
}

// ✅ Solution 2: Custom hook with ref pattern
function useDebounce(callback, delay) {
  const callbackRef = useRef(callback)
  
  // Update ref when callback changes
  useEffect(() => {
    callbackRef.current = callback
  })
  
  // Create stable debounced function
  const debouncedCallback = useMemo(() => {
    return debounce((...args) => {
      callbackRef.current(...args)
    }, delay)
  }, [delay])
  
  // Cleanup
  useEffect(() => {
    return () => {
      debouncedCallback.cancel()
    }
  }, [debouncedCallback])
  
  return debouncedCallback
}

// Usage with access to latest state
function SearchInput() {
  const [query, setQuery] = useState('')
  const [filters, setFilters] = useState({})
  
  const search = useDebounce(() => {
    // Access to latest state!
    console.log('Searching:', { query, filters })
    api.search({ query, filters })
  }, 500)
  
  return (
    <input
      value={query}
      onChange={(e) => {
        setQuery(e.target.value)
        search()
      }}
    />
  )
}
```

#### Auto-save Pattern
```javascript
function useAutoSave(data, saveFunction, delay = 1000) {
  const [saveState, setSaveState] = useState('idle')
  
  const save = useDebounce(async () => {
    setSaveState('saving')
    try {
      await saveFunction(data)
      setSaveState('saved')
      setTimeout(() => setSaveState('idle'), 2000)
    } catch (error) {
      setSaveState('error')
    }
  }, delay)
  
  // Trigger save when data changes
  useEffect(() => {
    if (data) {
      save()
    }
  }, [data, save])
  
  return saveState
}

// Usage
function Editor({ documentId }) {
  const [content, setContent] = useState('')
  
  const saveState = useAutoSave(content, async (data) => {
    await api.saveDocument(documentId, { content: data })
  })
  
  return (
    <div>
      <textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
      />
      <SaveIndicator state={saveState} />
    </div>
  )
}
```


## 🎨 Common UI Component Patterns

### Modal/Dialog Pattern

Accessible modal with focus management:

```javascript
import { useEffect, useRef } from 'react'
import { createPortal } from 'react-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { cn } from '@/lib/utils'

export function Modal({ 
  isOpen, 
  onClose, 
  title, 
  children, 
  size = 'md',
  closeOnBackdrop = true,
  closeOnEsc = true 
}) {
  const modalRef = useRef(null)
  const previousActiveElement = useRef(null)
  
  // Focus management
  useEffect(() => {
    if (isOpen) {
      previousActiveElement.current = document.activeElement
      modalRef.current?.focus()
    } else {
      previousActiveElement.current?.focus()
    }
  }, [isOpen])
  
  // ESC key handler
  useEffect(() => {
    if (!isOpen || !closeOnEsc) return
    
    const handleEsc = (e) => {
      if (e.key === 'Escape') onClose()
    }
    
    document.addEventListener('keydown', handleEsc)
    return () => document.removeEventListener('keydown', handleEsc)
  }, [isOpen, onClose, closeOnEsc])
  
  // Body scroll lock
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = ''
    }
    return () => {
      document.body.style.overflow = ''
    }
  }, [isOpen])
  
  const sizeClasses = {
    sm: 'max-w-md',
    md: 'max-w-lg',
    lg: 'max-w-2xl',
    xl: 'max-w-4xl',
    full: 'max-w-full mx-4'
  }
  
  return createPortal(
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/50"
            onClick={closeOnBackdrop ? onClose : undefined}
          />
          
          {/* Modal */}
          <motion.div
            ref={modalRef}
            tabIndex={-1}
            role="dialog"
            aria-modal="true"
            aria-labelledby="modal-title"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className={cn(
              "relative z-10 w-full bg-white rounded-lg shadow-xl",
              "max-h-[90vh] overflow-hidden",
              sizeClasses[size]
            )}
          >
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b">
              <h2 id="modal-title" className="text-xl font-semibold">
                {title}
              </h2>
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                aria-label="Close modal"
              >
                <XIcon className="h-5 w-5" />
              </button>
            </div>
            
            {/* Content */}
            <div className="p-6 overflow-y-auto max-h-[calc(90vh-8rem)]">
              {children}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>,
    document.body
  )
}
```

### Advanced Table Pattern

Building on the useTable hook mentioned in CODING-STANDARDS.md:

```javascript
// Advanced table hook with all features
export function useTable({
  data = [],
  columns = [],
  pageSize: defaultPageSize = 10,
  defaultSort = null,
  enableSelection = true,
  enableFilters = true
}) {
  // Pagination state
  const [page, setPage] = useState(0)
  const [pageSize, setPageSize] = useState(defaultPageSize)
  
  // Sorting state
  const [sort, setSort] = useState(defaultSort)
  
  // Selection state
  const [selected, setSelected] = useState(new Set())
  
  // Filter state
  const [filters, setFilters] = useState({})
  const [globalFilter, setGlobalFilter] = useState('')
  
  // Apply filters
  const filteredData = useMemo(() => {
    let result = [...data]
    
    // Global filter
    if (globalFilter) {
      result = result.filter(row =>
        columns.some(col => {
          const value = row[col.key]
          return String(value).toLowerCase().includes(globalFilter.toLowerCase())
        })
      )
    }
    
    // Column filters
    Object.entries(filters).forEach(([key, filterValue]) => {
      if (filterValue) {
        result = result.filter(row => {
          const value = row[key]
          return String(value).toLowerCase().includes(filterValue.toLowerCase())
        })
      }
    })
    
    return result
  }, [data, filters, globalFilter, columns])
  
  // Apply sorting
  const sortedData = useMemo(() => {
    if (!sort) return filteredData
    
    return [...filteredData].sort((a, b) => {
      const aVal = a[sort.key]
      const bVal = b[sort.key]
      
      if (aVal < bVal) return sort.direction === 'asc' ? -1 : 1
      if (aVal > bVal) return sort.direction === 'asc' ? 1 : -1
      return 0
    })
  }, [filteredData, sort])
  
  // Apply pagination
  const paginatedData = useMemo(() => {
    const start = page * pageSize
    const end = start + pageSize
    return sortedData.slice(start, end)
  }, [sortedData, page, pageSize])
  
  // Selection handlers
  const handleSelectAll = () => {
    if (selected.size === paginatedData.length) {
      setSelected(new Set())
    } else {
      setSelected(new Set(paginatedData.map(row => row.id)))
    }
  }
  
  const handleSelectRow = (id) => {
    const newSelected = new Set(selected)
    if (newSelected.has(id)) {
      newSelected.delete(id)
    } else {
      newSelected.add(id)
    }
    setSelected(newSelected)
  }
  
  // Sort handler
  const handleSort = (key) => {
    setSort(prev => {
      if (!prev || prev.key !== key) {
        return { key, direction: 'asc' }
      }
      if (prev.direction === 'asc') {
        return { key, direction: 'desc' }
      }
      return null
    })
  }
  
  return {
    // Data
    data: paginatedData,
    total: filteredData.length,
    
    // Pagination
    page,
    pageSize,
    pageCount: Math.ceil(filteredData.length / pageSize),
    setPage,
    setPageSize,
    
    // Sorting
    sort,
    onSort: handleSort,
    
    // Selection
    selected,
    onSelectRow: enableSelection ? handleSelectRow : undefined,
    onSelectAll: enableSelection ? handleSelectAll : undefined,
    isAllSelected: selected.size === paginatedData.length && paginatedData.length > 0,
    
    // Filters
    filters,
    globalFilter,
    setFilters,
    setGlobalFilter,
    onFilterChange: (key, value) => setFilters(prev => ({ ...prev, [key]: value })),
    
    // Actions
    reset: () => {
      setPage(0)
      setSort(defaultSort)
      setSelected(new Set())
      setFilters({})
      setGlobalFilter('')
    }
  }
}
```

### List with Filters Pattern

```javascript
export function FilterableList({ 
  items, 
  filters, 
  renderItem, 
  renderFilters,
  searchPlaceholder = "Search..." 
}) {
  const [search, setSearch] = useState('')
  const [activeFilters, setActiveFilters] = useState({})
  
  const filteredItems = useMemo(() => {
    let result = [...items]
    
    // Apply search
    if (search) {
      result = result.filter(item => 
        item.searchableText?.toLowerCase().includes(search.toLowerCase())
      )
    }
    
    // Apply filters
    Object.entries(activeFilters).forEach(([key, value]) => {
      if (value !== null && value !== undefined && value !== '') {
        result = result.filter(item => item[key] === value)
      }
    })
    
    return result
  }, [items, search, activeFilters])
  
  return (
    <div className="space-y-4">
      {/* Search */}
      <div className="flex gap-4">
        <div className="flex-1 relative">
          <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={searchPlaceholder}
            className="w-full pl-10 pr-4 py-2 border rounded-lg"
          />
        </div>
        
        {/* Filter dropdown */}
        {renderFilters && (
          <Popover>
            <Popover.Trigger asChild>
              <Button variant="outline" size="icon">
                <FilterIcon className="h-4 w-4" />
              </Button>
            </Popover.Trigger>
            <Popover.Content>
              {renderFilters(activeFilters, setActiveFilters)}
            </Popover.Content>
          </Popover>
        )}
      </div>
      
      {/* Results count */}
      <div className="text-sm text-gray-600">
        Showing {filteredItems.length} of {items.length} items
      </div>
      
      {/* List */}
      <div className="space-y-2">
        {filteredItems.map((item, index) => (
          <div key={item.id || index}>
            {renderItem(item, index)}
          </div>
        ))}
      </div>
      
      {/* Empty state */}
      {filteredItems.length === 0 && (
        <EmptyState
          message={search || Object.keys(activeFilters).length > 0 
            ? "No items match your filters" 
            : "No items found"
          }
          action={
            (search || Object.keys(activeFilters).length > 0) && (
              <Button
                variant="link"
                onClick={() => {
                  setSearch('')
                  setActiveFilters({})
                }}
              >
                Clear filters
              </Button>
            )
          }
        />
      )}
    </div>
  )
}
```

## 📊 Data Fetching Patterns

### Page-Level Data Fetching

Fetch data at the page level (following MOCK-DATA-STRUCTURE.md for types):

```javascript
// Page component with data fetching
export function UsersPage() {
  const dispatch = useDispatch()
  const { users, loading, error } = useSelector(state => state.users)
  
  // Fetch on mount
  useEffect(() => {
    dispatch(fetchUsers())
  }, [dispatch])
  
  // Refetch handler
  const handleRefresh = () => {
    dispatch(fetchUsers())
  }
  
  if (loading && !users.length) {
    return <PageSkeleton />
  }
  
  if (error && !users.length) {
    return (
      <ErrorState 
        error={error} 
        onRetry={handleRefresh}
      />
    )
  }
  
  return (
    <PageLayout>
      <PageHeader 
        title="Users" 
        actions={
          <Button onClick={handleRefresh} disabled={loading}>
            <RefreshIcon className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        }
      />
      
      <UsersList 
        users={users}
        loading={loading}
        onUserClick={(user) => navigate(`/users/${user.id}`)}
      />
    </PageLayout>
  )
}
```

### Optimistic Updates Pattern

```javascript
// Optimistic update for better UX
export function TodoItem({ todo }) {
  const dispatch = useDispatch()
  const [optimisticComplete, setOptimisticComplete] = useState(todo.completed)
  
  const handleToggle = async () => {
    // Optimistic update
    const newState = !optimisticComplete
    setOptimisticComplete(newState)
    
    try {
      // Actual update
      await dispatch(updateTodo({ 
        id: todo.id, 
        completed: newState 
      })).unwrap()
    } catch (error) {
      // Revert on error
      setOptimisticComplete(!newState)
      toast.error('Failed to update todo')
    }
  }
  
  return (
    <div className={cn(
      "flex items-center p-4 rounded-lg border",
      optimisticComplete && "opacity-60"
    )}>
      <Checkbox
        checked={optimisticComplete}
        onCheckedChange={handleToggle}
      />
      <span className={cn(
        "ml-3",
        optimisticComplete && "line-through"
      )}>
        {todo.title}
      </span>
    </div>
  )
}
```

### Infinite Scroll Pattern

```javascript
export function useInfiniteScroll({
  fetchMore,
  hasMore,
  loading,
  threshold = 100
}) {
  const observerRef = useRef()
  const loadMoreRef = useRef()
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !loading) {
          fetchMore()
        }
      },
      { rootMargin: `${threshold}px` }
    )
    
    if (loadMoreRef.current) {
      observer.observe(loadMoreRef.current)
    }
    
    observerRef.current = observer
    
    return () => observer.disconnect()
  }, [fetchMore, hasMore, loading, threshold])
  
  return loadMoreRef
}

// Usage
export function InfiniteProductList() {
  const { 
    products, 
    loading, 
    hasMore, 
    fetchNextPage 
  } = useInfiniteProducts()
  
  const loadMoreRef = useInfiniteScroll({
    fetchMore: fetchNextPage,
    hasMore,
    loading
  })
  
  return (
    <div className="grid grid-cols-3 gap-4">
      {products.map(product => (
        <ProductCard key={product.id} product={product} />
      ))}
      
      {/* Loading indicator */}
      {loading && (
        <div className="col-span-3 py-4">
          <Spinner className="mx-auto" />
        </div>
      )}
      
      {/* Infinite scroll trigger */}
      <div ref={loadMoreRef} className="h-1" />
      
      {/* End of list */}
      {!hasMore && products.length > 0 && (
        <div className="col-span-3 text-center py-8 text-gray-500">
          No more products to load
        </div>
      )}
    </div>
  )
}
```

## 🔄 Loading & Skeleton Patterns

### Skeleton Components

Create reusable skeleton components matching your UI:

```javascript
// Generic skeleton component
export function Skeleton({ 
  className, 
  variant = 'text',
  animation = 'pulse' 
}) {
  const baseClasses = "bg-gray-200 rounded"
  
  const variantClasses = {
    text: "h-4 w-full",
    circular: "rounded-full",
    rectangular: "rounded-md",
    button: "h-10 w-24"
  }
  
  const animationClasses = {
    pulse: "animate-pulse",
    wave: "animate-shimmer",
    none: ""
  }
  
  return (
    <div 
      className={cn(
        baseClasses,
        variantClasses[variant],
        animationClasses[animation],
        className
      )}
    />
  )
}

// Specific skeleton components
export function UserCardSkeleton() {
  return (
    <div className="p-4 bg-white rounded-lg border">
      <div className="flex items-center space-x-4">
        <Skeleton variant="circular" className="h-12 w-12" />
        <div className="flex-1 space-y-2">
          <Skeleton className="h-4 w-32" />
          <Skeleton className="h-3 w-48" />
        </div>
      </div>
    </div>
  )
}

export function TableSkeleton({ rows = 5, columns = 4 }) {
  return (
    <div className="border rounded-lg">
      {/* Header */}
      <div className="border-b bg-gray-50 p-4">
        <div className="grid grid-cols-{columns} gap-4">
          {Array.from({ length: columns }).map((_, i) => (
            <Skeleton key={i} className="h-4" />
          ))}
        </div>
      </div>
      
      {/* Rows */}
      {Array.from({ length: rows }).map((_, rowIndex) => (
        <div key={rowIndex} className="border-b p-4 last:border-0">
          <div className="grid grid-cols-{columns} gap-4">
            {Array.from({ length: columns }).map((_, colIndex) => (
              <Skeleton 
                key={colIndex} 
                className={cn(
                  "h-4",
                  colIndex === 0 && "w-20", // Shorter first column
                  colIndex === columns - 1 && "w-16" // Shorter last column
                )}
              />
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}
```

### Progressive Loading Pattern

```javascript
// Load critical content first, then enhance
export function ProgressiveImage({ 
  src, 
  placeholder, 
  alt, 
  className 
}) {
  const [imageSrc, setImageSrc] = useState(placeholder)
  const [loading, setLoading] = useState(true)
  
  useEffect(() => {
    const img = new Image()
    img.src = src
    img.onload = () => {
      setImageSrc(src)
      setLoading(false)
    }
  }, [src])
  
  return (
    <div className={cn("relative overflow-hidden", className)}>
      <img
        src={imageSrc}
        alt={alt}
        className={cn(
          "w-full h-full object-cover transition-all duration-300",
          loading && "filter blur-sm scale-105"
        )}
      />
      {loading && (
        <div className="absolute inset-0 bg-gray-100 animate-pulse" />
      )}
    </div>
  )
}
```

## 🎭 Animation Patterns

### Framer Motion Patterns

Standard animation variants for consistency:

```javascript
// Shared animation variants
export const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -20 }
}

export const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
}

export const scaleIn = {
  initial: { scale: 0.9, opacity: 0 },
  animate: { scale: 1, opacity: 1 },
  exit: { scale: 0.9, opacity: 0 }
}

// List animation
export function AnimatedList({ items, renderItem }) {
  return (
    <motion.div
      variants={staggerContainer}
      initial="initial"
      animate="animate"
      className="space-y-2"
    >
      <AnimatePresence>
        {items.map((item, index) => (
          <motion.div
            key={item.id}
            variants={fadeInUp}
            layout
            transition={{ duration: 0.3 }}
          >
            {renderItem(item, index)}
          </motion.div>
        ))}
      </AnimatePresence>
    </motion.div>
  )
}

// Page transitions
export function PageTransition({ children }) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      transition={{ duration: 0.3 }}
    >
      {children}
    </motion.div>
  )
}
```

### Micro-interactions

```javascript
// Button with micro-interaction
export function InteractiveButton({ children, onClick, ...props }) {
  return (
    <motion.button
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={cn(
        "px-4 py-2 bg-primary-500 text-white rounded-lg",
        "transition-colors hover:bg-primary-600"
      )}
      {...props}
    >
      {children}
    </motion.button>
  )
}

// Success feedback animation
export function SuccessCheckmark({ show }) {
  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          exit={{ scale: 0, rotate: 180 }}
          transition={{ type: "spring", stiffness: 200 }}
          className="h-6 w-6 text-green-500"
        >
          <CheckIcon />
        </motion.div>
      )}
    </AnimatePresence>
  )
}
```

## 🔧 Complex State Patterns

### Multi-step Form Pattern

```javascript
export function useMultiStepForm(steps) {
  const [currentStep, setCurrentStep] = useState(0)
  const [formData, setFormData] = useState({})
  const [errors, setErrors] = useState({})
  
  const isFirstStep = currentStep === 0
  const isLastStep = currentStep === steps.length - 1
  const currentStepConfig = steps[currentStep]
  
  const next = async () => {
    // Validate current step
    if (currentStepConfig.validate) {
      const stepErrors = await currentStepConfig.validate(formData)
      if (Object.keys(stepErrors).length > 0) {
        setErrors(stepErrors)
        return false
      }
    }
    
    setErrors({})
    setCurrentStep(prev => Math.min(prev + 1, steps.length - 1))
    return true
  }
  
  const previous = () => {
    setCurrentStep(prev => Math.max(prev - 1, 0))
  }
  
  const goToStep = (step) => {
    setCurrentStep(Math.max(0, Math.min(step, steps.length - 1)))
  }
  
  const updateFormData = (data) => {
    setFormData(prev => ({ ...prev, ...data }))
  }
  
  const submit = async () => {
    if (!isLastStep) return
    
    // Final validation
    const allErrors = {}
    for (const step of steps) {
      if (step.validate) {
        const stepErrors = await step.validate(formData)
        Object.assign(allErrors, stepErrors)
      }
    }
    
    if (Object.keys(allErrors).length > 0) {
      setErrors(allErrors)
      return false
    }
    
    return true
  }
  
  return {
    currentStep,
    currentStepConfig,
    formData,
    errors,
    isFirstStep,
    isLastStep,
    next,
    previous,
    goToStep,
    updateFormData,
    submit,
    progress: ((currentStep + 1) / steps.length) * 100
  }
}

// Usage
const steps = [
  {
    id: 'personal',
    title: 'Personal Information',
    component: PersonalInfoStep,
    validate: (data) => {
      const errors = {}
      if (!data.firstName) errors.firstName = 'Required'
      if (!data.email) errors.email = 'Required'
      return errors
    }
  },
  {
    id: 'address',
    title: 'Address',
    component: AddressStep,
    validate: (data) => {
      const errors = {}
      if (!data.street) errors.street = 'Required'
      return errors
    }
  }
]

export function MultiStepFormExample() {
  const form = useMultiStepForm(steps)
  const CurrentStepComponent = form.currentStepConfig.component
  
  return (
    <div className="max-w-2xl mx-auto">
      {/* Progress bar */}
      <div className="mb-8">
        <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-primary-500"
            animate={{ width: `${form.progress}%` }}
            transition={{ duration: 0.3 }}
          />
        </div>
      </div>
      
      {/* Step indicator */}
      <div className="flex justify-between mb-8">
        {steps.map((step, index) => (
          <button
            key={step.id}
            onClick={() => form.goToStep(index)}
            className={cn(
              "flex items-center",
              index <= form.currentStep ? "text-primary-500" : "text-gray-400"
            )}
          >
            <div className={cn(
              "w-8 h-8 rounded-full flex items-center justify-center",
              "border-2 transition-colors",
              index <= form.currentStep 
                ? "border-primary-500 bg-primary-500 text-white" 
                : "border-gray-300"
            )}>
              {index + 1}
            </div>
            {index < steps.length - 1 && (
              <div className={cn(
                "w-full h-0.5 mx-2",
                index < form.currentStep ? "bg-primary-500" : "bg-gray-300"
              )} />
            )}
          </button>
        ))}
      </div>
      
      {/* Current step */}
      <AnimatePresence mode="wait">
        <motion.div
          key={form.currentStep}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
        >
          <CurrentStepComponent
            data={form.formData}
            errors={form.errors}
            onChange={form.updateFormData}
          />
        </motion.div>
      </AnimatePresence>
      
      {/* Navigation */}
      <div className="flex justify-between mt-8">
        <Button
          variant="outline"
          onClick={form.previous}
          disabled={form.isFirstStep}
        >
          Previous
        </Button>
        
        {form.isLastStep ? (
          <Button onClick={async () => {
            if (await form.submit()) {
              // Handle submission
            }
          }}>
            Submit
          </Button>
        ) : (
          <Button onClick={form.next}>
            Next
          </Button>
        )}
      </div>
    </div>
  )
}
```

### Undo/Redo Pattern

```javascript
export function useUndoRedo(initialState) {
  const [states, setStates] = useState([initialState])
  const [currentIndex, setCurrentIndex] = useState(0)
  
  const canUndo = currentIndex > 0
  const canRedo = currentIndex < states.length - 1
  const currentState = states[currentIndex]
  
  const setState = (newState) => {
    const newStates = states.slice(0, currentIndex + 1)
    newStates.push(newState)
    
    // Limit history to 50 states
    if (newStates.length > 50) {
      newStates.shift()
    } else {
      setCurrentIndex(currentIndex + 1)
    }
    
    setStates(newStates)
  }
  
  const undo = () => {
    if (canUndo) {
      setCurrentIndex(currentIndex - 1)
    }
  }
  
  const redo = () => {
    if (canRedo) {
      setCurrentIndex(currentIndex + 1)
    }
  }
  
  const reset = () => {
    setStates([initialState])
    setCurrentIndex(0)
  }
  
  return {
    state: currentState,
    setState,
    undo,
    redo,
    reset,
    canUndo,
    canRedo
  }
}
```

## 🔄 Context Patterns & Performance

### Context with Children Pattern

Prevents prop drilling and unnecessary re-renders:

```javascript
// ❌ Problem: Prop drilling causes all components to re-render
function Page() {
  const [isExpanded, setIsExpanded] = useState(true)
  return (
    <Layout isExpanded={isExpanded}> {/* Re-renders */}
      <Sidebar toggle={() => setIsExpanded(!isExpanded)} /> {/* Re-renders */}
      <MainContent isExpanded={isExpanded} /> {/* Re-renders */}
    </Layout>
  )
}

// ✅ Solution: Context + children pattern
const NavigationContext = createContext()

function NavigationProvider({ children }) {
  const [isExpanded, setIsExpanded] = useState(true)
  
  // CRITICAL: Always memoize to prevent re-renders when provider re-renders!
  const value = useMemo(() => ({
    isExpanded,
    toggle: () => setIsExpanded(prev => !prev)
  }), [isExpanded])
  
  return (
    <NavigationContext.Provider value={value}>
      {children}
    </NavigationContext.Provider>
  )
}

// Usage - Layout/Sidebar/MainContent are passed as children
// They won't re-render when NavigationProvider's state changes!
<NavigationProvider>
  <Layout>
    <Sidebar />
    <MainContent />
  </Layout>
</NavigationProvider>
```

### Split Context Pattern

Split state from API to minimize re-renders:

```javascript
// ❌ Problem: Components using only `open` still re-render when state changes
const Context = createContext()
function Provider({ children }) {
  const [isOpen, setIsOpen] = useState(false)
  const value = { 
    isOpen, 
    open: () => setIsOpen(true),  // Recreated every render!
    close: () => setIsOpen(false) // Recreated every render!
  }
}

// ✅ Solution: Split state and API
const StateContext = createContext()
const ApiContext = createContext()

function Provider({ children }) {
  const [state, setState] = useState()
  
  // State context - only consumers using state re-render
  const stateValue = useMemo(() => ({ state }), [state])
  
  // API context - functions never change, consumers never re-render!
  const apiValue = useMemo(() => ({
    updateState: (val) => setState(val),
    reset: () => setState(null)
  }), []) // Empty deps = created once
  
  return (
    <StateContext.Provider value={stateValue}>
      <ApiContext.Provider value={apiValue}>
        {children}
      </ApiContext.Provider>
    </StateContext.Provider>
  )
}

// Component only using API won't re-render on state change
function ActionButton() {
  const { updateState } = useContext(ApiContext) // No re-renders!
  return <button onClick={() => updateState('new')}>Update</button>
}
```

### useReducer Context Pattern

useReducer provides stable dispatch:

```javascript
// ❌ Problem: toggle depends on state
function Provider({ children }) {
  const [isOpen, setIsOpen] = useState(false)
  // This changes every render because it depends on isOpen!
  const toggle = useCallback(() => setIsOpen(!isOpen), [isOpen])
}

// ✅ Solution: useReducer with stable dispatch
function Provider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState)
  
  // dispatch never changes, so api is created once!
  const api = useMemo(() => ({
    open: () => dispatch({ type: 'OPEN' }),
    close: () => dispatch({ type: 'CLOSE' }),
    toggle: () => dispatch({ type: 'TOGGLE' }) // No state dependency!
  }), []) // Empty deps!
  
  const value = useMemo(() => ({ ...state, ...api }), [state, api])
  
  return <Context.Provider value={value}>{children}</Context.Provider>
}

const reducer = (state, action) => {
  switch (action.type) {
    case 'TOGGLE':
      return { ...state, isOpen: !state.isOpen } // Access state here
    // ... other cases
  }
}
```

### Context Selector HOC

Selective subscriptions when splitting isn't enough:

```javascript
// Problem: Heavy component needs one stable value but re-renders on any context change
function HeavyEditor() {
  const { save } = useContext(EditorContext) // Re-renders on any context change!
  return <ExpensiveComponent onSave={save} />
}

// Solution: HOC + memo prevents re-renders
function withEditorApi(Component) {
  // Memoize the component
  const MemoComponent = React.memo(Component)
  
  return function WithEditorApi(props) {
    // This wrapper re-renders on context change
    const { save, publish, draft } = useContext(EditorContext)
    
    // But MemoComponent only re-renders if props change
    // If save/publish/draft are stable (memoized in context), no re-render!
    return (
      <MemoComponent 
        {...props}
        onSave={save}
        onPublish={publish}
        onDraft={draft}
      />
    )
  }
}

// Usage - HeavyEditor won't re-render on unrelated context changes
const HeavyEditor = withEditorApi(({ onSave, content }) => {
  return <ExpensiveComponent onSave={onSave} content={content} />
})
```

### Context Best Practices

1. **Always memoize context values** - Prevents all consumers from re-rendering
2. **Split contexts by update frequency** - Separate values that change from those that don't
3. **Use useReducer for stable dispatch** - Functions in API don't depend on state
4. **Consider HOCs for selective subscriptions** - When splitting isn't enough
5. **Measure before optimizing** - Use React DevTools Profiler first

### When to Use Context vs Props

- **Context**: Many components at different levels, avoid 3+ prop drilling, cross-cutting concerns
- **Props**: Parent to child, simple relationships, clear component API

## 🎨 Theme & Styling Patterns

### Dynamic Theme Switching

Building on THEME-SYSTEM.md tokens:

```javascript
export function ThemeProvider({ children }) {
  const [theme, setTheme] = useState(() => {
    return localStorage.getItem('theme') || 'light'
  })
  
  const [primaryColor, setPrimaryColor] = useState(() => {
    return localStorage.getItem('primaryColor') || 'blue'
  })
  
  useEffect(() => {
    // Apply theme class to root
    document.documentElement.classList.remove('light', 'dark')
    document.documentElement.classList.add(theme)
    
    // Apply primary color CSS variables
    const root = document.documentElement
    const colors = THEME_COLORS[primaryColor]
    
    Object.entries(colors).forEach(([key, value]) => {
      root.style.setProperty(`--color-primary-${key}`, value)
    })
    
    // Save to localStorage
    localStorage.setItem('theme', theme)
    localStorage.setItem('primaryColor', primaryColor)
  }, [theme, primaryColor])
  
  const value = {
    theme,
    setTheme,
    primaryColor,
    setPrimaryColor,
    toggleTheme: () => setTheme(prev => prev === 'light' ? 'dark' : 'light')
  }
  
  return (
    <ThemeContext.Provider value={value}>
      {children}
    </ThemeContext.Provider>
  )
}
```

### Responsive Patterns

```javascript
// Responsive hook
export function useBreakpoint() {
  const [breakpoint, setBreakpoint] = useState('desktop')
  
  useEffect(() => {
    const checkBreakpoint = () => {
      const width = window.innerWidth
      if (width < 640) setBreakpoint('mobile')
      else if (width < 768) setBreakpoint('tablet')
      else if (width < 1024) setBreakpoint('laptop')
      else setBreakpoint('desktop')
    }
    
    checkBreakpoint()
    window.addEventListener('resize', checkBreakpoint)
    return () => window.removeEventListener('resize', checkBreakpoint)
  }, [])
  
  return {
    breakpoint,
    isMobile: breakpoint === 'mobile',
    isTablet: breakpoint === 'tablet',
    isLaptop: breakpoint === 'laptop',
    isDesktop: breakpoint === 'desktop',
    isMobileOrTablet: ['mobile', 'tablet'].includes(breakpoint)
  }
}

// Responsive component
export function ResponsiveGrid({ children, className }) {
  const { isMobileOrTablet } = useBreakpoint()
  
  return (
    <div className={cn(
      "grid gap-4",
      isMobileOrTablet ? "grid-cols-1" : "grid-cols-3",
      className
    )}>
      {children}
    </div>
  )
}
```


## 📋 Quick Reference

- **Compound Components**: Complex UI with shared state
- **Render Props**: Maximum flexibility needed
- **Memoization**: Props rarely change, comparison is cheap
- **Optimistic Updates**: Better UX for network operations
- **Virtual Scrolling**: Lists with 100+ items
- **Multi-step Forms**: 3+ related form sections

## 🔗 References

- For basic component structure and conventions, see **CODING-STANDARDS.md**
- For available UI components, see **COMPONENT-REGISTRY.md**
- For styling tokens and theme variables, see **THEME-SYSTEM.md**
- For data structures used in examples, see **MOCK-DATA-STRUCTURE.md**
- For state management rules, see **CODING-STANDARDS.md#state-management**

## 📝 Summary

This document provides advanced patterns that complement the basic structures defined in CODING-STANDARDS.md. Use these patterns to build sophisticated, accessible, and performant UI components while maintaining consistency across the codebase.