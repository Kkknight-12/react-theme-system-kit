# Complete shadcn Variable Mapping for Tailwind v4

## All shadcn Variables Required

Based on the shadcn theme system, here are ALL the variables that need to be mapped:

### Core Variables
- `--radius` - Border radius base value
- `--background` - Main page background
- `--foreground` - Main text color
- `--card` - Card background
- `--card-foreground` - Card text color
- `--popover` - Popover/dropdown background
- `--popover-foreground` - Popover text color
- `--primary` - Primary brand color
- `--primary-foreground` - Text on primary
- `--secondary` - Secondary color (we make this vibrant!)
- `--secondary-foreground` - Text on secondary
- `--muted` - Muted/subtle backgrounds
- `--muted-foreground` - Text on muted
- `--accent` - Accent color
- `--accent-foreground` - Text on accent
- `--destructive` - Error/danger color
- `--destructive-foreground` - Text on destructive
- `--border` - Default border color
- `--input` - Input background color
- `--ring` - Focus ring color

### Chart Variables
- `--chart-1` through `--chart-5` - Chart color palette

### Sidebar Variables
- `--sidebar` - Sidebar background
- `--sidebar-foreground` - Sidebar text
- `--sidebar-primary` - Sidebar primary color
- `--sidebar-primary-foreground` - Text on sidebar primary
- `--sidebar-accent` - Sidebar accent color
- `--sidebar-accent-foreground` - Text on sidebar accent
- `--sidebar-border` - Sidebar border color
- `--sidebar-ring` - Sidebar focus ring

## Complete Mapping Implementation

```css
/* In your index.css or theme CSS file */

@theme {
  /* Define all color scales in Tailwind v4 */
  --color-primary-50: oklch(0.98 0.04 166);
  --color-primary-100: oklch(0.96 0.08 166);
  --color-primary-200: oklch(0.91 0.14 166);
  --color-primary-300: oklch(0.84 0.20 166);
  --color-primary-400: oklch(0.74 0.22 166);
  --color-primary-500: oklch(0.64 0.20 166);
  --color-primary-600: oklch(0.54 0.18 166);
  --color-primary-700: oklch(0.44 0.14 166);
  --color-primary-800: oklch(0.36 0.11 166);
  --color-primary-900: oklch(0.30 0.09 166);
  --color-primary-950: oklch(0.20 0.08 166);
  
  /* Secondary - Vibrant theme color (not neutral!) */
  --color-secondary-50: /* Theme specific */;
  --color-secondary-100: /* Theme specific */;
  --color-secondary-200: /* Theme specific */;
  --color-secondary-300: /* Theme specific */;
  --color-secondary-400: /* Theme specific */;
  --color-secondary-500: /* Theme specific */;
  --color-secondary-600: /* Theme specific */;
  --color-secondary-700: /* Theme specific */;
  --color-secondary-800: /* Theme specific */;
  --color-secondary-900: /* Theme specific */;
  --color-secondary-950: /* Theme specific */;
  
  /* Accent - Another vibrant color */
  --color-accent-50: /* Theme specific */;
  --color-accent-100: /* Theme specific */;
  --color-accent-200: /* Theme specific */;
  --color-accent-300: /* Theme specific */;
  --color-accent-400: /* Theme specific */;
  --color-accent-500: /* Theme specific */;
  --color-accent-600: /* Theme specific */;
  --color-accent-700: /* Theme specific */;
  --color-accent-800: /* Theme specific */;
  --color-accent-900: /* Theme specific */;
  --color-accent-950: /* Theme specific */;
  
  /* Neutral scale for backgrounds/borders */
  --color-neutral-50: oklch(0.985 0 0);
  --color-neutral-100: oklch(0.967 0.001 286);
  --color-neutral-200: oklch(0.92 0.004 286);
  --color-neutral-300: oklch(0.871 0.006 286);
  --color-neutral-400: oklch(0.705 0.015 286);
  --color-neutral-500: oklch(0.552 0.016 286);
  --color-neutral-600: oklch(0.442 0.017 286);
  --color-neutral-700: oklch(0.37 0.013 286);
  --color-neutral-800: oklch(0.274 0.006 286);
  --color-neutral-900: oklch(0.21 0.006 286);
  --color-neutral-950: oklch(0.141 0.005 286);
  
  /* Semantic colors */
  --color-destructive: oklch(0.577 0.245 27.325);
  --color-destructive-foreground: oklch(0.985 0 0);
}

/* Map ALL shadcn variables */
:root {
  /* Core radius */
  --radius: 0.65rem;
  
  /* Backgrounds & Foregrounds */
  --background: oklch(1 0 0);
  --foreground: var(--color-neutral-950);
  --card: oklch(1 0 0);
  --card-foreground: var(--color-neutral-950);
  --popover: oklch(1 0 0);
  --popover-foreground: var(--color-neutral-950);
  
  /* Primary colors */
  --primary: var(--color-primary-500);
  --primary-foreground: oklch(0.985 0 0);
  
  /* Secondary - Our vibrant approach! */
  --secondary: var(--color-secondary-500);
  --secondary-foreground: oklch(0.985 0 0);
  
  /* Muted - True neutral */
  --muted: var(--color-neutral-100);
  --muted-foreground: var(--color-neutral-500);
  
  /* Accent - Can be different from primary */
  --accent: var(--color-accent-500, var(--color-primary-500));
  --accent-foreground: oklch(0.985 0 0);
  
  /* Destructive/Error */
  --destructive: var(--color-destructive);
  --destructive-foreground: var(--color-destructive-foreground);
  
  /* Borders & Inputs */
  --border: var(--color-neutral-200);
  --input: var(--color-neutral-200);
  --ring: var(--color-primary-500);
  
  /* Chart colors - can be customized per theme */
  --chart-1: var(--color-primary-600);
  --chart-2: var(--color-secondary-600);
  --chart-3: var(--color-accent-600);
  --chart-4: var(--color-primary-400);
  --chart-5: var(--color-secondary-400);
  
  /* Sidebar - inherits from main theme */
  --sidebar: oklch(0.985 0 0);
  --sidebar-foreground: var(--color-neutral-950);
  --sidebar-primary: var(--color-primary-500);
  --sidebar-primary-foreground: oklch(0.985 0 0);
  --sidebar-accent: var(--color-neutral-100);
  --sidebar-accent-foreground: var(--color-neutral-900);
  --sidebar-border: var(--color-neutral-200);
  --sidebar-ring: var(--color-primary-500);
}

/* Dark mode - ALL variables need dark equivalents */
.dark {
  /* Backgrounds & Foregrounds */
  --background: var(--color-neutral-950);
  --foreground: oklch(0.985 0 0);
  --card: var(--color-neutral-900);
  --card-foreground: oklch(0.985 0 0);
  --popover: var(--color-neutral-900);
  --popover-foreground: oklch(0.985 0 0);
  
  /* Primary colors */
  --primary: var(--color-primary-500);
  --primary-foreground: oklch(0.985 0 0);
  
  /* Secondary - Still vibrant in dark mode */
  --secondary: var(--color-secondary-500);
  --secondary-foreground: oklch(0.985 0 0);
  
  /* Muted - Darker neutral */
  --muted: var(--color-neutral-800);
  --muted-foreground: var(--color-neutral-400);
  
  /* Accent */
  --accent: var(--color-accent-500, var(--color-primary-500));
  --accent-foreground: oklch(0.985 0 0);
  
  /* Destructive/Error */
  --destructive: oklch(0.704 0.191 22.216);
  --destructive-foreground: oklch(0.985 0 0);
  
  /* Borders & Inputs - Transparent for better dark mode */
  --border: oklch(1 0 0 / 10%);
  --input: oklch(1 0 0 / 15%);
  --ring: var(--color-primary-500);
  
  /* Chart colors - adjusted for dark mode */
  --chart-1: var(--color-primary-400);
  --chart-2: var(--color-secondary-400);
  --chart-3: var(--color-accent-400);
  --chart-4: var(--color-primary-300);
  --chart-5: var(--color-secondary-300);
  
  /* Sidebar dark mode */
  --sidebar: var(--color-neutral-900);
  --sidebar-foreground: oklch(0.985 0 0);
  --sidebar-primary: var(--color-primary-500);
  --sidebar-primary-foreground: oklch(0.985 0 0);
  --sidebar-accent: var(--color-neutral-800);
  --sidebar-accent-foreground: oklch(0.985 0 0);
  --sidebar-border: oklch(1 0 0 / 10%);
  --sidebar-ring: var(--color-primary-500);
}
```

## Purple Theme Example with ALL Variables

```css
/* Purple theme with complete variable set */
:root {
  --radius: 0.65rem;
  
  /* Main UI */
  --background: oklch(1 0 0);
  --foreground: oklch(0.141 0.005 285.823);
  --card: oklch(1 0 0);
  --card-foreground: oklch(0.141 0.005 285.823);
  --popover: oklch(1 0 0);
  --popover-foreground: oklch(0.141 0.005 285.823);
  
  /* Purple primary */
  --primary: oklch(0.627 0.265 303);
  --primary-foreground: oklch(0.985 0 0);
  
  /* Yellow secondary (triadic) */
  --secondary: oklch(0.795 0.184 86);
  --secondary-foreground: oklch(0.141 0.005 285.823);
  
  /* Neutral muted */
  --muted: oklch(0.967 0.001 286.375);
  --muted-foreground: oklch(0.552 0.016 285.938);
  
  /* Rose accent */
  --accent: oklch(0.645 0.246 16);
  --accent-foreground: oklch(0.985 0 0);
  
  /* Semantic */
  --destructive: oklch(0.577 0.245 27.325);
  --destructive-foreground: oklch(0.985 0 0);
  
  /* UI elements */
  --border: oklch(0.92 0.004 286.32);
  --input: oklch(0.92 0.004 286.32);
  --ring: oklch(0.627 0.265 303);
  
  /* Charts - using theme colors */
  --chart-1: oklch(0.558 0.288 302); /* purple-600 */
  --chart-2: oklch(0.681 0.162 75);  /* yellow-600 */
  --chart-3: oklch(0.586 0.253 17);  /* rose-600 */
  --chart-4: oklch(0.714 0.203 305); /* purple-400 */
  --chart-5: oklch(0.852 0.199 91);  /* yellow-400 */
  
  /* Sidebar */
  --sidebar: oklch(0.985 0 0);
  --sidebar-foreground: oklch(0.141 0.005 285.823);
  --sidebar-primary: oklch(0.627 0.265 303);
  --sidebar-primary-foreground: oklch(0.985 0 0);
  --sidebar-accent: oklch(0.967 0.001 286.375);
  --sidebar-accent-foreground: oklch(0.21 0.006 285.885);
  --sidebar-border: oklch(0.92 0.004 286.32);
  --sidebar-ring: oklch(0.627 0.265 303);
}

.dark {
  /* Dark mode with ALL variables */
  --background: oklch(0.141 0.005 285.823);
  --foreground: oklch(0.985 0 0);
  --card: oklch(0.21 0.006 285.885);
  --card-foreground: oklch(0.985 0 0);
  --popover: oklch(0.21 0.006 285.885);
  --popover-foreground: oklch(0.985 0 0);
  
  /* Colors stay vibrant */
  --primary: oklch(0.627 0.265 303);
  --primary-foreground: oklch(0.985 0 0);
  --secondary: oklch(0.795 0.184 86);
  --secondary-foreground: oklch(0.985 0 0);
  --muted: oklch(0.274 0.006 286.033);
  --muted-foreground: oklch(0.705 0.015 286.067);
  --accent: oklch(0.645 0.246 16);
  --accent-foreground: oklch(0.985 0 0);
  
  /* Semantic */
  --destructive: oklch(0.704 0.191 22.216);
  --destructive-foreground: oklch(0.985 0 0);
  
  /* Transparent borders */
  --border: oklch(1 0 0 / 10%);
  --input: oklch(1 0 0 / 15%);
  --ring: oklch(0.627 0.265 303);
  
  /* Adjusted chart colors */
  --chart-1: oklch(0.714 0.203 305); /* purple-400 */
  --chart-2: oklch(0.852 0.199 91);  /* yellow-400 */
  --chart-3: oklch(0.712 0.194 13);  /* rose-400 */
  --chart-4: oklch(0.827 0.119 306); /* purple-300 */
  --chart-5: oklch(0.905 0.182 98);  /* yellow-300 */
  
  /* Dark sidebar */
  --sidebar: oklch(0.21 0.006 285.885);
  --sidebar-foreground: oklch(0.985 0 0);
  --sidebar-primary: oklch(0.627 0.265 303);
  --sidebar-primary-foreground: oklch(0.985 0 0);
  --sidebar-accent: oklch(0.274 0.006 286.033);
  --sidebar-accent-foreground: oklch(0.985 0 0);
  --sidebar-border: oklch(1 0 0 / 10%);
  --sidebar-ring: oklch(0.627 0.265 303);
}
```

## Checklist: All shadcn Variables

- [x] `--radius` - Border radius
- [x] `--background` - Page background
- [x] `--foreground` - Main text
- [x] `--card` - Card background
- [x] `--card-foreground` - Card text
- [x] `--popover` - Popover background
- [x] `--popover-foreground` - Popover text
- [x] `--primary` - Primary color
- [x] `--primary-foreground` - Primary text
- [x] `--secondary` - Secondary color (VIBRANT!)
- [x] `--secondary-foreground` - Secondary text
- [x] `--muted` - Muted background
- [x] `--muted-foreground` - Muted text
- [x] `--accent` - Accent color
- [x] `--accent-foreground` - Accent text
- [x] `--destructive` - Error color
- [x] `--destructive-foreground` - Error text (missing in some themes!)
- [x] `--border` - Border color
- [x] `--input` - Input background
- [x] `--ring` - Focus ring
- [x] `--chart-1` through `--chart-5` - Chart colors
- [x] `--sidebar` - Sidebar background
- [x] `--sidebar-foreground` - Sidebar text
- [x] `--sidebar-primary` - Sidebar primary
- [x] `--sidebar-primary-foreground` - Sidebar primary text
- [x] `--sidebar-accent` - Sidebar accent
- [x] `--sidebar-accent-foreground` - Sidebar accent text
- [x] `--sidebar-border` - Sidebar border
- [x] `--sidebar-ring` - Sidebar focus ring

## Notes on Our Implementation

1. **Secondary is Vibrant**: Unlike default shadcn, our `--secondary` maps to vibrant theme colors
2. **Chart Colors**: We map these to theme colors rather than random values
3. **Sidebar Consistency**: Sidebar colors inherit from main theme for consistency
4. **Dark Mode Borders**: We use transparent white for borders in dark mode
5. **Missing Variables**: Some shadcn themes forget `--destructive-foreground` - always include it!