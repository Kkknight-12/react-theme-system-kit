# Component Patterns Index

**Project**: Modern Admin Dashboard Template  
**Purpose**: Advanced component patterns and composition strategies  
**Last Updated**: 2025-01-14

## 🔗 Related Documents

- **CODING-STANDARDS.md** - Basic component structure, props handling, state management
- **THEME-SYSTEM.md** - Design tokens and theming patterns
- **MOCK-DATA-STRUCTURE.md** - Data structures for component examples
- **COMPONENT-REGISTRY.md** - Available components reference

## 🎯 Overview

This index provides access to advanced component patterns organized by category. Each pattern file focuses on specific techniques for building sophisticated, accessible, and performant UI components.

> **Note**: The original COMPONENT-PATTERNS.md file has been split into focused category files for better organization and maintainability. The original file is preserved for reference.

## 📚 Pattern Categories

### 1. [Composition Patterns](patterns/composition-patterns.md)
- Render Props Pattern
- Compound Components with Context
- Custom Hooks vs HOCs
- HOC Use Cases and Best Practices

### 2. [Performance Patterns](patterns/performance-patterns.md)
- Memoization Fundamentals
- React.memo Rules and Guidelines
- Elements vs Components Performance
- Children as Props for Performance
- Escaping Stale Closures

### 3. [Configuration Patterns](patterns/configuration-patterns.md)
- Elements as Props for Flexibility
- Modal with Flexible Sections
- Default Props with cloneElement
- Render Props for Complex Interactions

### 4. [Ref Patterns](patterns/ref-patterns.md)
- DOM Element Access
- forwardRef Pattern
- Imperative APIs with useImperativeHandle
- When to Use Refs vs State
- Debouncing & Throttling Patterns

### 5. [UI Component Patterns](patterns/ui-component-patterns.md)
- Modal/Dialog Pattern with Accessibility
- Advanced Table Pattern
- List with Filters Pattern

### 6. [Data Fetching Patterns](patterns/data-fetching-patterns.md)
- Page-Level Data Fetching
- Optimistic Updates Pattern
- Infinite Scroll Pattern

### 7. [Loading & Animation Patterns](patterns/loading-animation-patterns.md)
- Skeleton Components
- Progressive Loading Pattern
- Framer Motion Patterns
- Micro-interactions

### 8. [State Management Patterns](patterns/state-management-patterns.md)
- Multi-step Form Pattern
- Undo/Redo Pattern
- Complex State Handling

### 9. [Context Patterns](patterns/context-patterns.md)
- Context with Children Pattern
- Split Context Pattern
- useReducer Context Pattern
- Context Performance Optimization

### 10. [Theme & Styling Patterns](patterns/theme-styling-patterns.md)
- Dynamic Theme Switching
- Responsive Patterns
- CSS-in-JS Patterns

## 📋 Quick Reference

### By Use Case

**Performance Optimization**
- Memoization: [Performance Patterns](patterns/performance-patterns.md#memoization-fundamentals)
- Preventing Re-renders: [Performance Patterns](patterns/performance-patterns.md#children-as-props-for-performance)
- Stable Callbacks: [Ref Patterns](patterns/ref-patterns.md#escaping-stale-closures)

**Form Handling**
- Multi-step Forms: [State Management](patterns/state-management-patterns.md#multi-step-form-pattern)
- Auto-save: [Ref Patterns](patterns/ref-patterns.md#auto-save-pattern)
- Debounced Inputs: [Ref Patterns](patterns/ref-patterns.md#debouncing-throttling-patterns)

**Component Composition**
- Flexible APIs: [Composition Patterns](patterns/composition-patterns.md#render-props-pattern)
- Compound Components: [Composition Patterns](patterns/composition-patterns.md#compound-components-with-context)
- Prop Forwarding: [Ref Patterns](patterns/ref-patterns.md#forwardref-pattern)

**Data Management**
- Fetching Strategies: [Data Fetching Patterns](patterns/data-fetching-patterns.md)
- Optimistic Updates: [Data Fetching Patterns](patterns/data-fetching-patterns.md#optimistic-updates-pattern)
- Infinite Lists: [Data Fetching Patterns](patterns/data-fetching-patterns.md#infinite-scroll-pattern)

## 🔍 How to Use These Patterns

1. **Start with CODING-STANDARDS.md** for basic React patterns and conventions
2. **Reference specific pattern files** when implementing advanced features
3. **Combine patterns** as needed - they're designed to work together
4. **Measure performance** before applying optimization patterns
5. **Keep accessibility in mind** - many patterns include a11y considerations

## 📝 Contributing

When adding new patterns:
1. Determine the appropriate category file
2. Follow the existing format and structure
3. Include practical examples with comments
4. Add any new patterns to this index
5. Update the quick reference if applicable

## 🔗 Additional Resources

- React Documentation: [react.dev](https://react.dev)
- React TypeScript Cheatsheet: [react-typescript-cheatsheet.netlify.app](https://react-typescript-cheatsheet.netlify.app/)
- Web Accessibility Guidelines: [w3.org/WAI/WCAG21/quickref](https://www.w3.org/WAI/WCAG21/quickref/)