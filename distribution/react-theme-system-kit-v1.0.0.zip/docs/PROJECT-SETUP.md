# Project Setup Guide

**Project**: Modern Admin Dashboard Template  
**Framework**: Vite + React  
**Language**: JavaScript  
**Package Manager**: pnpm  
**UI Framework**: Tailwind CSS + shadcn/ui

## Tech Stack

### Core
- **Vite** - Build tool for faster development
- **React 18** - UI library
- **JavaScript** - Programming language (no TypeScript)
- **React Router v6** - Routing and navigation
- **Redux Toolkit** - State management

### Styling & UI
- **Tailwind CSS** - Utility-first CSS framework
- **shadcn/ui** - Component library built on Radix UI
- **Radix UI** - Unstyled, accessible component primitives
- **Framer Motion** - Animation library
- **Lucide React** - Icon library (or @iconify/react)

### Forms & Validation
- **React Hook Form** - Performant forms with easy validation
- **Yup** - Schema validation

### Data & Tables
- **@tanstack/react-table** - Powerful table component
- **@tanstack/react-query** - Data fetching and caching

### Additional Libraries (from template analysis)
- **react-apexcharts** - Charts and data visualization
- **react-dropzone** - File upload
- **notistack** - Snackbar notifications
- **date-fns** - Date utilities
- **axios** - HTTP client

## Project Structure

```
project-root/
├── public/
│   ├── fonts/
│   ├── images/
│   └── favicon.ico
├── src/
│   ├── components/
│   │   ├── ui/           # Base UI components
│   │   ├── forms/        # Form-specific components
│   │   ├── charts/       # Chart components
│   │   └── layouts/      # Layout components
│   ├── pages/
│   │   ├── auth/
│   │   ├── dashboard/
│   │   ├── ecommerce/
│   │   └── errors/
│   ├── hooks/
│   │   ├── useAuth.js
│   │   ├── useTable.js
│   │   └── useTheme.js
│   ├── utils/
│   │   ├── format.js
│   │   ├── validation.js
│   │   └── mock.js
│   ├── store/            # Redux store
│   │   ├── slices/
│   │   └── index.js
│   ├── styles/
│   │   └── globals.css
│   ├── App.jsx
│   └── main.jsx
├── .env
├── .env.example
├── .gitignore
├── index.html
├── package.json
├── pnpm-lock.yaml
├── postcss.config.js
├── tailwind.config.js
├── vite.config.js
└── README.md
```

## Installation Steps

### 1. Create Project
```bash
pnpm create vite@latest admin-dashboard --template react
cd admin-dashboard
```

### 2. Install Core Dependencies
```bash
# Core
pnpm add react-router-dom @reduxjs/toolkit react-redux

# UI & Styling
pnpm add -D tailwindcss postcss autoprefixer
pnpm add class-variance-authority clsx tailwind-merge
pnpm add @radix-ui/react-dialog @radix-ui/react-dropdown-menu @radix-ui/react-select
pnpm add framer-motion lucide-react

# Forms & Validation
pnpm add react-hook-form yup @hookform/resolvers

# Data & Tables
pnpm add @tanstack/react-table @tanstack/react-query

# Additional
pnpm add axios date-fns
```

### 3. Setup Tailwind CSS
```bash
npx tailwindcss init -p
```

Update `tailwind.config.js`:
```javascript
/** @type {import('tailwindcss').Config} */
export default {
  darkMode: ["class"],
  content: [
    "./index.html",
    "./src/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      colors: {
        // Will be defined in THEME-SYSTEM.md
      },
    },
  },
  plugins: [],
}
```

Add to `src/styles/globals.css`:
```css
@tailwind base;
@tailwind components;
@tailwind utilities;

/* Custom CSS variables from THEME-SYSTEM.md */
```

### 4. Setup shadcn/ui
Since shadcn/ui doesn't have a direct Vite setup, we'll manually configure:

1. Create `jsconfig.json`:
```json
{
  "compilerOptions": {
    "baseUrl": ".",
    "paths": {
      "@/*": ["./src/*"]
    }
  }
}
```

2. Update `vite.config.js`:
```javascript
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
})
```

3. Create `src/lib/utils.js`:
```javascript
import { clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs) {
  return twMerge(clsx(inputs))
}
```

### 5. Environment Variables
Create `.env`:
```env
VITE_APP_NAME=Admin Dashboard
VITE_API_URL=http://localhost:3000/api
VITE_APP_VERSION=1.0.0
```

## Development Workflow

### Start Development Server
```bash
pnpm dev
```

### Build for Production
```bash
pnpm build
pnpm preview  # Preview production build
```

### Code Quality
```bash
# Add ESLint and Prettier
pnpm add -D eslint eslint-plugin-react eslint-plugin-react-hooks prettier

# Format code
pnpm format

# Lint code
pnpm lint
```

## Component Development Order

1. **Utils** (`src/utils/`) - Build first
2. **Base Components** (`src/components/ui/`) - Build second
3. **Layout Components** (`src/components/layouts/`) - Build third
4. **Page Components** (`src/pages/`) - Build last

## State Management Setup

### Redux Store (`src/store/index.js`)
```javascript
import { configureStore } from '@reduxjs/toolkit'
// Import slices here

export const store = configureStore({
  reducer: {
    // Add reducers here
  },
})
```

### Provider Setup (`src/main.jsx`)
```javascript
import React from 'react'
import ReactDOM from 'react-dom/client'
import { Provider } from 'react-redux'
import { BrowserRouter } from 'react-router-dom'
import { store } from './store'
import App from './App'
import './styles/globals.css'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Provider store={store}>
      <BrowserRouter>
        <App />
      </BrowserRouter>
    </Provider>
  </React.StrictMode>
)
```

## Notes

- We're using Radix UI through shadcn/ui for accessibility
- Framer Motion for smooth animations
- Redux Toolkit for complex state management
- React Hook Form for optimal form performance
- Tailwind CSS with custom theme system
- No TypeScript to keep development fast

**Next Steps**: Create CODING-STANDARDS.md to define how to write consistent code