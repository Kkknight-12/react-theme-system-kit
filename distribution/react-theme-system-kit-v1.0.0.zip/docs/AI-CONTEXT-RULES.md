# AI Context Rules

**Project**: Modern Admin Dashboard Template  
**Purpose**: Ensure consistent AI-assisted development across sessions  
**Last Updated**: 2025-01-14

## 🎯 Core Principle

AI must maintain consistency across sessions by following these rules strictly. These rules override any default AI behavior and ensure high-quality, maintainable code.

## 📚 Document Reading Order

**MANDATORY**: Read these documents in order before creating ANY component:

1. **COMPONENT-REGISTRY.md** - Know what components already exist
2. **UTILS-REGISTRY.md** - Know available utility functions
3. **THEME-SYSTEM.md** - Understand design tokens and color system
4. **CODING-STANDARDS.md** - Follow code conventions and patterns
5. **BUILD-ORDER-DIAGRAM.md** - Understand component dependencies
6. **PROJECT-SETUP.md** - Know technical stack and setup
7. **AI-LARGE-PROJECT-STRATEGY.md** - Understand AI workflow best practices

**Rule**: Only rely on memory AFTER reading all documents and understanding the project flow.

## 🔨 Component Creation Workflow

### 1. Pre-Creation Checks

Before creating any component:
- ✅ Check COMPONENT-REGISTRY.md - does it already exist?
- ✅ Check BUILD-ORDER-DIAGRAM.md - are dependencies built?
- ✅ Check THEME-SYSTEM.md - are needed tokens defined?

### 2. Component Dependencies

If a component needs another component that doesn't exist:
1. **STOP** - Don't proceed with current component
2. **CHECK** - Verify build order in BUILD-ORDER-DIAGRAM.md
3. **BUILD** - Create the dependency first
4. **CONTINUE** - Then create the original component

Example:
```
Building Card → Needs Button → Button doesn't exist
✅ Stop Card creation
✅ Build Button first
✅ Update registry
✅ Resume Card creation
```

### 3. Creation Process

1. **If component exists in registry**: Use the specified props and patterns
2. **If component doesn't exist**: 
   - STOP and ask user
   - After discussion, create following established patterns
   - Always check dependencies first

### 4. Post-Creation Updates

**ALWAYS** update COMPONENT-REGISTRY.md after creating a component:

Format:
```markdown
| ComponentName | Category | Description | Props | Implementation Notes |
| Button | Base UI | Interactive button element | variant, size, onClick, disabled, loading | Uses cn() utility, supports all theme colors |
```

## 📝 Registry Management

### Component Registry Updates
- Update immediately after component creation
- Include ALL props (not just main ones)
- Add implementation notes for special features
- Follow the 5-column format shown above

### Utility Registry Updates
- Add new utilities when used in **more than 5 components**
- Document parameters and return values
- Include usage examples
- Note any dependencies

## ❌ Error Handling Rules

### Missing Theme Tokens
1. **STOP** current work
2. **CREATE** the missing tokens in THEME-SYSTEM.md
3. **UPDATE** any related documentation
4. **CONTINUE** with component creation

### Missing Utility Functions
1. **STOP** component creation
2. **CREATE** the utility function following patterns in UTILS-REGISTRY.md
3. **UPDATE** UTILS-REGISTRY.md with new utility
4. **CONTINUE** with component

### Non-Existent Import Paths
1. **CREATE** the file/component first
2. **THEN** add the import
3. **NEVER** import non-existent files

## 💻 Code Generation Rules

### Import Management
```javascript
// ✅ GOOD: Only import existing files
import Button from '@/components/ui/Button'
import { formatDate } from '@/utils/format'

// TODO: Import when created
// import Card from '@/components/ui/Card'  // Need to create this component
// import { validateEmail } from '@/utils/validation'  // Need to create this utility
```

### Mock Data Handling
- **Location**: Create in `utils/mock-data/` folder
- **Structure**: Separate files by entity (users.js, products.js, orders.js)
- **Reusability**: Design for use across multiple components
- **Format**: Export as functions that return data

Example:
```javascript
// utils/mock-data/users.js
export function generateMockUsers(count = 10) {
  return Array.from({ length: count }, (_, i) => ({
    id: i + 1,
    name: `User ${i + 1}`,
    email: `user${i + 1}@example.com`,
    // ... other fields
  }))
}
```

### Component Structure Decisions
Create separate files when:
- Component exceeds **150 lines**
- Has **3+ internal sub-components**
- Needs its own styles file
- Will be reused across multiple pages

Keep in single file when:
- Simple component under 150 lines
- 1-2 internal components
- Page-specific with no reuse

## 🗄️ State Management Rules

### When to Use Redux
Use Redux for:
- User authentication state
- Shopping cart data
- Cross-page notifications
- Global app settings
- Data that multiple pages need

### When to Use Local State
Use local state for:
- Form input values
- UI toggles (modals, dropdowns)
- Temporary filters
- Component-specific loading states
- Data used in only one component

### Redux Structure
```
store/
  slices/
    userSlice.js      # User authentication
    cartSlice.js      # Shopping cart
    productSlice.js   # Product catalog
    uiSlice.js        # Global UI state
```

### API Calls
- **Location**: `services/` folder
- **Method**: Use Redux Toolkit's `createAsyncThunk`
- **Naming**: `serviceNameApi.js` (e.g., `userApi.js`)

## 📁 File Organization Rules

### Folder Creation
Create new folders when:
- You have **3+ related components**
- Components share common functionality
- Logical grouping improves organization

### File Naming (Not in Registries)
- Use **kebab-case** for all files
- Match the file name to its purpose
- Examples:
  - `user-profile-header.jsx`
  - `format-currency.js`
  - `mock-dashboard-data.js`

### Page-Specific Components
Structure:
```
pages/
  dashboard/
    components/
      DashboardHeader.jsx
      MetricsCard.jsx
      RecentActivity.jsx
    index.jsx
```

## 🚨 Critical Rules Summary

1. **ALWAYS** read registries before creating anything
2. **NEVER** import files that don't exist (use TODO comments)
3. **ALWAYS** update registries after creation
4. **STOP** and create dependencies first
5. **CREATE** missing tokens/utilities before using them
6. **FOLLOW** the build order strictly
7. **ASK** before creating components not in registry

## 🔄 Workflow Example

Creating a UserCard component:

1. **Read** COMPONENT-REGISTRY.md → Not found
2. **Ask** user about creating UserCard
3. **Check** BUILD-ORDER-DIAGRAM.md → Needs Card, Avatar
4. **Verify** Card exists → Yes, Avatar exists → No
5. **Create** Avatar first → Update registry
6. **Create** UserCard → Update registry
7. **Test** with theme tokens → All good
8. **Complete** ✅

## 📋 Pre-Component Checklist

Before writing any component code:
- [ ] Read all 7 core documents
- [ ] Verify component doesn't exist
- [ ] Check all dependencies exist
- [ ] Confirm theme tokens available
- [ ] Understand the component's purpose
- [ ] Know which utilities to use

Following these rules ensures consistent, high-quality development across all AI sessions.