# AI-Assisted Large Project Development Strategy

## The Memory Problem & Solution

AI has ~200K token context, but a large project can be millions of tokens. Here's how to work around this:

## 1. Project Structure for AI Development

### The "Reference First" Architecture
```
project/
├── AI-CONTEXT/                    # Always give this to AI first
│   ├── PROJECT-STATE.md          # Current status, what's built
│   ├── COMPONENT-REGISTRY.md     # List of all components with examples
│   ├── UTILS-REGISTRY.md         # All utility functions
│   ├── THEME-SYSTEM.md           # Colors, spacing, patterns
│   └── CODING-STANDARDS.md       # Rules AI must follow
├── components/
│   ├── ui/                       # Base components
│   └── features/                 # Feature components
└── pages/                        # Actual pages

```

## 2. The Component Registry System

### COMPONENT-REGISTRY.md
```markdown
# Component Registry - ALWAYS USE THESE FIRST

## Base Components

### Button
Location: `components/ui/Button.tsx`
Import: `import { Button } from '@/components/ui/Button'`
Variants: primary, secondary, outline, ghost, danger
Sizes: sm, md, lg

Example:
\```tsx
<Button variant="primary" size="md">Click me</Button>
<Button variant="outline" size="sm" loading>Loading...</Button>
\```

### Card
Location: `components/ui/Card.tsx`
Import: `import { Card } from '@/components/ui/Card'`

Example:
\```tsx
<Card>
  <Card.Header>
    <Card.Title>Title</Card.Title>
  </Card.Header>
  <Card.Body>Content</Card.Body>
  <Card.Footer>Footer</Card.Footer>
</Card>
\```

### DataTable
Location: `components/ui/DataTable.tsx`
Import: `import { DataTable } from '@/components/ui/DataTable'`

Example:
\```tsx
<DataTable 
  data={users} 
  columns={columns}
  searchable
  sortable
  paginated
/>
\```

### Form Components
Location: `components/ui/form/`
- Input: `import { Input } from '@/components/ui/form/Input'`
- Select: `import { Select } from '@/components/ui/form/Select'`
- Checkbox: `import { Checkbox } from '@/components/ui/form/Checkbox'`

[... continue for all components]
```

### UTILS-REGISTRY.md
```markdown
# Utility Functions - ALWAYS USE THESE

## Formatting
Location: `utils/format.ts`

### formatCurrency(amount: number): string
\```ts
formatCurrency(1234.56) // "$1,234.56"
\```

### formatDate(date: Date | string): string
\```ts
formatDate(new Date()) // "Jan 15, 2024"
\```

## Data Helpers
Location: `utils/data.ts`

### generateMockData(type: string, count: number)
\```ts
const users = generateMockData('user', 10)
const products = generateMockData('product', 20)
\```

[... continue for all utils]
```

## 3. The Modular Prompt System

### Prompt Template for New Features
```markdown
I need to create a [FEATURE NAME] page.

CONTEXT FILES TO READ FIRST:
1. AI-CONTEXT/COMPONENT-REGISTRY.md
2. AI-CONTEXT/THEME-SYSTEM.md
3. AI-CONTEXT/CODING-STANDARDS.md

REQUIREMENTS:
- Use ONLY existing components from the registry
- Follow the theme system exactly
- Import from the correct paths
- Follow the coding standards

SPECIFIC FEATURE REQUIREMENTS:
[Your specific requirements here]

EXPECTED STRUCTURE:
\```tsx
import { Button } from '@/components/ui/Button'
import { Card } from '@/components/ui/Card'
import { DataTable } from '@/components/ui/DataTable'
// ... other imports from registry

export default function [FeatureName]Page() {
  // Implementation
}
\```
```

## 4. Building Large Features in Chunks

### The "Slice Strategy"
Instead of "build an e-commerce system", break it down:

```markdown
# E-commerce Build Sequence

## Slice 1: Product List Page
Prompt: "Create product list page using DataTable from COMPONENT-REGISTRY.md with:
- Grid/List view toggle
- Sort by price, name, date
- Filter sidebar
- Use existing Card component for grid view"

## Slice 2: Product Detail Page  
Prompt: "Create product detail page using components from COMPONENT-REGISTRY.md:
- Use Card for main content
- Use Button for add to cart
- Use existing ImageGallery component"

## Slice 3: Shopping Cart
[... continue]
```

## 5. The State Management Strategy

### PROJECT-STATE.md
```markdown
# Project State - Updated: [DATE]

## Completed Features
- [x] Authentication System (6 pages)
  - Login, Register, Forgot Password, Reset Password, 2FA, Social Login
- [x] Base Dashboard (analytics theme)
- [x] User Management (CRUD operations)

## In Progress
- [ ] E-commerce Module
  - [x] Product List
  - [x] Product Detail
  - [ ] Shopping Cart <- CURRENTLY HERE
  - [ ] Checkout

## Component Count
- Base Components: 24
- Feature Components: 18
- Total Pages: 42/150

## Next Tasks
1. Complete Shopping Cart
2. Build Checkout Flow
3. Create Order Management
```

## 6. AI Conversation Management

### The "Session Strategy"
Each AI session focuses on ONE feature:

```
Session 1: Build Product List
- Load: COMPONENT-REGISTRY.md, THEME-SYSTEM.md
- Task: Create product list with filters
- Output: pages/products/index.tsx

Session 2: Build Product Detail  
- Load: COMPONENT-REGISTRY.md, THEME-SYSTEM.md
- Task: Create product detail page
- Output: pages/products/[id].tsx

Session 3: Update Registry
- Load: Previous registries
- Task: Add new components created
- Output: Updated COMPONENT-REGISTRY.md
```

## 7. Enforcing Consistency

### CODING-STANDARDS.md
```markdown
# Coding Standards - MUST FOLLOW

## Import Order
1. React imports
2. Third-party imports
3. Component imports from @/components
4. Utility imports from @/utils
5. Type imports

## Component Rules
- ALWAYS use existing components first
- NEVER create new base components without updating registry
- ALWAYS follow the variant patterns

## Styling Rules
- Use Tailwind classes only
- Follow spacing scale: space-y-{2,4,6,8}
- Follow the theme colors: primary, secondary, etc.

## Data Fetching
- Use the existing useQuery hook
- Use generateMockData for demos
- Follow the API response format

## File Naming
- Pages: kebab-case.tsx
- Components: PascalCase.tsx
- Utils: camelCase.ts
```

## 8. Practical Workflow Example

### Building Dashboard Variations

**Step 1: Create Base Dashboard**
```
Prompt: "Create analytics dashboard using components from COMPONENT-REGISTRY.md"
Output: pages/dashboards/analytics.tsx
```

**Step 2: Generate Variations**
```
Prompt: "Convert the analytics dashboard to an e-commerce dashboard by:
1. Keep the same layout
2. Change StatCard data to: Total Sales, Orders, Customers, Revenue
3. Change chart data to sales data
4. Use formatCurrency from UTILS-REGISTRY.md"
```

**Step 3: Rapid Multiplication**
```
Prompt: "Create 5 more dashboard variations:
1. CRM Dashboard (leads, conversions)
2. SaaS Dashboard (MRR, churn, users)
3. Marketing Dashboard (campaigns, ROI)
4. Inventory Dashboard (stock, orders)
5. HR Dashboard (employees, attendance)

Keep the same component structure, just change data and labels"
```

## 9. Component Reuse Patterns

### The "Composition Over Creation" Rule
```tsx
// DON'T: Create new components
const ProductCard = () => { /* new implementation */ }

// DO: Compose from existing
import { Card } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'

const ProductCard = ({ product }) => (
  <Card>
    <Card.Image src={product.image} />
    <Card.Body>
      <Card.Title>{product.name}</Card.Title>
      <Badge>{product.category}</Badge>
      <Card.Text>{product.description}</Card.Text>
    </Card.Body>
    <Card.Footer>
      <Button variant="primary">Add to Cart</Button>
    </Card.Footer>
  </Card>
)
```

## 10. The Build Schedule

### Week 1: Foundation
**Day 1-2: Core Setup**
- Create all registry files
- Build 20 base components
- Set up theme system
- Create component showcase page

**Day 3-4: First Features**
- Authentication flow (6 pages)
- Base dashboard
- User management

**Day 5-7: Rapid Multiplication**
- Generate 10 dashboard variations
- Create 20 form examples
- Build 10 table variations

### Week 2: Applications
**Day 8-9: E-commerce**
- Use existing components
- 15 pages from 5 base templates

**Day 10-11: Mini Apps**
- Email UI (compose from existing)
- Chat UI (compose from existing)
- Calendar (compose from existing)

**Day 12-14: Polish**
- Industry variations
- Additional themes
- Documentation

## Key Success Factors

1. **Registry Discipline**: ALWAYS update registries when adding components
2. **Session Focus**: One feature per AI session
3. **Composition**: Build new features from existing components
4. **Documentation**: Keep AI-CONTEXT folder updated
5. **Chunking**: Break large features into small tasks

## Common Pitfalls to Avoid

1. **Don't let AI recreate existing components**
   - Always provide COMPONENT-REGISTRY.md first

2. **Don't build everything from scratch**
   - Use multiplication strategies

3. **Don't forget to update documentation**
   - End each session by updating registries

4. **Don't mix multiple features in one session**
   - Keep AI focused on one task

## The Golden Rule

**"If AI doesn't know about existing components, it will create new ones"**

Always start EVERY prompt with:
- Read COMPONENT-REGISTRY.md first
- Use ONLY existing components
- Follow THEME-SYSTEM.md

This approach lets you build a 150-page template efficiently while maintaining consistency across the entire project.