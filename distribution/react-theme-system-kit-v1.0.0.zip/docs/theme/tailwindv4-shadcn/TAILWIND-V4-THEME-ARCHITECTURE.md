# Tailwind v4 Theme Architecture

## Overview

This document explains our theme architecture that combines Tailwind v4's powerful theme system with shadcn/ui components, implementing the 60-30-10 design principle with color theory-based relationships.

## Core Architecture

### 1. Three-Layer System

```
┌─────────────────────────────────────┐
│   Tailwind Color Scales (@theme)   │ ← Full color palettes (50-950)
├─────────────────────────────────────┤
│  CSS Bridge Variables (:root/.dark) │ ← Dark mode switching layer
├─────────────────────────────────────┤
│    shadcn Mappings (@theme inline) │ ← Component compatibility
└─────────────────────────────────────┘
```

**Key Concepts:**
- **@theme directive**: Defines theme variables that generate utility classes
- **@theme inline**: References other CSS variables without duplication
- **Theme namespaces**: Organized as --color-*, --font-*, --spacing-*, etc.
- **OKLCH color space**: Better perceptual uniformity than HSL/RGB

### 2. Color Scales in @theme

```css
@theme {
  /* Complete color scales - don't change in dark mode */
  --color-primary-50: oklch(...);
  --color-primary-100: oklch(...);
  /* ... through 950 */
  
  --color-secondary-50: oklch(...);
  /* ... full scale */
  
  --color-neutral-50: oklch(...);
  /* ... full scale */
}
```

### 3. CSS Bridge Variables

```css
/* Light mode */
:root {
  --background: oklch(1 0 0);  /* white */
  --foreground: oklch(0.141 0.005 286);  /* neutral-950 */
  --muted: oklch(0.967 0.001 286);  /* neutral-100 */
  --border: oklch(0.92 0.004 286);  /* neutral-200 */
  /* Dynamic accent colors injected by theme.js */
}

/* Dark mode switching */
.dark {
  --background: oklch(0.141 0.005 286);  /* neutral-950 */
  --foreground: oklch(0.985 0 0);  /* white */
  --muted: oklch(0.274 0.006 286);  /* neutral-800 */
  --border: oklch(1 0 0 / 10%);  /* transparent white */
  /* Dynamic accent colors injected by theme.js */
}

/* Reference in @theme inline */
@theme inline {
  --color-background: var(--background);
  --color-foreground: var(--foreground);
  --color-muted: var(--muted);
  --color-border: var(--border);
  /* Accent colors NOT defined here - dynamically injected */
}
```

## Theme Design Philosophy

### 60-30-10 Color Distribution

- **60% Dominant**: Neutral backgrounds and surfaces
- **30% Supporting**: Secondary colors and muted elements
- **10% Accent**: Primary actions and emphasis

### Color Theory Relationships

Each theme uses specific color relationships:

1. **Complementary** (180°): Maximum contrast
   - Blue ↔ Orange
   - Purple ↔ Yellow/Green

2. **Triadic** (120°): Balanced vibrancy
   - Purple → Green → Orange
   - Blue → Red → Yellow

3. **Analogous** (30-60°): Harmony
   - Blue → Teal → Green
   - Purple → Pink → Red

## Theme Structure

```javascript
// themePresets.js
export const themePresets = {
  purple: {
    name: 'Purple Haze',
    primary: { /* full scale */ },
    secondary: { /* green - triadic */ },
    accent: { /* rose - analogous */ },
    relationships: {
      secondary: 'triadic',
      accent: 'analogous'
    }
  }
}
```

## Implementation

### Theme Switching

```javascript
// theme.js
export function applyTheme(themeName) {
  // Updates color scales only
  // Does NOT update CSS bridge variables
  // Dark mode is handled by CSS
}
```

### Component Usage

```jsx
// Tailwind utilities with scales
<div className="bg-primary-500 hover:bg-primary-600">
  Primary Button
</div>

// shadcn components
<Button variant="secondary">
  Uses our mappings
</Button>

// Semantic colors
<Alert className="border-error text-error">
  Error state
</Alert>
```

## Best Practices

1. **Use color scales** for precise control
2. **Let CSS handle dark mode** via bridge variables
3. **Follow 60-30-10** for visual hierarchy
4. **Maintain color relationships** when creating themes
5. **Test accessibility** with contrast checkers
6. **Use @theme inline** when referencing other variables
7. **Organize theme variables** by namespace (--color-*, --font-*, etc.)
8. **Prefer OKLCH** over HSL/RGB for color consistency
9. **Add data-slot attributes** to components for styling hooks
10. **Use size-* utility** instead of w-* h-* for square elements

## Migration from v3 to v4

### Key Changes:
1. **Move :root and .dark out of @layer base**
2. **Wrap color values in hsl() or oklch()**
3. **Use @theme inline for variable references**
4. **Remove hsl() wrappers from @theme**
5. **Update chart colors to remove hsl() wrapper**
6. **Replace tailwindcss-animate with tw-animate-css**
7. **Remove forwardRef in React 19**

### Example Migration:
```css
/* Old (v3) */
@layer base {
  :root {
    --background: 0 0% 100%;
  }
}

/* New (v4) */
:root {
  --background: oklch(1 0 0);
}

@theme inline {
  --color-background: var(--background);
}
```

## See Also

- [TAILWIND-V4-SHADCN-SOLUTION.md](../../TAILWIND-V4-SHADCN-SOLUTION.md) - Technical implementation details
- [COLOR-PALETTE-GUIDE.md](../COLOR-PALETTE-GUIDE.md) - Color usage guidelines