# Tailwind v4 + shadcn Dark Mode Solution

## Overview

This guide explains the official pattern for integrating shadcn/ui with Tailwind v4, focusing on dark mode implementation. The solution uses CSS variables as a bridge between Tailwind's theme system and shadcn's component expectations.

## Understanding the Integration

### How Tailwind v4 Theme Variables Work

1. **@theme directive**: Creates both utility classes AND CSS variables
   ```css
   @theme {
     --color-mint-500: oklch(0.72 0.11 178);
   }
   /* Creates: bg-mint-500, text-mint-500, AND var(--color-mint-500) */
   ```

2. **@theme inline**: For variables that reference other variables
   ```css
   @theme inline {
     --color-foreground: var(--foreground);
   }
   /* Utility uses the referenced variable directly */
   ```

### How shadcn Expects Variables

shadcn components use CSS variables exclusively:
- `--background`, `--foreground` for main colors
- `--primary`, `--secondary`, `--muted` for semantic colors
- `--border`, `--input`, `--ring` for form elements
- All defined in `:root` and `.dark` selectors

## The Problem with Direct References

When using `@theme inline` with references to Tailwind theme variables, dark mode breaks:

```css
/* What we had (broken): */
@theme inline {
  --color-foreground: var(--color-neutral-950);  /* References theme variable */
}

/* Generated utility: */
.text-foreground { 
  color: var(--color-neutral-950);  /* Hardcoded to light mode value! */
}

/* Dark mode override ignored: */
:root.dark {
  --color-foreground: oklch(0.985 0 0);  /* This does nothing! */
}
```

### The Root Cause

Tailwind v4's `@theme inline` resolves variable references at build time. When you reference a theme variable like `var(--color-neutral-950)`, Tailwind follows the reference chain and generates utilities with the resolved value.

## The Official Solution: CSS Bridge Variables

The official shadcn + Tailwind v4 pattern uses CSS variables as a bridge between Tailwind's theme system and dark mode switching. This is documented in the [official shadcn Tailwind v4 guide](https://ui.shadcn.com/docs/tailwind-v4).

### How It Works

1. **CSS Variables** (outside @theme) handle dark mode switching
2. **@theme inline** references these CSS variables instead of theme variables
3. **Tailwind utilities** now reference variables that can change
4. **shadcn components** use the same CSS variables for consistency

### Why This Pattern?

From the Tailwind v4 documentation:
- Theme variables create utilities: `--color-*` → `bg-*`, `text-*`, etc.
- `@theme inline` is specifically for "referencing other variables"
- CSS variables can be overridden at runtime (perfect for dark mode)
- Theme variables are resolved at build time (not suitable for dark mode)

## Implementation Guide

### Step 1: Define CSS Bridge Variables

```css
/* CSS Bridge Variables for Dark Mode */
/* Important: Define these OUTSIDE @theme and @layer */
:root {
  /* Core colors */
  --background: oklch(1 0 0);  /* white */
  --foreground: oklch(0.141 0.005 286);  /* neutral-950 */
  --card: oklch(1 0 0);
  --card-foreground: oklch(0.141 0.005 286);
  --popover: oklch(1 0 0);
  --popover-foreground: oklch(0.141 0.005 286);
  
  /* Semantic colors */
  --primary: oklch(0.64 0.20 166);  /* Your primary color */
  --primary-foreground: oklch(0.985 0 0);
  --secondary: oklch(0.967 0.001 286);  /* neutral-100 */
  --secondary-foreground: oklch(0.141 0.005 286);
  --muted: oklch(0.967 0.001 286);  /* neutral-100 */
  --muted-foreground: oklch(0.552 0.016 286);  /* neutral-500 */
  --accent: oklch(0.967 0.001 286);
  --accent-foreground: oklch(0.141 0.005 286);
  --destructive: oklch(0.577 0.245 27.325);
  --destructive-foreground: oklch(0.985 0 0);
  
  /* Borders and inputs */
  --border: oklch(0.92 0.004 286);  /* neutral-200 */
  --input: oklch(0.92 0.004 286);
  --ring: oklch(0.64 0.20 166);  /* matches primary */
  
  /* Chart colors */
  --chart-1: oklch(0.646 0.222 41.116);
  --chart-2: oklch(0.6 0.118 184.704);
  --chart-3: oklch(0.398 0.07 227.392);
  --chart-4: oklch(0.828 0.189 84.429);
  --chart-5: oklch(0.769 0.188 70.08);
}

.dark {
  /* Dark mode overrides */
  --background: oklch(0.141 0.005 286);  /* neutral-950 */
  --foreground: oklch(0.985 0 0);  /* white */
  --card: oklch(0.21 0.006 286);  /* neutral-900 */
  --card-foreground: oklch(0.985 0 0);
  --popover: oklch(0.21 0.006 286);
  --popover-foreground: oklch(0.985 0 0);
  
  /* Semantic colors (some stay the same) */
  --primary: oklch(0.64 0.20 166);  /* Same as light */
  --primary-foreground: oklch(0.985 0 0);
  --secondary: oklch(0.274 0.006 286);  /* neutral-800 */
  --secondary-foreground: oklch(0.985 0 0);
  --muted: oklch(0.274 0.006 286);  /* neutral-800 */
  --muted-foreground: oklch(0.705 0.015 286);  /* neutral-400 */
  --accent: oklch(0.274 0.006 286);
  --accent-foreground: oklch(0.985 0 0);
  --destructive: oklch(0.704 0.191 22.216);
  --destructive-foreground: oklch(0.985 0 0);
  
  /* Transparent borders for better dark mode */
  --border: oklch(1 0 0 / 10%);
  --input: oklch(1 0 0 / 15%);
  --ring: oklch(0.64 0.20 166);
  
  /* Adjusted chart colors */
  --chart-1: oklch(0.488 0.243 264.376);
  --chart-2: oklch(0.696 0.17 162.48);
  --chart-3: oklch(0.769 0.188 70.08);
  --chart-4: oklch(0.627 0.265 303.9);
  --chart-5: oklch(0.645 0.246 16.439);
}
```

### Step 2: Reference Bridge Variables in @theme inline

```css
@theme inline {
  /* Map CSS variables to Tailwind theme variables */
  /* This creates utilities like bg-background, text-foreground, etc. */
  
  /* Core colors */
  --color-background: var(--background);
  --color-foreground: var(--foreground);
  --color-card: var(--card);
  --color-card-foreground: var(--card-foreground);
  --color-popover: var(--popover);
  --color-popover-foreground: var(--popover-foreground);
  
  /* Semantic colors */
  --color-primary: var(--primary);
  --color-primary-foreground: var(--primary-foreground);
  --color-secondary: var(--secondary);
  --color-secondary-foreground: var(--secondary-foreground);
  --color-muted: var(--muted);
  --color-muted-foreground: var(--muted-foreground);
  --color-accent: var(--accent);
  --color-accent-foreground: var(--accent-foreground);
  --color-destructive: var(--destructive);
  --color-destructive-foreground: var(--destructive-foreground);
  
  /* Form elements */
  --color-border: var(--border);
  --color-input: var(--input);
  --color-ring: var(--ring);
  
  /* Chart colors */
  --color-chart-1: var(--chart-1);
  --color-chart-2: var(--chart-2);
  --color-chart-3: var(--chart-3);
  --color-chart-4: var(--chart-4);
  --color-chart-5: var(--chart-5);
}
```

### Step 3: Define Your Color Scales and Static Values

```css
@theme {
  /* Color scales that don't change in dark mode */
  /* These create utilities like bg-primary-500, text-neutral-300, etc. */
  
  /* Primary color scale */
  --color-primary-50: oklch(0.98 0.04 166);
  --color-primary-100: oklch(0.96 0.08 166);
  --color-primary-200: oklch(0.91 0.14 166);
  --color-primary-300: oklch(0.84 0.20 166);
  --color-primary-400: oklch(0.74 0.22 166);
  --color-primary-500: oklch(0.64 0.20 166);
  --color-primary-600: oklch(0.54 0.18 166);
  --color-primary-700: oklch(0.44 0.14 166);
  --color-primary-800: oklch(0.36 0.11 166);
  --color-primary-900: oklch(0.30 0.09 166);
  --color-primary-950: oklch(0.20 0.08 166);
  
  /* Neutral scale */
  --color-neutral-50: oklch(0.985 0 0);
  --color-neutral-100: oklch(0.967 0.001 286);
  --color-neutral-200: oklch(0.92 0.004 286);
  --color-neutral-300: oklch(0.871 0.006 286);
  --color-neutral-400: oklch(0.705 0.015 286);
  --color-neutral-500: oklch(0.552 0.016 286);
  --color-neutral-600: oklch(0.442 0.017 286);
  --color-neutral-700: oklch(0.37 0.013 286);
  --color-neutral-800: oklch(0.274 0.006 286);
  --color-neutral-900: oklch(0.21 0.006 286);
  --color-neutral-950: oklch(0.141 0.005 286);
  
  /* Other static values */
  --radius: 0.65rem;  /* Base radius for shadcn components */
}
```

### Step 4: Map shadcn Variables for Component Compatibility

```css
@layer base {
  /* These ensure shadcn components can access the variables they expect */
  :root {
    /* Map theme variables to shadcn's expected names */
    --radius: 0.65rem;
    
    /* Color mappings (reference the CSS variables) */
    --background: var(--background);
    --foreground: var(--foreground);
    --primary: var(--primary);
    --primary-foreground: var(--primary-foreground);
    /* ... etc ... */
  }
}
```

## The Result

With this approach:

1. **Tailwind Utilities Work**: `text-foreground` generates `color: var(--foreground)`
2. **Dark Mode Works**: The CSS variable `--foreground` switches between light and dark values
3. **shadcn Components Work**: They reference the same CSS variables
4. **Full Integration**: Both Tailwind utilities and shadcn components respect dark mode

### Generated Utilities Example

```css
/* Tailwind generates utilities that reference CSS variables */
.bg-background { background-color: var(--background); }
.text-foreground { color: var(--foreground); }
.border-border { border-color: var(--border); }

/* In light mode: */
/* --background = oklch(1 0 0) = white */
/* --foreground = oklch(0.141 0.005 286) = dark text */

/* In dark mode: */
/* --background = oklch(0.141 0.005 286) = dark bg */
/* --foreground = oklch(0.985 0 0) = white text */
```

### Chart Configuration

With this setup, chart colors in JavaScript no longer need hsl() wrappers:

```javascript
const chartConfig = {
  desktop: {
    label: "Desktop",
    color: "var(--chart-1)",  // No hsl() wrapper needed
  },
  mobile: {
    label: "Mobile",
    color: "var(--chart-2)",
  },
}
```

## Key Rules for Tailwind v4 + shadcn Integration

### 1. Variable Definition Rules

**CSS Variables (outside @theme)**
- Define in `:root` and `.dark` for dark mode switching
- Use OKLCH color format (better than HSL)
- No @layer wrapper needed

**Theme Variables (@theme)**
- Use for color scales that don't change
- Use for static design tokens
- Creates both utilities AND CSS variables

**@theme inline**
- ONLY use to reference CSS variables
- Never reference theme variables that need dark mode
- Perfect for the bridge pattern

### 2. Dark Mode Rules

```css
/* ❌ BAD - Breaks dark mode */
@theme inline {
  --color-foreground: var(--color-neutral-950);  /* Theme variable */
}

/* ✅ GOOD - Dark mode works */
:root {
  --foreground: oklch(0.141 0.005 286);
}
.dark {
  --foreground: oklch(0.985 0 0);
}
@theme inline {
  --color-foreground: var(--foreground);  /* CSS variable */
}
```

### 3. Color Format Guidelines

**Use OKLCH instead of HSL**
- Better color consistency across browsers
- More perceptually uniform
- Official recommendation from shadcn

**Transparent Colors in Dark Mode**
```css
.dark {
  --border: oklch(1 0 0 / 10%);  /* 10% white */
  --input: oklch(1 0 0 / 15%);   /* 15% white */
}
```

## Common Pitfalls to Avoid

1. **Don't try to override @theme inline variables** - It won't work
2. **Don't use @theme inline for everything** - Only for CSS variable references
3. **Don't put CSS variables inside @layer** - They should be top-level
4. **Don't forget the shadcn variable names** - Components expect specific names
5. **Don't mix HSL and OKLCH** - Use OKLCH consistently

## Migration Checklist

When setting up or migrating to Tailwind v4 + shadcn:

- [ ] Define CSS bridge variables in `:root` and `.dark`
- [ ] Use OKLCH color format (not HSL)
- [ ] Add `@theme inline` block to reference CSS variables
- [ ] Keep color scales in regular `@theme` block
- [ ] Map shadcn expected variables in `@layer base`
- [ ] Update chart configs to remove hsl() wrappers
- [ ] Test all components in light and dark mode
- [ ] Use `tw-animate-css` instead of `tailwindcss-animate`

## Complete Example Structure

```css
@import "../../../node_modules/.pnpm/tailwindcss@4.1.11/node_modules/tailwindcss/dist/lib.d.mts";
@import "../../../node_modules/tw-animate-css";

/* 1. CSS Bridge Variables */
:root {
   --background: oklch(1 0 0);
   --foreground: oklch(0.141 0.005 286);
   /* ... all other variables ... */
}

.dark {
   --background: oklch(0.141 0.005 286);
   --foreground: oklch(0.985 0 0);
   /* ... all other variables ... */
}

/* 2. Theme Variables */
@theme {
   /* Color scales */
   --color-primary-500: oklch(0.64 0.20 166);
   /* ... other scales ... */
   /* Static values */
   --radius: 0.65rem;
}

/* 3. Bridge to Tailwind */
@theme inline {
   --color-background: var(--background);
   --color-foreground: var(--foreground);
   /* ... map all CSS variables ... */
}

/* 4. Additional mappings if needed */
@layer base {
   /* Any additional setup */
}
```

## Summary

The CSS Bridge Variable pattern is the official solution for using Tailwind v4 with shadcn. It enables:

- **Full dark mode support** through CSS variable switching
- **Tailwind utility generation** via @theme inline
- **shadcn component compatibility** with expected variable names
- **Modern color management** with OKLCH format

This pattern solves the fundamental issue where theme variable references get resolved at build time, ensuring that utilities like `text-foreground` properly switch between light and dark values.