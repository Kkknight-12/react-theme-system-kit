# Universal Theme System for Tailwind/shadcn Projects

A reusable theme creation system inspired by enterprise-grade design systems, built for Tailwind CSS v4 and shadcn/ui, following the 60-30-10 color rule.

## Core Concepts

### 1. Theme Architecture

Our theme system is built on these principles:
- **60-30-10 Rule**: Proper color distribution for visual hierarchy
  - 60% Dominant (backgrounds, large surfaces)
  - 30% Supporting (sections, cards, sidebars)
  - 10% Accent (CTAs, important actions)
- **Dual Shade Systems**: 
  - 11-shade system (50-950) for granular control
  - 5-shade system (lighter, light, main, dark, darker) for component integration
- **Semantic Colors**: Purpose-based naming with proper contrast
- **Dynamic Presets**: 8 color schemes using proper color theory
- **Mode Support**: Light and dark modes with OKLCH color space
- **CSS Variables**: Runtime switching with zero JavaScript after load

### 2. Color Shade Generation Algorithm

Instead of manually defining shades, we'll generate them programmatically:

```javascript
// utils/colorShadeGenerator.js
import Color from 'color';

export function generateColorShades(baseColor) {
  const color = Color(baseColor);
  
  return {
    lighter: color.lightness(90).hex(),
    light: color.lightness(70).hex(),
    main: baseColor,
    dark: color.lightness(40).darken(0.1).hex(),
    darker: color.lightness(25).darken(0.2).hex(),
  };
}

// For better control, use HSL-based generation
export function generateShadesHSL(baseColor) {
  const color = Color(baseColor);
  const hsl = color.hsl();
  
  return {
    lighter: Color.hsl(hsl.hue(), hsl.saturation() * 0.3, 95).hex(),
    light: Color.hsl(hsl.hue(), hsl.saturation() * 0.6, 80).hex(),
    main: baseColor,
    dark: Color.hsl(hsl.hue(), hsl.saturation(), 35).hex(),
    darker: Color.hsl(hsl.hue(), hsl.saturation() * 0.9, 20).hex(),
  };
}
```

### 3. 60-30-10 Color Rule Implementation

Our theme system strictly follows the 60-30-10 rule for visual hierarchy:

- **60% Dominant (Neutrals)**: Backgrounds, large surfaces (`--color-background`, `--color-surface`)
- **30% Supporting (Muted)**: Cards, sections, sidebars (`--color-muted`, `--color-surface-hover`)
- **10% Accent (Vibrant)**: CTAs, important actions (`--color-primary`, `--color-accent`)

**Important**: In our implementation, "secondary" colors in theme presets are NOT used for UI secondary elements. Instead, UI secondary elements use muted neutrals to maintain proper visual hierarchy.

### 4. Theme Preset System with Color Theory

```javascript
// config/themePresets.js
export const themePresets = {
  // Default Emerald - Triadic Color Scheme
  default: {
    name: 'default',
    label: 'Emerald',
    primary: { /* 11 shades of emerald */ },
    secondary: { /* Purple - triadic relationship */ },
    accent: { /* Amber - high contrast */ },
  },
  
  // Ocean Blue
  ocean: {
    name: 'ocean',
    primary: '#0ea5e9', // Sky
    secondary: '#06b6d4', // Cyan
    accent: '#f97316', // Orange
  },
  
  // Forest Green
  forest: {
    name: 'forest',
    primary: '#10b981', // Emerald
    secondary: '#059669', // Green
    accent: '#eab308', // Yellow
  },
  
  // Sunset
  sunset: {
    name: 'sunset',
    primary: '#f97316', // Orange
    secondary: '#ef4444', // Red
    accent: '#a855f7', // Purple
  },
  
  // Midnight
  midnight: {
    name: 'midnight',
    primary: '#8b5cf6', // Violet
    secondary: '#6366f1', // Indigo
    accent: '#14b8a6', // Teal
  },
  
  // Rose Gold
  rosegold: {
    name: 'rosegold',
    primary: '#f43f5e', // Rose
    secondary: '#ec4899', // Pink
    accent: '#84cc16', // Lime
  }
};
```

### 4. Complete Theme Configuration Generator

```javascript
// utils/themeGenerator.js
import { generateShadesHSL } from './colorShadeGenerator';

export function generateThemeConfig(preset) {
  const primary = generateShadesHSL(preset.primary);
  const secondary = generateShadesHSL(preset.secondary);
  const accent = preset.accent;
  
  // Semantic colors (consistent across all themes)
  const semantic = {
    success: '#10b981', // Emerald
    warning: '#f59e0b', // Amber
    error: '#ef4444',   // Red
    info: '#3b82f6',    // Blue
  };
  
  // Generate shades for semantic colors
  const semanticShades = {
    success: generateShadesHSL(semantic.success),
    warning: generateShadesHSL(semantic.warning),
    error: generateShadesHSL(semantic.error),
    info: generateShadesHSL(semantic.info),
  };
  
  // Neutral colors (customized per theme)
  const neutralBase = preset.primary;
  const neutral = generateNeutralScale(neutralBase);
  
  return {
    primary,
    secondary,
    accent,
    semantic: semanticShades,
    neutral,
  };
}

// Generate a neutral scale based on the primary color
function generateNeutralScale(primaryColor) {
  const color = Color(primaryColor);
  const hue = color.hue();
  
  return {
    50: Color.hsl(hue, 5, 98).hex(),
    100: Color.hsl(hue, 5, 96).hex(),
    200: Color.hsl(hue, 5, 93).hex(),
    300: Color.hsl(hue, 5, 88).hex(),
    400: Color.hsl(hue, 5, 74).hex(),
    500: Color.hsl(hue, 5, 62).hex(),
    600: Color.hsl(hue, 5, 46).hex(),
    700: Color.hsl(hue, 5, 34).hex(),
    800: Color.hsl(hue, 5, 23).hex(),
    900: Color.hsl(hue, 5, 13).hex(),
    950: Color.hsl(hue, 5, 7).hex(),
  };
}
```

## Tailwind Integration

### 1. Dynamic Tailwind Configuration

```javascript
// tailwind.config.js
const { themePresets } = require('./config/themePresets');
const { generateThemeConfig } = require('./utils/themeGenerator');

// Generate all theme configurations
const themes = Object.values(themePresets).reduce((acc, preset) => {
  acc[preset.name] = generateThemeConfig(preset);
  return acc;
}, {});

module.exports = {
  darkMode: 'class',
  content: ['./src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        // Dynamic colors using CSS variables
        primary: {
          lighter: 'rgb(var(--primary-lighter) / <alpha-value>)',
          light: 'rgb(var(--primary-light) / <alpha-value>)',
          DEFAULT: 'rgb(var(--primary) / <alpha-value>)',
          dark: 'rgb(var(--primary-dark) / <alpha-value>)',
          darker: 'rgb(var(--primary-darker) / <alpha-value>)',
        },
        secondary: {
          lighter: 'rgb(var(--secondary-lighter) / <alpha-value>)',
          light: 'rgb(var(--secondary-light) / <alpha-value>)',
          DEFAULT: 'rgb(var(--secondary) / <alpha-value>)',
          dark: 'rgb(var(--secondary-dark) / <alpha-value>)',
          darker: 'rgb(var(--secondary-darker) / <alpha-value>)',
        },
        accent: 'rgb(var(--accent) / <alpha-value>)',
        
        // Semantic colors
        success: {
          lighter: 'rgb(var(--success-lighter) / <alpha-value>)',
          light: 'rgb(var(--success-light) / <alpha-value>)',
          DEFAULT: 'rgb(var(--success) / <alpha-value>)',
          dark: 'rgb(var(--success-dark) / <alpha-value>)',
          darker: 'rgb(var(--success-darker) / <alpha-value>)',
        },
        warning: {
          lighter: 'rgb(var(--warning-lighter) / <alpha-value>)',
          light: 'rgb(var(--warning-light) / <alpha-value>)',
          DEFAULT: 'rgb(var(--warning) / <alpha-value>)',
          dark: 'rgb(var(--warning-dark) / <alpha-value>)',
          darker: 'rgb(var(--warning-darker) / <alpha-value>)',
        },
        error: {
          lighter: 'rgb(var(--error-lighter) / <alpha-value>)',
          light: 'rgb(var(--error-light) / <alpha-value>)',
          DEFAULT: 'rgb(var(--error) / <alpha-value>)',
          dark: 'rgb(var(--error-dark) / <alpha-value>)',
          darker: 'rgb(var(--error-darker) / <alpha-value>)',
        },
        info: {
          lighter: 'rgb(var(--info-lighter) / <alpha-value>)',
          light: 'rgb(var(--info-light) / <alpha-value>)',
          DEFAULT: 'rgb(var(--info) / <alpha-value>)',
          dark: 'rgb(var(--info-dark) / <alpha-value>)',
          darker: 'rgb(var(--info-darker) / <alpha-value>)',
        },
        
        // Neutral scale
        neutral: {
          50: 'rgb(var(--neutral-50) / <alpha-value>)',
          100: 'rgb(var(--neutral-100) / <alpha-value>)',
          200: 'rgb(var(--neutral-200) / <alpha-value>)',
          300: 'rgb(var(--neutral-300) / <alpha-value>)',
          400: 'rgb(var(--neutral-400) / <alpha-value>)',
          500: 'rgb(var(--neutral-500) / <alpha-value>)',
          600: 'rgb(var(--neutral-600) / <alpha-value>)',
          700: 'rgb(var(--neutral-700) / <alpha-value>)',
          800: 'rgb(var(--neutral-800) / <alpha-value>)',
          900: 'rgb(var(--neutral-900) / <alpha-value>)',
          950: 'rgb(var(--neutral-950) / <alpha-value>)',
        },
        
        // Surface colors
        background: 'rgb(var(--background) / <alpha-value>)',
        surface: 'rgb(var(--surface) / <alpha-value>)',
        'surface-variant': 'rgb(var(--surface-variant) / <alpha-value>)',
        
        // Text colors
        'text-primary': 'rgb(var(--text-primary) / <alpha-value>)',
        'text-secondary': 'rgb(var(--text-secondary) / <alpha-value>)',
        'text-disabled': 'rgb(var(--text-disabled) / <alpha-value>)',
      },
      
      // Theme-aware shadows
      boxShadow: {
        'sm': '0 1px 2px 0 rgb(var(--shadow-color) / 0.05)',
        'DEFAULT': '0 1px 3px 0 rgb(var(--shadow-color) / 0.1), 0 1px 2px -1px rgb(var(--shadow-color) / 0.1)',
        'md': '0 4px 6px -1px rgb(var(--shadow-color) / 0.1), 0 2px 4px -2px rgb(var(--shadow-color) / 0.1)',
        'lg': '0 10px 15px -3px rgb(var(--shadow-color) / 0.1), 0 4px 6px -4px rgb(var(--shadow-color) / 0.1)',
        'xl': '0 20px 25px -5px rgb(var(--shadow-color) / 0.1), 0 8px 10px -6px rgb(var(--shadow-color) / 0.1)',
        '2xl': '0 25px 50px -12px rgb(var(--shadow-color) / 0.25)',
        'primary': '0 4px 14px 0 rgb(var(--primary) / 0.4)',
        'secondary': '0 4px 14px 0 rgb(var(--secondary) / 0.4)',
      },
    },
  },
  plugins: [],
};
```

### 2. CSS Variables Setup

```css
/* styles/themes.css */
@layer base {
  /* Default theme (Modern) - Light mode */
  :root {
    /* Primary - Indigo */
    --primary-lighter: 224 231 255;
    --primary-light: 199 210 254;
    --primary: 99 102 241;
    --primary-dark: 67 56 202;
    --primary-darker: 49 46 129;
    
    /* Secondary - Purple */
    --secondary-lighter: 233 213 255;
    --secondary-light: 196 167 255;
    --secondary: 139 92 246;
    --secondary-dark: 109 40 217;
    --secondary-darker: 76 29 149;
    
    /* Accent */
    --accent: 245 158 11;
    
    /* Success - Emerald */
    --success-lighter: 209 250 229;
    --success-light: 167 243 208;
    --success: 16 185 129;
    --success-dark: 5 150 105;
    --success-darker: 4 120 87;
    
    /* Warning - Amber */
    --warning-lighter: 254 243 199;
    --warning-light: 253 230 138;
    --warning: 245 158 11;
    --warning-dark: 217 119 6;
    --warning-darker: 146 64 14;
    
    /* Error - Red */
    --error-lighter: 254 226 226;
    --error-light: 254 202 202;
    --error: 239 68 68;
    --error-dark: 220 38 38;
    --error-darker: 153 27 27;
    
    /* Info - Blue */
    --info-lighter: 219 234 254;
    --info-light: 191 219 254;
    --info: 59 130 246;
    --info-dark: 37 99 235;
    --info-darker: 29 78 216;
    
    /* Neutral scale */
    --neutral-50: 250 250 251;
    --neutral-100: 244 244 246;
    --neutral-200: 237 237 239;
    --neutral-300: 224 224 227;
    --neutral-400: 189 189 192;
    --neutral-500: 158 158 163;
    --neutral-600: 118 118 124;
    --neutral-700: 87 87 93;
    --neutral-800: 58 58 64;
    --neutral-900: 37 37 43;
    --neutral-950: 18 18 23;
    
    /* Surface colors */
    --background: 255 255 255;
    --surface: 250 250 251;
    --surface-variant: 244 244 246;
    
    /* Text colors */
    --text-primary: 18 18 23;
    --text-secondary: 87 87 93;
    --text-disabled: 158 158 163;
    
    /* Shadow color */
    --shadow-color: 0 0 0;
  }
  
  /* Dark mode overrides */
  .dark {
    /* Surface colors */
    --background: 18 18 23;
    --surface: 37 37 43;
    --surface-variant: 58 58 64;
    
    /* Text colors */
    --text-primary: 250 250 251;
    --text-secondary: 189 189 192;
    --text-disabled: 118 118 124;
    
    /* Shadow color */
    --shadow-color: 0 0 0;
  }
  
  /* Theme presets */
  [data-theme="ocean"] {
    /* Ocean theme colors */
    --primary-lighter: 224 242 254;
    --primary-light: 186 230 253;
    --primary: 14 165 233;
    --primary-dark: 2 132 199;
    --primary-darker: 12 74 110;
    
    --secondary-lighter: 207 250 254;
    --secondary-light: 165 243 252;
    --secondary: 6 182 212;
    --secondary-dark: 8 145 178;
    --secondary-darker: 21 94 117;
    
    --accent: 249 115 22;
  }
  
  [data-theme="forest"] {
    /* Forest theme colors */
    --primary-lighter: 220 252 231;
    --primary-light: 187 247 208;
    --primary: 16 185 129;
    --primary-dark: 5 150 105;
    --primary-darker: 6 95 70;
    
    --secondary-lighter: 220 252 231;
    --secondary-light: 187 247 208;
    --secondary: 5 150 105;
    --secondary-dark: 4 120 87;
    --secondary-darker: 6 78 59;
    
    --accent: 234 179 8;
  }
  
  /* Add more theme presets... */
}
```

### 3. React Theme Provider

```jsx
// contexts/ThemeContext.jsx
import { createContext, useContext, useEffect, useState } from 'react';

const ThemeContext = createContext();

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within ThemeProvider');
  }
  return context;
};

const THEME_STORAGE_KEY = 'app-theme-preference';

export function ThemeProvider({ children, defaultTheme = 'modern', defaultMode = 'light' }) {
  const [theme, setTheme] = useState(() => {
    // Load from localStorage
    const stored = localStorage.getItem(THEME_STORAGE_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
    return { preset: defaultTheme, mode: defaultMode };
  });

  // Apply theme changes
  useEffect(() => {
    // Apply mode
    if (theme.mode === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    
    // Apply preset
    document.documentElement.setAttribute('data-theme', theme.preset);
    
    // Save to localStorage
    localStorage.setItem(THEME_STORAGE_KEY, JSON.stringify(theme));
  }, [theme]);

  const setMode = (mode) => {
    setTheme(prev => ({ ...prev, mode }));
  };

  const toggleMode = () => {
    setTheme(prev => ({ ...prev, mode: prev.mode === 'light' ? 'dark' : 'light' }));
  };

  const setPreset = (preset) => {
    setTheme(prev => ({ ...prev, preset }));
  };

  const value = {
    theme,
    setMode,
    toggleMode,
    setPreset,
    availablePresets: ['modern', 'ocean', 'forest', 'sunset', 'midnight', 'rosegold'],
  };

  return (
    <ThemeContext.Provider value={value}>
      {children}
    </ThemeContext.Provider>
  );
}
```

### 4. Theme Switcher Component

```jsx
// components/ThemeSwitcher.jsx
import { useTheme } from '@/contexts/ThemeContext';
import { Palette, Moon, Sun } from 'lucide-react';

export function ThemeSwitcher() {
  const { theme, toggleMode, setPreset, availablePresets } = useTheme();

  return (
    <div className="flex items-center gap-4">
      {/* Mode toggle */}
      <button
        onClick={toggleMode}
        className="p-2 rounded-lg bg-surface hover:bg-surface-variant transition-colors"
        aria-label="Toggle theme mode"
      >
        {theme.mode === 'light' ? (
          <Moon className="h-5 w-5" />
        ) : (
          <Sun className="h-5 w-5" />
        )}
      </button>

      {/* Preset selector */}
      <div className="relative">
        <select
          value={theme.preset}
          onChange={(e) => setPreset(e.target.value)}
          className="appearance-none bg-surface hover:bg-surface-variant px-4 py-2 pr-8 rounded-lg transition-colors cursor-pointer"
        >
          {availablePresets.map(preset => (
            <option key={preset} value={preset}>
              {preset.charAt(0).toUpperCase() + preset.slice(1)}
            </option>
          ))}
        </select>
        <Palette className="absolute right-2 top-1/2 -translate-y-1/2 h-4 w-4 pointer-events-none" />
      </div>
    </div>
  );
}
```

## Tailwind v4 Implementation with OKLCH

### 1. Using @theme Directive

```css
/* index.css - Tailwind v4 with OKLCH color space */
@import "../../node_modules/.pnpm/tailwindcss@4.1.11/node_modules/tailwindcss/dist/lib.d.mts";

@theme {
  /* Primary colors with 11-shade system */
  --color-primary-50: oklch(0.98 0.04 166);
  --color-primary-100: oklch(0.96 0.08 166);
  --color-primary-200: oklch(0.91 0.14 166);
  --color-primary-300: oklch(0.84 0.20 166);
  --color-primary-400: oklch(0.74 0.22 166);
  --color-primary-500: oklch(0.64 0.20 166);
  --color-primary-600: oklch(0.54 0.18 166);
  --color-primary-700: oklch(0.44 0.14 166);
  --color-primary-800: oklch(0.36 0.11 166);
  --color-primary-900: oklch(0.30 0.09 166);
  --color-primary-950: oklch(0.20 0.08 166);

  /* 5-shade system mapping */
  --color-primary-lighter: var(--color-primary-200);
  --color-primary-light: var(--color-primary-400);
  --color-primary: var(--color-primary-500);
  --color-primary-dark: var(--color-primary-600);
  --color-primary-darker: var(--color-primary-800);
}
```

### 2. Dynamic Theme Application

```javascript
// utils/theme.js
export function applyTheme(themeName) {
  const preset = themePresets[themeName];
  if (!preset) return;

  // Cache CSS for performance
  if (themeCache.has(themeName)) {
    styleElement.textContent = themeCache.get(themeName);
    return;
  }

  const css = `
    :root {
      /* Primary colors */
      ${Object.entries(preset.primary)
        .filter(([shade]) => shade !== 'DEFAULT')
        .map(([shade, hex]) => {
          const oklch = hexToOklch(hex);
          return `--color-primary-${shade}: ${oklch};`;
        })
        .join('\n      ')}
      
      /* Compute contrast colors dynamically */
      --color-secondary-foreground: ${getContrastColor(preset.secondary?.[500])};
      --color-accent-foreground: ${getContrastColor(preset.accent?.[500])};
    }
  `;
  
  themeCache.set(themeName, css);
  styleElement.textContent = css;
}
```

## shadcn/ui Integration with 60-30-10 Rule

### 1. Proper Color Mapping

```css
/* Map shadcn variables following 60-30-10 rule */
:root {
  /* 60% - Dominant neutrals */
  --background: var(--color-background);
  --card: var(--color-surface);
  
  /* 30% - Supporting elements (NOT vibrant secondary!) */
  --secondary: var(--color-muted);
  --secondary-foreground: var(--color-muted-foreground);
  --muted: var(--color-surface-hover);
  
  /* 10% - Accent/emphasis */
  --primary: var(--color-primary-500);
  --accent: var(--color-accent-500);
}
```

### 2. Button Hierarchy Following 60-30-10

```jsx
// Primary button (10% - accent)
<Button variant="default">Primary Action</Button>

// Secondary button (30% - muted supporting)
<Button variant="secondary">Secondary Action</Button>

// Tertiary actions
<Button variant="outline">Outline</Button>
<Button variant="ghost">Ghost</Button>
```

### 2. Component Usage Examples

```jsx
// Example components using the theme system

// Card with theme-aware styling
export function ThemedCard({ children }) {
  return (
    <div className="bg-surface border border-neutral-200 dark:border-neutral-700 rounded-lg p-6 shadow-md">
      {children}
    </div>
  );
}

// Button variants
export function ThemedButton({ variant = 'primary', children, ...props }) {
  const variants = {
    primary: 'bg-primary hover:bg-primary-dark text-white',
    secondary: 'bg-secondary hover:bg-secondary-dark text-white',
    success: 'bg-success hover:bg-success-dark text-white',
    error: 'bg-error hover:bg-error-dark text-white',
    outline: 'border-2 border-primary text-primary hover:bg-primary hover:text-white',
  };

  return (
    <button
      className={`px-4 py-2 rounded-lg transition-colors ${variants[variant]}`}
      {...props}
    >
      {children}
    </button>
  );
}

// Alert component
export function ThemedAlert({ type = 'info', children }) {
  const types = {
    info: 'bg-info-lighter border-info text-info-darker',
    success: 'bg-success-lighter border-success text-success-darker',
    warning: 'bg-warning-lighter border-warning text-warning-darker',
    error: 'bg-error-lighter border-error text-error-darker',
  };

  return (
    <div className={`p-4 rounded-lg border ${types[type]}`}>
      {children}
    </div>
  );
}
```

## Quick Start Guide

### 1. Install Dependencies

```bash
npm install color
# or
yarn add color
```

### 2. Setup File Structure

```
your-project/
├── config/
│   └── themePresets.js
├── utils/
│   ├── colorShadeGenerator.js
│   └── themeGenerator.js
├── contexts/
│   └── ThemeContext.jsx
├── components/
│   └── ThemeSwitcher.jsx
├── styles/
│   └── themes.css
└── tailwind.config.js
```

### 3. Initialize Theme

```jsx
// App.jsx or _app.jsx
import { ThemeProvider } from '@/contexts/ThemeContext';
import '@/styles/themes.css';

function App() {
  return (
    <ThemeProvider defaultTheme="modern" defaultMode="light">
      {/* Your app content */}
    </ThemeProvider>
  );
}
```

### 4. Use Theme Components

```jsx
import { ThemeSwitcher } from '@/components/ThemeSwitcher';

function Header() {
  return (
    <header className="bg-surface border-b border-neutral-200 dark:border-neutral-700">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <h1 className="text-2xl font-bold text-primary">My App</h1>
        <ThemeSwitcher />
      </div>
    </header>
  );
}
```

## Best Practices

1. **Consistent Naming**: Always use semantic names (primary, secondary) not color names
2. **Accessibility**: Ensure sufficient contrast ratios for all color combinations
3. **Performance**: Use CSS variables for instant theme switching
4. **Flexibility**: Design components to work with any theme preset
5. **Documentation**: Document your color choices and their intended use

## Benefits

- **Reusable**: Use this system across all your projects
- **Flexible**: Easy to add new theme presets
- **Professional**: Enterprise-grade theming like major UI frameworks
- **Performance**: No JavaScript rebuilds for theme changes
- **User-Friendly**: Let users choose their preferred theme

This system gives you the power of Material-UI's theming with the simplicity of Tailwind CSS!