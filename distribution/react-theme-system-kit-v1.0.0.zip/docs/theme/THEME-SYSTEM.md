# Theme System - ALWAYS FOLLOW THESE DESIGN RULES

**CRITICAL**: This is the single source of truth for all styling decisions. Every component MUST follow these rules.

> **Tailwind v4 Note**: This project uses Tailwind CSS v4 with the new `@theme` directive. Colors are defined in `src/index.css` and automatically generate utility classes. See TAILWIND-V4-SETUP.md for implementation details.

## Table of Contents
1. [Color System](#color-system)
2. [Typography Scale](#typography-scale)
3. [Spacing System](#spacing-system)
4. [Border Radius](#border-radius)
5. [Shadows](#shadows)
6. [Breakpoints](#breakpoints)
7. [Z-Index Scale](#z-index-scale)
8. [Animation Values](#animation-values)
9. [Component Patterns](#component-patterns)
10. [Theme Implementation](#theme-implementation)

---

## Color System

### Primary Colors
```css
/* ALWAYS use these CSS variables, never hardcode colors */
--primary-50: rgb(239 246 255);
--primary-100: rgb(219 234 254);
--primary-200: rgb(191 219 254);
--primary-300: rgb(147 197 253);
--primary-400: rgb(96 165 250);
--primary-500: rgb(59 130 246);  /* Main primary */
--primary-600: rgb(37 99 235);
--primary-700: rgb(29 78 216);
--primary-800: rgb(30 64 175);
--primary-900: rgb(30 58 138);
--primary-950: rgb(23 37 84);
```

### Semantic Colors
```css
/* Success */
--success: rgb(34 197 94);
--success-light: rgb(134 239 172);
--success-dark: rgb(22 163 74);

/* Warning */
--warning: rgb(251 146 60);
--warning-light: rgb(254 215 170);
--warning-dark: rgb(234 88 12);

/* Error/Danger */
--error: rgb(239 68 68);
--error-light: rgb(252 165 165);
--error-dark: rgb(220 38 38);

/* Info */
--info: rgb(59 130 246);
--info-light: rgb(147 197 253);
--info-dark: rgb(37 99 235);
```

### Neutral Colors
```css
/* Grey scale for text, borders, backgrounds */
--gray-50: rgb(249 250 251);
--gray-100: rgb(243 244 246);
--gray-200: rgb(229 231 235);
--gray-300: rgb(209 213 219);
--gray-400: rgb(156 163 175);
--gray-500: rgb(107 114 128);
--gray-600: rgb(75 85 99);
--gray-700: rgb(55 65 81);
--gray-800: rgb(31 41 55);
--gray-900: rgb(17 24 39);
--gray-950: rgb(3 7 18);
```

### Surface Colors
```css
/* Light mode */
--background: rgb(255 255 255);
--surface: rgb(249 250 251);
--surface-hover: rgb(243 244 246);
--surface-active: rgb(229 231 235);

/* Dark mode */
.dark {
  --background: rgb(3 7 18);
  --surface: rgb(17 24 39);
  --surface-hover: rgb(31 41 55);
  --surface-active: rgb(55 65 81);
}
```

### Text Colors
```css
/* Light mode */
--text-primary: rgb(17 24 39);
--text-secondary: rgb(107 114 128);
--text-disabled: rgb(156 163 175);
--text-inverse: rgb(255 255 255);

/* Dark mode */
.dark {
  --text-primary: rgb(249 250 251);
  --text-secondary: rgb(156 163 175);
  --text-disabled: rgb(107 114 128);
  --text-inverse: rgb(17 24 39);
}
```

### Usage in Components
```tsx
// DO: Use semantic color classes
<Button className="bg-primary-500 hover:bg-primary-600 text-white">

// DON'T: Use arbitrary colors
<Button className="bg-blue-500">

// DO: Use surface colors for cards
<Card className="bg-surface border-gray-200">

// DON'T: Use white directly
<Card className="bg-white">
```

---

## Typography Scale

### Font Family
```css
--font-sans: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
--font-mono: "SF Mono", Monaco, "Cascadia Code", "Roboto Mono", monospace;
```

### Font Sizes
```css
/* ALWAYS use these classes, never arbitrary sizes */
text-xs    /* 12px - 0.75rem */
text-sm    /* 14px - 0.875rem */
text-base  /* 16px - 1rem (default) */
text-lg    /* 18px - 1.125rem */
text-xl    /* 20px - 1.25rem */
text-2xl   /* 24px - 1.5rem */
text-3xl   /* 30px - 1.875rem */
text-4xl   /* 36px - 2.25rem */
text-5xl   /* 48px - 3rem */
```

### Font Weights
```css
font-normal     /* 400 */
font-medium     /* 500 */
font-semibold   /* 600 */
font-bold       /* 700 */
```

### Line Heights
```css
leading-none    /* 1 */
leading-tight   /* 1.25 */
leading-snug    /* 1.375 */
leading-normal  /* 1.5 */
leading-relaxed /* 1.625 */
leading-loose   /* 2 */
```

### Typography Patterns
```tsx
// Page Title
<h1 className="text-3xl font-bold text-text-primary">

// Section Title
<h2 className="text-2xl font-semibold text-text-primary">

// Card Title
<h3 className="text-lg font-semibold text-text-primary">

// Body Text
<p className="text-base text-text-secondary leading-relaxed">

// Small Text
<span className="text-sm text-text-secondary">

// Caption
<span className="text-xs text-text-disabled">
```

---

## Spacing System

### Base Unit: 4px (0.25rem)
```css
/* ALWAYS use these spacing values */
space-0   /* 0px */
space-1   /* 4px - 0.25rem */
space-2   /* 8px - 0.5rem */
space-3   /* 12px - 0.75rem */
space-4   /* 16px - 1rem */
space-5   /* 20px - 1.25rem */
space-6   /* 24px - 1.5rem */
space-7   /* 28px - 1.75rem */
space-8   /* 32px - 2rem */
space-10  /* 40px - 2.5rem */
space-12  /* 48px - 3rem */
space-16  /* 64px - 4rem */
space-20  /* 80px - 5rem */
space-24  /* 96px - 6rem */
```

### Spacing Patterns
```tsx
// Card Padding
<Card className="p-6">

// Section Spacing
<section className="py-12 md:py-16">

// Form Field Spacing
<Stack spacing={4}>

// Button Padding
<Button className="px-4 py-2">  // Medium
<Button className="px-3 py-1.5"> // Small
<Button className="px-6 py-3">   // Large
```

---

## Border Radius

```css
rounded-none    /* 0px */
rounded-sm      /* 2px - 0.125rem */
rounded         /* 4px - 0.25rem */
rounded-md      /* 6px - 0.375rem */
rounded-lg      /* 8px - 0.5rem (DEFAULT for cards) */
rounded-xl      /* 12px - 0.75rem */
rounded-2xl     /* 16px - 1rem */
rounded-3xl     /* 24px - 1.5rem */
rounded-full    /* 9999px */
```

### Component Border Radius
```tsx
// Cards
<Card className="rounded-lg">

// Buttons
<Button className="rounded-md">

// Inputs
<Input className="rounded-md">

// Avatars
<Avatar className="rounded-full">

// Badges
<Badge className="rounded-full">
```

---

## Shadows

```css
/* Elevation Scale */
shadow-none
shadow-sm     /* Subtle shadow for hover states */
shadow        /* Default shadow for cards (DEFAULT) */
shadow-md     /* Dropdowns, popovers */
shadow-lg     /* Modals, drawers */
shadow-xl     /* Elevated elements */
shadow-2xl    /* Maximum elevation */

/* Colored Shadows */
shadow-primary   /* 0 4px 14px 0 rgb(59 130 246 / 0.3) */
shadow-success   /* 0 4px 14px 0 rgb(34 197 94 / 0.3) */
shadow-error     /* 0 4px 14px 0 rgb(239 68 68 / 0.3) */
```

### Shadow Patterns
```tsx
// Card (resting)
<Card className="shadow">

// Card (hover)
<Card className="shadow hover:shadow-md transition-shadow">

// Floating Action Button
<Button className="shadow-lg">

// Modal
<Modal className="shadow-2xl">
```

---

## Breakpoints

```css
/* Mobile First Approach */
sm:   /* 640px  - Small devices */
md:   /* 768px  - Medium devices */
lg:   /* 1024px - Large devices */
xl:   /* 1280px - Extra large devices */
2xl:  /* 1536px - 2X large devices */
```

### Responsive Patterns
```tsx
// Responsive Grid
<Grid className="grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">

// Responsive Padding
<Container className="px-4 sm:px-6 lg:px-8">

// Responsive Text
<h1 className="text-2xl md:text-3xl lg:text-4xl">

// Hide/Show by Breakpoint
<div className="hidden lg:block"> // Desktop only
<div className="block lg:hidden"> // Mobile only
```

---

## Z-Index Scale

```css
/* ALWAYS use these z-index values */
z-0       /* 0 - Base level */
z-10      /* 10 - Dropdown, Popover */
z-20      /* 20 - Fixed headers */
z-30      /* 30 - Drawer overlay */
z-40      /* 40 - Modal overlay */
z-50      /* 50 - Toast notifications */
z-[9999]  /* 9999 - Critical UI (tooltips) */
```

### Z-Index Usage
```tsx
// Header
<header className="sticky top-0 z-20">

// Modal Backdrop
<div className="fixed inset-0 z-40 bg-black/50">

// Modal Content
<div className="relative z-40">

// Toast
<div className="fixed top-4 right-4 z-50">
```

---

## Animation Values

### Durations
```css
duration-75   /* 75ms - Micro interactions */
duration-150  /* 150ms - Default (RECOMMENDED) */
duration-200  /* 200ms - Smooth transitions */
duration-300  /* 300ms - Modal/drawer */
duration-500  /* 500ms - Page transitions */
```

### Easing Functions
```css
ease-linear
ease-in
ease-out
ease-in-out  /* DEFAULT - Use for most animations */
```

### Common Animations
```tsx
// Hover Transitions
<Button className="transition-colors duration-150">

// All Properties
<Card className="transition-all duration-200 hover:shadow-md">

// Transform
<div className="transition-transform duration-200 hover:scale-105">

// Opacity
<div className="transition-opacity duration-300">
```

---

## Component Patterns

### Button Sizes & Variants
```tsx
// Size Classes
const sizeClasses = {
  xs: "px-2.5 py-1 text-xs",
  sm: "px-3 py-1.5 text-sm",
  md: "px-4 py-2 text-base",    // DEFAULT
  lg: "px-6 py-3 text-lg",
  xl: "px-8 py-4 text-xl"
}

// Variant Classes
const variantClasses = {
  primary: "bg-primary-500 hover:bg-primary-600 text-white",
  secondary: "bg-gray-100 hover:bg-gray-200 text-gray-900",
  outline: "border-2 border-primary-500 text-primary-500 hover:bg-primary-50",
  ghost: "hover:bg-gray-100 text-gray-700",
  danger: "bg-error hover:bg-error-dark text-white"
}
```

### Input Styling
```tsx
// Base Input Classes
const inputClasses = `
  w-full px-3 py-2
  bg-white border border-gray-300 rounded-md
  text-text-primary placeholder:text-gray-400
  focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent
  disabled:bg-gray-50 disabled:text-gray-500 disabled:cursor-not-allowed
`

// Error State
const errorClasses = "border-error focus:ring-error"
```

### Card Styling
```tsx
// Base Card
const cardClasses = `
  bg-surface rounded-lg shadow
  border border-gray-200
  overflow-hidden
`

// Hover Card
const hoverCardClasses = `
  ${cardClasses}
  hover:shadow-md transition-shadow duration-200
  cursor-pointer
`
```

---

## Theme Implementation

### CSS Variables Setup
```css
/* app/globals.css */
@layer base {
  :root {
    /* Add all color variables here */
    --primary-500: 59 130 246;
    /* ... rest of colors */
  }
  
  .dark {
    /* Dark mode overrides */
    --background: 3 7 18;
    /* ... rest of dark colors */
  }
}
```

### Using Theme Colors
```tsx
// Tailwind Config Extension
colors: {
  primary: {
    50: 'rgb(var(--primary-50) / <alpha-value>)',
    // ... all shades
    500: 'rgb(var(--primary-500) / <alpha-value>)',
  }
}

// Component Usage
<div className="bg-primary-500/20"> // With opacity
```

### Theme Context Usage
```tsx
import { useTheme } from '@/contexts/ThemeContext'

function Component() {
  const { theme, toggleTheme } = useTheme()
  
  return (
    <div className={theme === 'dark' ? 'dark' : ''}>
      {/* Content */}
    </div>
  )
}
```

---

## Golden Rules

1. **NEVER hardcode colors** - Always use CSS variables
2. **NEVER use arbitrary values** - Use the spacing/size scale
3. **ALWAYS use semantic colors** - primary, success, error, etc.
4. **FOLLOW the 4px grid** - All spacing must be divisible by 4
5. **MAINTAIN consistency** - Same element = same styling across app
6. **MOBILE FIRST** - Default styles for mobile, enhance for desktop
7. **USE transitions** - Smooth state changes (150-200ms)
8. **RESPECT the scale** - Don't create new values

## Quick Reference Card

```tsx
// Perfect Button
<Button className="
  px-4 py-2 
  bg-primary-500 hover:bg-primary-600 
  text-white font-medium 
  rounded-md shadow-sm 
  transition-colors duration-150
">

// Perfect Card
<Card className="
  bg-surface rounded-lg shadow 
  border border-gray-200 
  p-6 space-y-4
">

// Perfect Input
<Input className="
  w-full px-3 py-2 
  bg-white border border-gray-300 rounded-md
  focus:ring-2 focus:ring-primary-500
">
```

## Remember

This theme system ensures visual consistency across 150+ pages. Every color, spacing, and style decision should reference this document.